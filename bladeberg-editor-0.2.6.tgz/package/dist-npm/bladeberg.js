function Ki(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Xi = { exports: {} }, R = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Gn = Symbol.for("react.element"), sc = Symbol.for("react.portal"), ac = Symbol.for("react.fragment"), cc = Symbol.for("react.strict_mode"), fc = Symbol.for("react.profiler"), dc = Symbol.for("react.provider"), pc = Symbol.for("react.context"), mc = Symbol.for("react.forward_ref"), hc = Symbol.for("react.suspense"), vc = Symbol.for("react.memo"), gc = Symbol.for("react.lazy"), Du = Symbol.iterator;
function yc(e) {
  return e === null || typeof e != "object" ? null : (e = Du && e[Du] || e["@@iterator"], typeof e == "function" ? e : null);
}
var Yi = { isMounted: function() {
  return !1;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, Gi = Object.assign, Zi = {};
function on(e, t, n) {
  this.props = e, this.context = t, this.refs = Zi, this.updater = n || Yi;
}
on.prototype.isReactComponent = {};
on.prototype.setState = function(e, t) {
  if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, e, t, "setState");
};
on.prototype.forceUpdate = function(e) {
  this.updater.enqueueForceUpdate(this, e, "forceUpdate");
};
function Ji() {
}
Ji.prototype = on.prototype;
function Ao(e, t, n) {
  this.props = e, this.context = t, this.refs = Zi, this.updater = n || Yi;
}
var Vo = Ao.prototype = new Ji();
Vo.constructor = Ao;
Gi(Vo, on.prototype);
Vo.isPureReactComponent = !0;
var Fu = Array.isArray, qi = Object.prototype.hasOwnProperty, Wo = { current: null }, bi = { key: !0, ref: !0, __self: !0, __source: !0 };
function es(e, t, n) {
  var r, l = {}, o = null, u = null;
  if (t != null) for (r in t.ref !== void 0 && (u = t.ref), t.key !== void 0 && (o = "" + t.key), t) qi.call(t, r) && !bi.hasOwnProperty(r) && (l[r] = t[r]);
  var i = arguments.length - 2;
  if (i === 1) l.children = n;
  else if (1 < i) {
    for (var s = Array(i), a = 0; a < i; a++) s[a] = arguments[a + 2];
    l.children = s;
  }
  if (e && e.defaultProps) for (r in i = e.defaultProps, i) l[r] === void 0 && (l[r] = i[r]);
  return { $$typeof: Gn, type: e, key: o, ref: u, props: l, _owner: Wo.current };
}
function wc(e, t) {
  return { $$typeof: Gn, type: e.type, key: t, ref: e.ref, props: e.props, _owner: e._owner };
}
function Ho(e) {
  return typeof e == "object" && e !== null && e.$$typeof === Gn;
}
function kc(e) {
  var t = { "=": "=0", ":": "=2" };
  return "$" + e.replace(/[=:]/g, function(n) {
    return t[n];
  });
}
var Uu = /\/+/g;
function kl(e, t) {
  return typeof e == "object" && e !== null && e.key != null ? kc("" + e.key) : t.toString(36);
}
function wr(e, t, n, r, l) {
  var o = typeof e;
  (o === "undefined" || o === "boolean") && (e = null);
  var u = !1;
  if (e === null) u = !0;
  else switch (o) {
    case "string":
    case "number":
      u = !0;
      break;
    case "object":
      switch (e.$$typeof) {
        case Gn:
        case sc:
          u = !0;
      }
  }
  if (u) return u = e, l = l(u), e = r === "" ? "." + kl(u, 0) : r, Fu(l) ? (n = "", e != null && (n = e.replace(Uu, "$&/") + "/"), wr(l, t, n, "", function(a) {
    return a;
  })) : l != null && (Ho(l) && (l = wc(l, n + (!l.key || u && u.key === l.key ? "" : ("" + l.key).replace(Uu, "$&/") + "/") + e)), t.push(l)), 1;
  if (u = 0, r = r === "" ? "." : r + ":", Fu(e)) for (var i = 0; i < e.length; i++) {
    o = e[i];
    var s = r + kl(o, i);
    u += wr(o, t, n, s, l);
  }
  else if (s = yc(e), typeof s == "function") for (e = s.call(e), i = 0; !(o = e.next()).done; ) o = o.value, s = r + kl(o, i++), u += wr(o, t, n, s, l);
  else if (o === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
  return u;
}
function nr(e, t, n) {
  if (e == null) return e;
  var r = [], l = 0;
  return wr(e, r, "", "", function(o) {
    return t.call(n, o, l++);
  }), r;
}
function Sc(e) {
  if (e._status === -1) {
    var t = e._result;
    t = t(), t.then(function(n) {
      (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n);
    }, function(n) {
      (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n);
    }), e._status === -1 && (e._status = 0, e._result = t);
  }
  if (e._status === 1) return e._result.default;
  throw e._result;
}
var ae = { current: null }, kr = { transition: null }, Ec = { ReactCurrentDispatcher: ae, ReactCurrentBatchConfig: kr, ReactCurrentOwner: Wo };
function ts() {
  throw Error("act(...) is not supported in production builds of React.");
}
R.Children = { map: nr, forEach: function(e, t, n) {
  nr(e, function() {
    t.apply(this, arguments);
  }, n);
}, count: function(e) {
  var t = 0;
  return nr(e, function() {
    t++;
  }), t;
}, toArray: function(e) {
  return nr(e, function(t) {
    return t;
  }) || [];
}, only: function(e) {
  if (!Ho(e)) throw Error("React.Children.only expected to receive a single React element child.");
  return e;
} };
R.Component = on;
R.Fragment = ac;
R.Profiler = fc;
R.PureComponent = Ao;
R.StrictMode = cc;
R.Suspense = hc;
R.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ec;
R.act = ts;
R.cloneElement = function(e, t, n) {
  if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
  var r = Gi({}, e.props), l = e.key, o = e.ref, u = e._owner;
  if (t != null) {
    if (t.ref !== void 0 && (o = t.ref, u = Wo.current), t.key !== void 0 && (l = "" + t.key), e.type && e.type.defaultProps) var i = e.type.defaultProps;
    for (s in t) qi.call(t, s) && !bi.hasOwnProperty(s) && (r[s] = t[s] === void 0 && i !== void 0 ? i[s] : t[s]);
  }
  var s = arguments.length - 2;
  if (s === 1) r.children = n;
  else if (1 < s) {
    i = Array(s);
    for (var a = 0; a < s; a++) i[a] = arguments[a + 2];
    r.children = i;
  }
  return { $$typeof: Gn, type: e.type, key: l, ref: o, props: r, _owner: u };
};
R.createContext = function(e) {
  return e = { $$typeof: pc, _currentValue: e, _currentValue2: e, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, e.Provider = { $$typeof: dc, _context: e }, e.Consumer = e;
};
R.createElement = es;
R.createFactory = function(e) {
  var t = es.bind(null, e);
  return t.type = e, t;
};
R.createRef = function() {
  return { current: null };
};
R.forwardRef = function(e) {
  return { $$typeof: mc, render: e };
};
R.isValidElement = Ho;
R.lazy = function(e) {
  return { $$typeof: gc, _payload: { _status: -1, _result: e }, _init: Sc };
};
R.memo = function(e, t) {
  return { $$typeof: vc, type: e, compare: t === void 0 ? null : t };
};
R.startTransition = function(e) {
  var t = kr.transition;
  kr.transition = {};
  try {
    e();
  } finally {
    kr.transition = t;
  }
};
R.unstable_act = ts;
R.useCallback = function(e, t) {
  return ae.current.useCallback(e, t);
};
R.useContext = function(e) {
  return ae.current.useContext(e);
};
R.useDebugValue = function() {
};
R.useDeferredValue = function(e) {
  return ae.current.useDeferredValue(e);
};
R.useEffect = function(e, t) {
  return ae.current.useEffect(e, t);
};
R.useId = function() {
  return ae.current.useId();
};
R.useImperativeHandle = function(e, t, n) {
  return ae.current.useImperativeHandle(e, t, n);
};
R.useInsertionEffect = function(e, t) {
  return ae.current.useInsertionEffect(e, t);
};
R.useLayoutEffect = function(e, t) {
  return ae.current.useLayoutEffect(e, t);
};
R.useMemo = function(e, t) {
  return ae.current.useMemo(e, t);
};
R.useReducer = function(e, t, n) {
  return ae.current.useReducer(e, t, n);
};
R.useRef = function(e) {
  return ae.current.useRef(e);
};
R.useState = function(e) {
  return ae.current.useState(e);
};
R.useSyncExternalStore = function(e, t, n) {
  return ae.current.useSyncExternalStore(e, t, n);
};
R.useTransition = function() {
  return ae.current.useTransition();
};
R.version = "18.3.1";
Xi.exports = R;
var W = Xi.exports;
const _c = /* @__PURE__ */ Ki(W);
var ns = { exports: {} }, ke = {}, rs = { exports: {} }, ls = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
  function t(_, T) {
    var L = _.length;
    _.push(T);
    e: for (; 0 < L; ) {
      var Q = L - 1 >>> 1, Z = _[Q];
      if (0 < l(Z, T)) _[Q] = T, _[L] = Z, L = Q;
      else break e;
    }
  }
  function n(_) {
    return _.length === 0 ? null : _[0];
  }
  function r(_) {
    if (_.length === 0) return null;
    var T = _[0], L = _.pop();
    if (L !== T) {
      _[0] = L;
      e: for (var Q = 0, Z = _.length, er = Z >>> 1; Q < er; ) {
        var gt = 2 * (Q + 1) - 1, wl = _[gt], yt = gt + 1, tr = _[yt];
        if (0 > l(wl, L)) yt < Z && 0 > l(tr, wl) ? (_[Q] = tr, _[yt] = L, Q = yt) : (_[Q] = wl, _[gt] = L, Q = gt);
        else if (yt < Z && 0 > l(tr, L)) _[Q] = tr, _[yt] = L, Q = yt;
        else break e;
      }
    }
    return T;
  }
  function l(_, T) {
    var L = _.sortIndex - T.sortIndex;
    return L !== 0 ? L : _.id - T.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var o = performance;
    e.unstable_now = function() {
      return o.now();
    };
  } else {
    var u = Date, i = u.now();
    e.unstable_now = function() {
      return u.now() - i;
    };
  }
  var s = [], a = [], m = 1, p = null, h = 3, v = !1, w = !1, k = !1, O = typeof setTimeout == "function" ? setTimeout : null, f = typeof clearTimeout == "function" ? clearTimeout : null, c = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function d(_) {
    for (var T = n(a); T !== null; ) {
      if (T.callback === null) r(a);
      else if (T.startTime <= _) r(a), T.sortIndex = T.expirationTime, t(s, T);
      else break;
      T = n(a);
    }
  }
  function g(_) {
    if (k = !1, d(_), !w) if (n(s) !== null) w = !0, gl(S);
    else {
      var T = n(a);
      T !== null && yl(g, T.startTime - _);
    }
  }
  function S(_, T) {
    w = !1, k && (k = !1, f(P), P = -1), v = !0;
    var L = h;
    try {
      for (d(T), p = n(s); p !== null && (!(p.expirationTime > T) || _ && !b()); ) {
        var Q = p.callback;
        if (typeof Q == "function") {
          p.callback = null, h = p.priorityLevel;
          var Z = Q(p.expirationTime <= T);
          T = e.unstable_now(), typeof Z == "function" ? p.callback = Z : p === n(s) && r(s), d(T);
        } else r(s);
        p = n(s);
      }
      if (p !== null) var er = !0;
      else {
        var gt = n(a);
        gt !== null && yl(g, gt.startTime - T), er = !1;
      }
      return er;
    } finally {
      p = null, h = L, v = !1;
    }
  }
  var C = !1, x = null, P = -1, N = 5, z = -1;
  function b() {
    return !(e.unstable_now() - z < N);
  }
  function vt() {
    if (x !== null) {
      var _ = e.unstable_now();
      z = _;
      var T = !0;
      try {
        T = x(!0, _);
      } finally {
        T ? an() : (C = !1, x = null);
      }
    } else C = !1;
  }
  var an;
  if (typeof c == "function") an = function() {
    c(vt);
  };
  else if (typeof MessageChannel < "u") {
    var ju = new MessageChannel(), ic = ju.port2;
    ju.port1.onmessage = vt, an = function() {
      ic.postMessage(null);
    };
  } else an = function() {
    O(vt, 0);
  };
  function gl(_) {
    x = _, C || (C = !0, an());
  }
  function yl(_, T) {
    P = O(function() {
      _(e.unstable_now());
    }, T);
  }
  e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(_) {
    _.callback = null;
  }, e.unstable_continueExecution = function() {
    w || v || (w = !0, gl(S));
  }, e.unstable_forceFrameRate = function(_) {
    0 > _ || 125 < _ ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : N = 0 < _ ? Math.floor(1e3 / _) : 5;
  }, e.unstable_getCurrentPriorityLevel = function() {
    return h;
  }, e.unstable_getFirstCallbackNode = function() {
    return n(s);
  }, e.unstable_next = function(_) {
    switch (h) {
      case 1:
      case 2:
      case 3:
        var T = 3;
        break;
      default:
        T = h;
    }
    var L = h;
    h = T;
    try {
      return _();
    } finally {
      h = L;
    }
  }, e.unstable_pauseExecution = function() {
  }, e.unstable_requestPaint = function() {
  }, e.unstable_runWithPriority = function(_, T) {
    switch (_) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        _ = 3;
    }
    var L = h;
    h = _;
    try {
      return T();
    } finally {
      h = L;
    }
  }, e.unstable_scheduleCallback = function(_, T, L) {
    var Q = e.unstable_now();
    switch (typeof L == "object" && L !== null ? (L = L.delay, L = typeof L == "number" && 0 < L ? Q + L : Q) : L = Q, _) {
      case 1:
        var Z = -1;
        break;
      case 2:
        Z = 250;
        break;
      case 5:
        Z = 1073741823;
        break;
      case 4:
        Z = 1e4;
        break;
      default:
        Z = 5e3;
    }
    return Z = L + Z, _ = { id: m++, callback: T, priorityLevel: _, startTime: L, expirationTime: Z, sortIndex: -1 }, L > Q ? (_.sortIndex = L, t(a, _), n(s) === null && _ === n(a) && (k ? (f(P), P = -1) : k = !0, yl(g, L - Q))) : (_.sortIndex = Z, t(s, _), w || v || (w = !0, gl(S))), _;
  }, e.unstable_shouldYield = b, e.unstable_wrapCallback = function(_) {
    var T = h;
    return function() {
      var L = h;
      h = T;
      try {
        return _.apply(this, arguments);
      } finally {
        h = L;
      }
    };
  };
})(ls);
rs.exports = ls;
var Cc = rs.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var xc = W, we = Cc;
function y(e) {
  for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
  return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var os = /* @__PURE__ */ new Set(), Mn = {};
function Rt(e, t) {
  qt(e, t), qt(e + "Capture", t);
}
function qt(e, t) {
  for (Mn[e] = t, e = 0; e < t.length; e++) os.add(t[e]);
}
var Qe = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Xl = Object.prototype.hasOwnProperty, Pc = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, Bu = {}, $u = {};
function Nc(e) {
  return Xl.call($u, e) ? !0 : Xl.call(Bu, e) ? !1 : Pc.test(e) ? $u[e] = !0 : (Bu[e] = !0, !1);
}
function Tc(e, t, n, r) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof t) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
    default:
      return !1;
  }
}
function zc(e, t, n, r) {
  if (t === null || typeof t > "u" || Tc(e, t, n, r)) return !0;
  if (r) return !1;
  if (n !== null) switch (n.type) {
    case 3:
      return !t;
    case 4:
      return t === !1;
    case 5:
      return isNaN(t);
    case 6:
      return isNaN(t) || 1 > t;
  }
  return !1;
}
function ce(e, t, n, r, l, o, u) {
  this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = l, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = u;
}
var ne = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
  ne[e] = new ce(e, 0, !1, e, null, !1, !1);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
  var t = e[0];
  ne[t] = new ce(t, 1, !1, e[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
  ne[e] = new ce(e, 2, !1, e.toLowerCase(), null, !1, !1);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
  ne[e] = new ce(e, 2, !1, e, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
  ne[e] = new ce(e, 3, !1, e.toLowerCase(), null, !1, !1);
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
  ne[e] = new ce(e, 3, !0, e, null, !1, !1);
});
["capture", "download"].forEach(function(e) {
  ne[e] = new ce(e, 4, !1, e, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function(e) {
  ne[e] = new ce(e, 6, !1, e, null, !1, !1);
});
["rowSpan", "start"].forEach(function(e) {
  ne[e] = new ce(e, 5, !1, e.toLowerCase(), null, !1, !1);
});
var Qo = /[\-:]([a-z])/g;
function Ko(e) {
  return e[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
  var t = e.replace(
    Qo,
    Ko
  );
  ne[t] = new ce(t, 1, !1, e, null, !1, !1);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
  var t = e.replace(Qo, Ko);
  ne[t] = new ce(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
  var t = e.replace(Qo, Ko);
  ne[t] = new ce(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function(e) {
  ne[e] = new ce(e, 1, !1, e.toLowerCase(), null, !1, !1);
});
ne.xlinkHref = new ce("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
  ne[e] = new ce(e, 1, !1, e.toLowerCase(), null, !0, !0);
});
function Xo(e, t, n, r) {
  var l = ne.hasOwnProperty(t) ? ne[t] : null;
  (l !== null ? l.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (zc(t, n, l, r) && (n = null), r || l === null ? Nc(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : l.mustUseProperty ? e[l.propertyName] = n === null ? l.type === 3 ? !1 : "" : n : (t = l.attributeName, r = l.attributeNamespace, n === null ? e.removeAttribute(t) : (l = l.type, n = l === 3 || l === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
}
var Ge = xc.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, rr = Symbol.for("react.element"), It = Symbol.for("react.portal"), jt = Symbol.for("react.fragment"), Yo = Symbol.for("react.strict_mode"), Yl = Symbol.for("react.profiler"), us = Symbol.for("react.provider"), is = Symbol.for("react.context"), Go = Symbol.for("react.forward_ref"), Gl = Symbol.for("react.suspense"), Zl = Symbol.for("react.suspense_list"), Zo = Symbol.for("react.memo"), Je = Symbol.for("react.lazy"), ss = Symbol.for("react.offscreen"), Au = Symbol.iterator;
function cn(e) {
  return e === null || typeof e != "object" ? null : (e = Au && e[Au] || e["@@iterator"], typeof e == "function" ? e : null);
}
var V = Object.assign, Sl;
function wn(e) {
  if (Sl === void 0) try {
    throw Error();
  } catch (n) {
    var t = n.stack.trim().match(/\n( *(at )?)/);
    Sl = t && t[1] || "";
  }
  return `
` + Sl + e;
}
var El = !1;
function _l(e, t) {
  if (!e || El) return "";
  El = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (t) if (t = function() {
      throw Error();
    }, Object.defineProperty(t.prototype, "props", { set: function() {
      throw Error();
    } }), typeof Reflect == "object" && Reflect.construct) {
      try {
        Reflect.construct(t, []);
      } catch (a) {
        var r = a;
      }
      Reflect.construct(e, [], t);
    } else {
      try {
        t.call();
      } catch (a) {
        r = a;
      }
      e.call(t.prototype);
    }
    else {
      try {
        throw Error();
      } catch (a) {
        r = a;
      }
      e();
    }
  } catch (a) {
    if (a && r && typeof a.stack == "string") {
      for (var l = a.stack.split(`
`), o = r.stack.split(`
`), u = l.length - 1, i = o.length - 1; 1 <= u && 0 <= i && l[u] !== o[i]; ) i--;
      for (; 1 <= u && 0 <= i; u--, i--) if (l[u] !== o[i]) {
        if (u !== 1 || i !== 1)
          do
            if (u--, i--, 0 > i || l[u] !== o[i]) {
              var s = `
` + l[u].replace(" at new ", " at ");
              return e.displayName && s.includes("<anonymous>") && (s = s.replace("<anonymous>", e.displayName)), s;
            }
          while (1 <= u && 0 <= i);
        break;
      }
    }
  } finally {
    El = !1, Error.prepareStackTrace = n;
  }
  return (e = e ? e.displayName || e.name : "") ? wn(e) : "";
}
function Lc(e) {
  switch (e.tag) {
    case 5:
      return wn(e.type);
    case 16:
      return wn("Lazy");
    case 13:
      return wn("Suspense");
    case 19:
      return wn("SuspenseList");
    case 0:
    case 2:
    case 15:
      return e = _l(e.type, !1), e;
    case 11:
      return e = _l(e.type.render, !1), e;
    case 1:
      return e = _l(e.type, !0), e;
    default:
      return "";
  }
}
function Jl(e) {
  if (e == null) return null;
  if (typeof e == "function") return e.displayName || e.name || null;
  if (typeof e == "string") return e;
  switch (e) {
    case jt:
      return "Fragment";
    case It:
      return "Portal";
    case Yl:
      return "Profiler";
    case Yo:
      return "StrictMode";
    case Gl:
      return "Suspense";
    case Zl:
      return "SuspenseList";
  }
  if (typeof e == "object") switch (e.$$typeof) {
    case is:
      return (e.displayName || "Context") + ".Consumer";
    case us:
      return (e._context.displayName || "Context") + ".Provider";
    case Go:
      var t = e.render;
      return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
    case Zo:
      return t = e.displayName || null, t !== null ? t : Jl(e.type) || "Memo";
    case Je:
      t = e._payload, e = e._init;
      try {
        return Jl(e(t));
      } catch {
      }
  }
  return null;
}
function Rc(e) {
  var t = e.type;
  switch (e.tag) {
    case 24:
      return "Cache";
    case 9:
      return (t.displayName || "Context") + ".Consumer";
    case 10:
      return (t._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return t;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Jl(t);
    case 8:
      return t === Yo ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
  }
  return null;
}
function ft(e) {
  switch (typeof e) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return e;
    case "object":
      return e;
    default:
      return "";
  }
}
function as(e) {
  var t = e.type;
  return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
}
function Mc(e) {
  var t = as(e) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t), r = "" + e[t];
  if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
    var l = n.get, o = n.set;
    return Object.defineProperty(e, t, { configurable: !0, get: function() {
      return l.call(this);
    }, set: function(u) {
      r = "" + u, o.call(this, u);
    } }), Object.defineProperty(e, t, { enumerable: n.enumerable }), { getValue: function() {
      return r;
    }, setValue: function(u) {
      r = "" + u;
    }, stopTracking: function() {
      e._valueTracker = null, delete e[t];
    } };
  }
}
function lr(e) {
  e._valueTracker || (e._valueTracker = Mc(e));
}
function cs(e) {
  if (!e) return !1;
  var t = e._valueTracker;
  if (!t) return !0;
  var n = t.getValue(), r = "";
  return e && (r = as(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1;
}
function Rr(e) {
  if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
  try {
    return e.activeElement || e.body;
  } catch {
    return e.body;
  }
}
function ql(e, t) {
  var n = t.checked;
  return V({}, t, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: n ?? e._wrapperState.initialChecked });
}
function Vu(e, t) {
  var n = t.defaultValue == null ? "" : t.defaultValue, r = t.checked != null ? t.checked : t.defaultChecked;
  n = ft(t.value != null ? t.value : n), e._wrapperState = { initialChecked: r, initialValue: n, controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null };
}
function fs(e, t) {
  t = t.checked, t != null && Xo(e, "checked", t, !1);
}
function bl(e, t) {
  fs(e, t);
  var n = ft(t.value), r = t.type;
  if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
  else if (r === "submit" || r === "reset") {
    e.removeAttribute("value");
    return;
  }
  t.hasOwnProperty("value") ? eo(e, t.type, n) : t.hasOwnProperty("defaultValue") && eo(e, t.type, ft(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked);
}
function Wu(e, t, n) {
  if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
    var r = t.type;
    if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
    t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t;
  }
  n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n);
}
function eo(e, t, n) {
  (t !== "number" || Rr(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
}
var kn = Array.isArray;
function Kt(e, t, n, r) {
  if (e = e.options, t) {
    t = {};
    for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
    for (n = 0; n < e.length; n++) l = t.hasOwnProperty("$" + e[n].value), e[n].selected !== l && (e[n].selected = l), l && r && (e[n].defaultSelected = !0);
  } else {
    for (n = "" + ft(n), t = null, l = 0; l < e.length; l++) {
      if (e[l].value === n) {
        e[l].selected = !0, r && (e[l].defaultSelected = !0);
        return;
      }
      t !== null || e[l].disabled || (t = e[l]);
    }
    t !== null && (t.selected = !0);
  }
}
function to(e, t) {
  if (t.dangerouslySetInnerHTML != null) throw Error(y(91));
  return V({}, t, { value: void 0, defaultValue: void 0, children: "" + e._wrapperState.initialValue });
}
function Hu(e, t) {
  var n = t.value;
  if (n == null) {
    if (n = t.children, t = t.defaultValue, n != null) {
      if (t != null) throw Error(y(92));
      if (kn(n)) {
        if (1 < n.length) throw Error(y(93));
        n = n[0];
      }
      t = n;
    }
    t == null && (t = ""), n = t;
  }
  e._wrapperState = { initialValue: ft(n) };
}
function ds(e, t) {
  var n = ft(t.value), r = ft(t.defaultValue);
  n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r);
}
function Qu(e) {
  var t = e.textContent;
  t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t);
}
function ps(e) {
  switch (e) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function no(e, t) {
  return e == null || e === "http://www.w3.org/1999/xhtml" ? ps(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e;
}
var or, ms = function(e) {
  return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, l) {
    MSApp.execUnsafeLocalFunction(function() {
      return e(t, n, r, l);
    });
  } : e;
}(function(e, t) {
  if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
  else {
    for (or = or || document.createElement("div"), or.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = or.firstChild; e.firstChild; ) e.removeChild(e.firstChild);
    for (; t.firstChild; ) e.appendChild(t.firstChild);
  }
});
function On(e, t) {
  if (t) {
    var n = e.firstChild;
    if (n && n === e.lastChild && n.nodeType === 3) {
      n.nodeValue = t;
      return;
    }
  }
  e.textContent = t;
}
var _n = {
  animationIterationCount: !0,
  aspectRatio: !0,
  borderImageOutset: !0,
  borderImageSlice: !0,
  borderImageWidth: !0,
  boxFlex: !0,
  boxFlexGroup: !0,
  boxOrdinalGroup: !0,
  columnCount: !0,
  columns: !0,
  flex: !0,
  flexGrow: !0,
  flexPositive: !0,
  flexShrink: !0,
  flexNegative: !0,
  flexOrder: !0,
  gridArea: !0,
  gridRow: !0,
  gridRowEnd: !0,
  gridRowSpan: !0,
  gridRowStart: !0,
  gridColumn: !0,
  gridColumnEnd: !0,
  gridColumnSpan: !0,
  gridColumnStart: !0,
  fontWeight: !0,
  lineClamp: !0,
  lineHeight: !0,
  opacity: !0,
  order: !0,
  orphans: !0,
  tabSize: !0,
  widows: !0,
  zIndex: !0,
  zoom: !0,
  fillOpacity: !0,
  floodOpacity: !0,
  stopOpacity: !0,
  strokeDasharray: !0,
  strokeDashoffset: !0,
  strokeMiterlimit: !0,
  strokeOpacity: !0,
  strokeWidth: !0
}, Oc = ["Webkit", "ms", "Moz", "O"];
Object.keys(_n).forEach(function(e) {
  Oc.forEach(function(t) {
    t = t + e.charAt(0).toUpperCase() + e.substring(1), _n[t] = _n[e];
  });
});
function hs(e, t, n) {
  return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || _n.hasOwnProperty(e) && _n[e] ? ("" + t).trim() : t + "px";
}
function vs(e, t) {
  e = e.style;
  for (var n in t) if (t.hasOwnProperty(n)) {
    var r = n.indexOf("--") === 0, l = hs(n, t[n], r);
    n === "float" && (n = "cssFloat"), r ? e.setProperty(n, l) : e[n] = l;
  }
}
var Ic = V({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });
function ro(e, t) {
  if (t) {
    if (Ic[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(y(137, e));
    if (t.dangerouslySetInnerHTML != null) {
      if (t.children != null) throw Error(y(60));
      if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(y(61));
    }
    if (t.style != null && typeof t.style != "object") throw Error(y(62));
  }
}
function lo(e, t) {
  if (e.indexOf("-") === -1) return typeof t.is == "string";
  switch (e) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var oo = null;
function Jo(e) {
  return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
}
var uo = null, Xt = null, Yt = null;
function Ku(e) {
  if (e = qn(e)) {
    if (typeof uo != "function") throw Error(y(280));
    var t = e.stateNode;
    t && (t = ol(t), uo(e.stateNode, e.type, t));
  }
}
function gs(e) {
  Xt ? Yt ? Yt.push(e) : Yt = [e] : Xt = e;
}
function ys() {
  if (Xt) {
    var e = Xt, t = Yt;
    if (Yt = Xt = null, Ku(e), t) for (e = 0; e < t.length; e++) Ku(t[e]);
  }
}
function ws(e, t) {
  return e(t);
}
function ks() {
}
var Cl = !1;
function Ss(e, t, n) {
  if (Cl) return e(t, n);
  Cl = !0;
  try {
    return ws(e, t, n);
  } finally {
    Cl = !1, (Xt !== null || Yt !== null) && (ks(), ys());
  }
}
function In(e, t) {
  var n = e.stateNode;
  if (n === null) return null;
  var r = ol(n);
  if (r === null) return null;
  n = r[t];
  e: switch (t) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
      break e;
    default:
      e = !1;
  }
  if (e) return null;
  if (n && typeof n != "function") throw Error(y(231, t, typeof n));
  return n;
}
var io = !1;
if (Qe) try {
  var fn = {};
  Object.defineProperty(fn, "passive", { get: function() {
    io = !0;
  } }), window.addEventListener("test", fn, fn), window.removeEventListener("test", fn, fn);
} catch {
  io = !1;
}
function jc(e, t, n, r, l, o, u, i, s) {
  var a = Array.prototype.slice.call(arguments, 3);
  try {
    t.apply(n, a);
  } catch (m) {
    this.onError(m);
  }
}
var Cn = !1, Mr = null, Or = !1, so = null, Dc = { onError: function(e) {
  Cn = !0, Mr = e;
} };
function Fc(e, t, n, r, l, o, u, i, s) {
  Cn = !1, Mr = null, jc.apply(Dc, arguments);
}
function Uc(e, t, n, r, l, o, u, i, s) {
  if (Fc.apply(this, arguments), Cn) {
    if (Cn) {
      var a = Mr;
      Cn = !1, Mr = null;
    } else throw Error(y(198));
    Or || (Or = !0, so = a);
  }
}
function Mt(e) {
  var t = e, n = e;
  if (e.alternate) for (; t.return; ) t = t.return;
  else {
    e = t;
    do
      t = e, t.flags & 4098 && (n = t.return), e = t.return;
    while (e);
  }
  return t.tag === 3 ? n : null;
}
function Es(e) {
  if (e.tag === 13) {
    var t = e.memoizedState;
    if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
  }
  return null;
}
function Xu(e) {
  if (Mt(e) !== e) throw Error(y(188));
}
function Bc(e) {
  var t = e.alternate;
  if (!t) {
    if (t = Mt(e), t === null) throw Error(y(188));
    return t !== e ? null : e;
  }
  for (var n = e, r = t; ; ) {
    var l = n.return;
    if (l === null) break;
    var o = l.alternate;
    if (o === null) {
      if (r = l.return, r !== null) {
        n = r;
        continue;
      }
      break;
    }
    if (l.child === o.child) {
      for (o = l.child; o; ) {
        if (o === n) return Xu(l), e;
        if (o === r) return Xu(l), t;
        o = o.sibling;
      }
      throw Error(y(188));
    }
    if (n.return !== r.return) n = l, r = o;
    else {
      for (var u = !1, i = l.child; i; ) {
        if (i === n) {
          u = !0, n = l, r = o;
          break;
        }
        if (i === r) {
          u = !0, r = l, n = o;
          break;
        }
        i = i.sibling;
      }
      if (!u) {
        for (i = o.child; i; ) {
          if (i === n) {
            u = !0, n = o, r = l;
            break;
          }
          if (i === r) {
            u = !0, r = o, n = l;
            break;
          }
          i = i.sibling;
        }
        if (!u) throw Error(y(189));
      }
    }
    if (n.alternate !== r) throw Error(y(190));
  }
  if (n.tag !== 3) throw Error(y(188));
  return n.stateNode.current === n ? e : t;
}
function _s(e) {
  return e = Bc(e), e !== null ? Cs(e) : null;
}
function Cs(e) {
  if (e.tag === 5 || e.tag === 6) return e;
  for (e = e.child; e !== null; ) {
    var t = Cs(e);
    if (t !== null) return t;
    e = e.sibling;
  }
  return null;
}
var xs = we.unstable_scheduleCallback, Yu = we.unstable_cancelCallback, $c = we.unstable_shouldYield, Ac = we.unstable_requestPaint, K = we.unstable_now, Vc = we.unstable_getCurrentPriorityLevel, qo = we.unstable_ImmediatePriority, Ps = we.unstable_UserBlockingPriority, Ir = we.unstable_NormalPriority, Wc = we.unstable_LowPriority, Ns = we.unstable_IdlePriority, tl = null, Ue = null;
function Hc(e) {
  if (Ue && typeof Ue.onCommitFiberRoot == "function") try {
    Ue.onCommitFiberRoot(tl, e, void 0, (e.current.flags & 128) === 128);
  } catch {
  }
}
var Me = Math.clz32 ? Math.clz32 : Xc, Qc = Math.log, Kc = Math.LN2;
function Xc(e) {
  return e >>>= 0, e === 0 ? 32 : 31 - (Qc(e) / Kc | 0) | 0;
}
var ur = 64, ir = 4194304;
function Sn(e) {
  switch (e & -e) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return e & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return e;
  }
}
function jr(e, t) {
  var n = e.pendingLanes;
  if (n === 0) return 0;
  var r = 0, l = e.suspendedLanes, o = e.pingedLanes, u = n & 268435455;
  if (u !== 0) {
    var i = u & ~l;
    i !== 0 ? r = Sn(i) : (o &= u, o !== 0 && (r = Sn(o)));
  } else u = n & ~l, u !== 0 ? r = Sn(u) : o !== 0 && (r = Sn(o));
  if (r === 0) return 0;
  if (t !== 0 && t !== r && !(t & l) && (l = r & -r, o = t & -t, l >= o || l === 16 && (o & 4194240) !== 0)) return t;
  if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0) for (e = e.entanglements, t &= r; 0 < t; ) n = 31 - Me(t), l = 1 << n, r |= e[n], t &= ~l;
  return r;
}
function Yc(e, t) {
  switch (e) {
    case 1:
    case 2:
    case 4:
      return t + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function Gc(e, t) {
  for (var n = e.suspendedLanes, r = e.pingedLanes, l = e.expirationTimes, o = e.pendingLanes; 0 < o; ) {
    var u = 31 - Me(o), i = 1 << u, s = l[u];
    s === -1 ? (!(i & n) || i & r) && (l[u] = Yc(i, t)) : s <= t && (e.expiredLanes |= i), o &= ~i;
  }
}
function ao(e) {
  return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0;
}
function Ts() {
  var e = ur;
  return ur <<= 1, !(ur & 4194240) && (ur = 64), e;
}
function xl(e) {
  for (var t = [], n = 0; 31 > n; n++) t.push(e);
  return t;
}
function Zn(e, t, n) {
  e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Me(t), e[t] = n;
}
function Zc(e, t) {
  var n = e.pendingLanes & ~t;
  e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
  var r = e.eventTimes;
  for (e = e.expirationTimes; 0 < n; ) {
    var l = 31 - Me(n), o = 1 << l;
    t[l] = 0, r[l] = -1, e[l] = -1, n &= ~o;
  }
}
function bo(e, t) {
  var n = e.entangledLanes |= t;
  for (e = e.entanglements; n; ) {
    var r = 31 - Me(n), l = 1 << r;
    l & t | e[r] & t && (e[r] |= t), n &= ~l;
  }
}
var j = 0;
function zs(e) {
  return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1;
}
var Ls, eu, Rs, Ms, Os, co = !1, sr = [], rt = null, lt = null, ot = null, jn = /* @__PURE__ */ new Map(), Dn = /* @__PURE__ */ new Map(), be = [], Jc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Gu(e, t) {
  switch (e) {
    case "focusin":
    case "focusout":
      rt = null;
      break;
    case "dragenter":
    case "dragleave":
      lt = null;
      break;
    case "mouseover":
    case "mouseout":
      ot = null;
      break;
    case "pointerover":
    case "pointerout":
      jn.delete(t.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      Dn.delete(t.pointerId);
  }
}
function dn(e, t, n, r, l, o) {
  return e === null || e.nativeEvent !== o ? (e = { blockedOn: t, domEventName: n, eventSystemFlags: r, nativeEvent: o, targetContainers: [l] }, t !== null && (t = qn(t), t !== null && eu(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, l !== null && t.indexOf(l) === -1 && t.push(l), e);
}
function qc(e, t, n, r, l) {
  switch (t) {
    case "focusin":
      return rt = dn(rt, e, t, n, r, l), !0;
    case "dragenter":
      return lt = dn(lt, e, t, n, r, l), !0;
    case "mouseover":
      return ot = dn(ot, e, t, n, r, l), !0;
    case "pointerover":
      var o = l.pointerId;
      return jn.set(o, dn(jn.get(o) || null, e, t, n, r, l)), !0;
    case "gotpointercapture":
      return o = l.pointerId, Dn.set(o, dn(Dn.get(o) || null, e, t, n, r, l)), !0;
  }
  return !1;
}
function Is(e) {
  var t = St(e.target);
  if (t !== null) {
    var n = Mt(t);
    if (n !== null) {
      if (t = n.tag, t === 13) {
        if (t = Es(n), t !== null) {
          e.blockedOn = t, Os(e.priority, function() {
            Rs(n);
          });
          return;
        }
      } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  e.blockedOn = null;
}
function Sr(e) {
  if (e.blockedOn !== null) return !1;
  for (var t = e.targetContainers; 0 < t.length; ) {
    var n = fo(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
    if (n === null) {
      n = e.nativeEvent;
      var r = new n.constructor(n.type, n);
      oo = r, n.target.dispatchEvent(r), oo = null;
    } else return t = qn(n), t !== null && eu(t), e.blockedOn = n, !1;
    t.shift();
  }
  return !0;
}
function Zu(e, t, n) {
  Sr(e) && n.delete(t);
}
function bc() {
  co = !1, rt !== null && Sr(rt) && (rt = null), lt !== null && Sr(lt) && (lt = null), ot !== null && Sr(ot) && (ot = null), jn.forEach(Zu), Dn.forEach(Zu);
}
function pn(e, t) {
  e.blockedOn === t && (e.blockedOn = null, co || (co = !0, we.unstable_scheduleCallback(we.unstable_NormalPriority, bc)));
}
function Fn(e) {
  function t(l) {
    return pn(l, e);
  }
  if (0 < sr.length) {
    pn(sr[0], e);
    for (var n = 1; n < sr.length; n++) {
      var r = sr[n];
      r.blockedOn === e && (r.blockedOn = null);
    }
  }
  for (rt !== null && pn(rt, e), lt !== null && pn(lt, e), ot !== null && pn(ot, e), jn.forEach(t), Dn.forEach(t), n = 0; n < be.length; n++) r = be[n], r.blockedOn === e && (r.blockedOn = null);
  for (; 0 < be.length && (n = be[0], n.blockedOn === null); ) Is(n), n.blockedOn === null && be.shift();
}
var Gt = Ge.ReactCurrentBatchConfig, Dr = !0;
function ef(e, t, n, r) {
  var l = j, o = Gt.transition;
  Gt.transition = null;
  try {
    j = 1, tu(e, t, n, r);
  } finally {
    j = l, Gt.transition = o;
  }
}
function tf(e, t, n, r) {
  var l = j, o = Gt.transition;
  Gt.transition = null;
  try {
    j = 4, tu(e, t, n, r);
  } finally {
    j = l, Gt.transition = o;
  }
}
function tu(e, t, n, r) {
  if (Dr) {
    var l = fo(e, t, n, r);
    if (l === null) jl(e, t, r, Fr, n), Gu(e, r);
    else if (qc(l, e, t, n, r)) r.stopPropagation();
    else if (Gu(e, r), t & 4 && -1 < Jc.indexOf(e)) {
      for (; l !== null; ) {
        var o = qn(l);
        if (o !== null && Ls(o), o = fo(e, t, n, r), o === null && jl(e, t, r, Fr, n), o === l) break;
        l = o;
      }
      l !== null && r.stopPropagation();
    } else jl(e, t, r, null, n);
  }
}
var Fr = null;
function fo(e, t, n, r) {
  if (Fr = null, e = Jo(r), e = St(e), e !== null) if (t = Mt(e), t === null) e = null;
  else if (n = t.tag, n === 13) {
    if (e = Es(t), e !== null) return e;
    e = null;
  } else if (n === 3) {
    if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
    e = null;
  } else t !== e && (e = null);
  return Fr = e, null;
}
function js(e) {
  switch (e) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (Vc()) {
        case qo:
          return 1;
        case Ps:
          return 4;
        case Ir:
        case Wc:
          return 16;
        case Ns:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var tt = null, nu = null, Er = null;
function Ds() {
  if (Er) return Er;
  var e, t = nu, n = t.length, r, l = "value" in tt ? tt.value : tt.textContent, o = l.length;
  for (e = 0; e < n && t[e] === l[e]; e++) ;
  var u = n - e;
  for (r = 1; r <= u && t[n - r] === l[o - r]; r++) ;
  return Er = l.slice(e, 1 < r ? 1 - r : void 0);
}
function _r(e) {
  var t = e.keyCode;
  return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
}
function ar() {
  return !0;
}
function Ju() {
  return !1;
}
function Se(e) {
  function t(n, r, l, o, u) {
    this._reactName = n, this._targetInst = l, this.type = r, this.nativeEvent = o, this.target = u, this.currentTarget = null;
    for (var i in e) e.hasOwnProperty(i) && (n = e[i], this[i] = n ? n(o) : o[i]);
    return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? ar : Ju, this.isPropagationStopped = Ju, this;
  }
  return V(t.prototype, { preventDefault: function() {
    this.defaultPrevented = !0;
    var n = this.nativeEvent;
    n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = ar);
  }, stopPropagation: function() {
    var n = this.nativeEvent;
    n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = ar);
  }, persist: function() {
  }, isPersistent: ar }), t;
}
var un = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(e) {
  return e.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0 }, ru = Se(un), Jn = V({}, un, { view: 0, detail: 0 }), nf = Se(Jn), Pl, Nl, mn, nl = V({}, Jn, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: lu, button: 0, buttons: 0, relatedTarget: function(e) {
  return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
}, movementX: function(e) {
  return "movementX" in e ? e.movementX : (e !== mn && (mn && e.type === "mousemove" ? (Pl = e.screenX - mn.screenX, Nl = e.screenY - mn.screenY) : Nl = Pl = 0, mn = e), Pl);
}, movementY: function(e) {
  return "movementY" in e ? e.movementY : Nl;
} }), qu = Se(nl), rf = V({}, nl, { dataTransfer: 0 }), lf = Se(rf), of = V({}, Jn, { relatedTarget: 0 }), Tl = Se(of), uf = V({}, un, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), sf = Se(uf), af = V({}, un, { clipboardData: function(e) {
  return "clipboardData" in e ? e.clipboardData : window.clipboardData;
} }), cf = Se(af), ff = V({}, un, { data: 0 }), bu = Se(ff), df = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, pf = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, mf = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
function hf(e) {
  var t = this.nativeEvent;
  return t.getModifierState ? t.getModifierState(e) : (e = mf[e]) ? !!t[e] : !1;
}
function lu() {
  return hf;
}
var vf = V({}, Jn, { key: function(e) {
  if (e.key) {
    var t = df[e.key] || e.key;
    if (t !== "Unidentified") return t;
  }
  return e.type === "keypress" ? (e = _r(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? pf[e.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: lu, charCode: function(e) {
  return e.type === "keypress" ? _r(e) : 0;
}, keyCode: function(e) {
  return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
}, which: function(e) {
  return e.type === "keypress" ? _r(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
} }), gf = Se(vf), yf = V({}, nl, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), ei = Se(yf), wf = V({}, Jn, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: lu }), kf = Se(wf), Sf = V({}, un, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Ef = Se(Sf), _f = V({}, nl, {
  deltaX: function(e) {
    return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
  },
  deltaY: function(e) {
    return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), Cf = Se(_f), xf = [9, 13, 27, 32], ou = Qe && "CompositionEvent" in window, xn = null;
Qe && "documentMode" in document && (xn = document.documentMode);
var Pf = Qe && "TextEvent" in window && !xn, Fs = Qe && (!ou || xn && 8 < xn && 11 >= xn), ti = " ", ni = !1;
function Us(e, t) {
  switch (e) {
    case "keyup":
      return xf.indexOf(t.keyCode) !== -1;
    case "keydown":
      return t.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function Bs(e) {
  return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
}
var Dt = !1;
function Nf(e, t) {
  switch (e) {
    case "compositionend":
      return Bs(t);
    case "keypress":
      return t.which !== 32 ? null : (ni = !0, ti);
    case "textInput":
      return e = t.data, e === ti && ni ? null : e;
    default:
      return null;
  }
}
function Tf(e, t) {
  if (Dt) return e === "compositionend" || !ou && Us(e, t) ? (e = Ds(), Er = nu = tt = null, Dt = !1, e) : null;
  switch (e) {
    case "paste":
      return null;
    case "keypress":
      if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
        if (t.char && 1 < t.char.length) return t.char;
        if (t.which) return String.fromCharCode(t.which);
      }
      return null;
    case "compositionend":
      return Fs && t.locale !== "ko" ? null : t.data;
    default:
      return null;
  }
}
var zf = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };
function ri(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t === "input" ? !!zf[e.type] : t === "textarea";
}
function $s(e, t, n, r) {
  gs(r), t = Ur(t, "onChange"), 0 < t.length && (n = new ru("onChange", "change", null, n, r), e.push({ event: n, listeners: t }));
}
var Pn = null, Un = null;
function Lf(e) {
  Js(e, 0);
}
function rl(e) {
  var t = Bt(e);
  if (cs(t)) return e;
}
function Rf(e, t) {
  if (e === "change") return t;
}
var As = !1;
if (Qe) {
  var zl;
  if (Qe) {
    var Ll = "oninput" in document;
    if (!Ll) {
      var li = document.createElement("div");
      li.setAttribute("oninput", "return;"), Ll = typeof li.oninput == "function";
    }
    zl = Ll;
  } else zl = !1;
  As = zl && (!document.documentMode || 9 < document.documentMode);
}
function oi() {
  Pn && (Pn.detachEvent("onpropertychange", Vs), Un = Pn = null);
}
function Vs(e) {
  if (e.propertyName === "value" && rl(Un)) {
    var t = [];
    $s(t, Un, e, Jo(e)), Ss(Lf, t);
  }
}
function Mf(e, t, n) {
  e === "focusin" ? (oi(), Pn = t, Un = n, Pn.attachEvent("onpropertychange", Vs)) : e === "focusout" && oi();
}
function Of(e) {
  if (e === "selectionchange" || e === "keyup" || e === "keydown") return rl(Un);
}
function If(e, t) {
  if (e === "click") return rl(t);
}
function jf(e, t) {
  if (e === "input" || e === "change") return rl(t);
}
function Df(e, t) {
  return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
}
var Ie = typeof Object.is == "function" ? Object.is : Df;
function Bn(e, t) {
  if (Ie(e, t)) return !0;
  if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
  var n = Object.keys(e), r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (r = 0; r < n.length; r++) {
    var l = n[r];
    if (!Xl.call(t, l) || !Ie(e[l], t[l])) return !1;
  }
  return !0;
}
function ui(e) {
  for (; e && e.firstChild; ) e = e.firstChild;
  return e;
}
function ii(e, t) {
  var n = ui(e);
  e = 0;
  for (var r; n; ) {
    if (n.nodeType === 3) {
      if (r = e + n.textContent.length, e <= t && r >= t) return { node: n, offset: t - e };
      e = r;
    }
    e: {
      for (; n; ) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break e;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = ui(n);
  }
}
function Ws(e, t) {
  return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Ws(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1;
}
function Hs() {
  for (var e = window, t = Rr(); t instanceof e.HTMLIFrameElement; ) {
    try {
      var n = typeof t.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) e = t.contentWindow;
    else break;
    t = Rr(e.document);
  }
  return t;
}
function uu(e) {
  var t = e && e.nodeName && e.nodeName.toLowerCase();
  return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
}
function Ff(e) {
  var t = Hs(), n = e.focusedElem, r = e.selectionRange;
  if (t !== n && n && n.ownerDocument && Ws(n.ownerDocument.documentElement, n)) {
    if (r !== null && uu(n)) {
      if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
      else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
        e = e.getSelection();
        var l = n.textContent.length, o = Math.min(r.start, l);
        r = r.end === void 0 ? o : Math.min(r.end, l), !e.extend && o > r && (l = r, r = o, o = l), l = ii(n, o);
        var u = ii(
          n,
          r
        );
        l && u && (e.rangeCount !== 1 || e.anchorNode !== l.node || e.anchorOffset !== l.offset || e.focusNode !== u.node || e.focusOffset !== u.offset) && (t = t.createRange(), t.setStart(l.node, l.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(u.node, u.offset)) : (t.setEnd(u.node, u.offset), e.addRange(t)));
      }
    }
    for (t = [], e = n; e = e.parentNode; ) e.nodeType === 1 && t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top;
  }
}
var Uf = Qe && "documentMode" in document && 11 >= document.documentMode, Ft = null, po = null, Nn = null, mo = !1;
function si(e, t, n) {
  var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  mo || Ft == null || Ft !== Rr(r) || (r = Ft, "selectionStart" in r && uu(r) ? r = { start: r.selectionStart, end: r.selectionEnd } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = { anchorNode: r.anchorNode, anchorOffset: r.anchorOffset, focusNode: r.focusNode, focusOffset: r.focusOffset }), Nn && Bn(Nn, r) || (Nn = r, r = Ur(po, "onSelect"), 0 < r.length && (t = new ru("onSelect", "select", null, t, n), e.push({ event: t, listeners: r }), t.target = Ft)));
}
function cr(e, t) {
  var n = {};
  return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n;
}
var Ut = { animationend: cr("Animation", "AnimationEnd"), animationiteration: cr("Animation", "AnimationIteration"), animationstart: cr("Animation", "AnimationStart"), transitionend: cr("Transition", "TransitionEnd") }, Rl = {}, Qs = {};
Qe && (Qs = document.createElement("div").style, "AnimationEvent" in window || (delete Ut.animationend.animation, delete Ut.animationiteration.animation, delete Ut.animationstart.animation), "TransitionEvent" in window || delete Ut.transitionend.transition);
function ll(e) {
  if (Rl[e]) return Rl[e];
  if (!Ut[e]) return e;
  var t = Ut[e], n;
  for (n in t) if (t.hasOwnProperty(n) && n in Qs) return Rl[e] = t[n];
  return e;
}
var Ks = ll("animationend"), Xs = ll("animationiteration"), Ys = ll("animationstart"), Gs = ll("transitionend"), Zs = /* @__PURE__ */ new Map(), ai = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function pt(e, t) {
  Zs.set(e, t), Rt(t, [e]);
}
for (var Ml = 0; Ml < ai.length; Ml++) {
  var Ol = ai[Ml], Bf = Ol.toLowerCase(), $f = Ol[0].toUpperCase() + Ol.slice(1);
  pt(Bf, "on" + $f);
}
pt(Ks, "onAnimationEnd");
pt(Xs, "onAnimationIteration");
pt(Ys, "onAnimationStart");
pt("dblclick", "onDoubleClick");
pt("focusin", "onFocus");
pt("focusout", "onBlur");
pt(Gs, "onTransitionEnd");
qt("onMouseEnter", ["mouseout", "mouseover"]);
qt("onMouseLeave", ["mouseout", "mouseover"]);
qt("onPointerEnter", ["pointerout", "pointerover"]);
qt("onPointerLeave", ["pointerout", "pointerover"]);
Rt("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Rt("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Rt("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Rt("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Rt("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Rt("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var En = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), Af = new Set("cancel close invalid load scroll toggle".split(" ").concat(En));
function ci(e, t, n) {
  var r = e.type || "unknown-event";
  e.currentTarget = n, Uc(r, t, void 0, e), e.currentTarget = null;
}
function Js(e, t) {
  t = (t & 4) !== 0;
  for (var n = 0; n < e.length; n++) {
    var r = e[n], l = r.event;
    r = r.listeners;
    e: {
      var o = void 0;
      if (t) for (var u = r.length - 1; 0 <= u; u--) {
        var i = r[u], s = i.instance, a = i.currentTarget;
        if (i = i.listener, s !== o && l.isPropagationStopped()) break e;
        ci(l, i, a), o = s;
      }
      else for (u = 0; u < r.length; u++) {
        if (i = r[u], s = i.instance, a = i.currentTarget, i = i.listener, s !== o && l.isPropagationStopped()) break e;
        ci(l, i, a), o = s;
      }
    }
  }
  if (Or) throw e = so, Or = !1, so = null, e;
}
function F(e, t) {
  var n = t[wo];
  n === void 0 && (n = t[wo] = /* @__PURE__ */ new Set());
  var r = e + "__bubble";
  n.has(r) || (qs(t, e, 2, !1), n.add(r));
}
function Il(e, t, n) {
  var r = 0;
  t && (r |= 4), qs(n, e, r, t);
}
var fr = "_reactListening" + Math.random().toString(36).slice(2);
function $n(e) {
  if (!e[fr]) {
    e[fr] = !0, os.forEach(function(n) {
      n !== "selectionchange" && (Af.has(n) || Il(n, !1, e), Il(n, !0, e));
    });
    var t = e.nodeType === 9 ? e : e.ownerDocument;
    t === null || t[fr] || (t[fr] = !0, Il("selectionchange", !1, t));
  }
}
function qs(e, t, n, r) {
  switch (js(t)) {
    case 1:
      var l = ef;
      break;
    case 4:
      l = tf;
      break;
    default:
      l = tu;
  }
  n = l.bind(null, t, n, e), l = void 0, !io || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (l = !0), r ? l !== void 0 ? e.addEventListener(t, n, { capture: !0, passive: l }) : e.addEventListener(t, n, !0) : l !== void 0 ? e.addEventListener(t, n, { passive: l }) : e.addEventListener(t, n, !1);
}
function jl(e, t, n, r, l) {
  var o = r;
  if (!(t & 1) && !(t & 2) && r !== null) e: for (; ; ) {
    if (r === null) return;
    var u = r.tag;
    if (u === 3 || u === 4) {
      var i = r.stateNode.containerInfo;
      if (i === l || i.nodeType === 8 && i.parentNode === l) break;
      if (u === 4) for (u = r.return; u !== null; ) {
        var s = u.tag;
        if ((s === 3 || s === 4) && (s = u.stateNode.containerInfo, s === l || s.nodeType === 8 && s.parentNode === l)) return;
        u = u.return;
      }
      for (; i !== null; ) {
        if (u = St(i), u === null) return;
        if (s = u.tag, s === 5 || s === 6) {
          r = o = u;
          continue e;
        }
        i = i.parentNode;
      }
    }
    r = r.return;
  }
  Ss(function() {
    var a = o, m = Jo(n), p = [];
    e: {
      var h = Zs.get(e);
      if (h !== void 0) {
        var v = ru, w = e;
        switch (e) {
          case "keypress":
            if (_r(n) === 0) break e;
          case "keydown":
          case "keyup":
            v = gf;
            break;
          case "focusin":
            w = "focus", v = Tl;
            break;
          case "focusout":
            w = "blur", v = Tl;
            break;
          case "beforeblur":
          case "afterblur":
            v = Tl;
            break;
          case "click":
            if (n.button === 2) break e;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            v = qu;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            v = lf;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            v = kf;
            break;
          case Ks:
          case Xs:
          case Ys:
            v = sf;
            break;
          case Gs:
            v = Ef;
            break;
          case "scroll":
            v = nf;
            break;
          case "wheel":
            v = Cf;
            break;
          case "copy":
          case "cut":
          case "paste":
            v = cf;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            v = ei;
        }
        var k = (t & 4) !== 0, O = !k && e === "scroll", f = k ? h !== null ? h + "Capture" : null : h;
        k = [];
        for (var c = a, d; c !== null; ) {
          d = c;
          var g = d.stateNode;
          if (d.tag === 5 && g !== null && (d = g, f !== null && (g = In(c, f), g != null && k.push(An(c, g, d)))), O) break;
          c = c.return;
        }
        0 < k.length && (h = new v(h, w, null, n, m), p.push({ event: h, listeners: k }));
      }
    }
    if (!(t & 7)) {
      e: {
        if (h = e === "mouseover" || e === "pointerover", v = e === "mouseout" || e === "pointerout", h && n !== oo && (w = n.relatedTarget || n.fromElement) && (St(w) || w[Ke])) break e;
        if ((v || h) && (h = m.window === m ? m : (h = m.ownerDocument) ? h.defaultView || h.parentWindow : window, v ? (w = n.relatedTarget || n.toElement, v = a, w = w ? St(w) : null, w !== null && (O = Mt(w), w !== O || w.tag !== 5 && w.tag !== 6) && (w = null)) : (v = null, w = a), v !== w)) {
          if (k = qu, g = "onMouseLeave", f = "onMouseEnter", c = "mouse", (e === "pointerout" || e === "pointerover") && (k = ei, g = "onPointerLeave", f = "onPointerEnter", c = "pointer"), O = v == null ? h : Bt(v), d = w == null ? h : Bt(w), h = new k(g, c + "leave", v, n, m), h.target = O, h.relatedTarget = d, g = null, St(m) === a && (k = new k(f, c + "enter", w, n, m), k.target = d, k.relatedTarget = O, g = k), O = g, v && w) t: {
            for (k = v, f = w, c = 0, d = k; d; d = Ot(d)) c++;
            for (d = 0, g = f; g; g = Ot(g)) d++;
            for (; 0 < c - d; ) k = Ot(k), c--;
            for (; 0 < d - c; ) f = Ot(f), d--;
            for (; c--; ) {
              if (k === f || f !== null && k === f.alternate) break t;
              k = Ot(k), f = Ot(f);
            }
            k = null;
          }
          else k = null;
          v !== null && fi(p, h, v, k, !1), w !== null && O !== null && fi(p, O, w, k, !0);
        }
      }
      e: {
        if (h = a ? Bt(a) : window, v = h.nodeName && h.nodeName.toLowerCase(), v === "select" || v === "input" && h.type === "file") var S = Rf;
        else if (ri(h)) if (As) S = jf;
        else {
          S = Of;
          var C = Mf;
        }
        else (v = h.nodeName) && v.toLowerCase() === "input" && (h.type === "checkbox" || h.type === "radio") && (S = If);
        if (S && (S = S(e, a))) {
          $s(p, S, n, m);
          break e;
        }
        C && C(e, h, a), e === "focusout" && (C = h._wrapperState) && C.controlled && h.type === "number" && eo(h, "number", h.value);
      }
      switch (C = a ? Bt(a) : window, e) {
        case "focusin":
          (ri(C) || C.contentEditable === "true") && (Ft = C, po = a, Nn = null);
          break;
        case "focusout":
          Nn = po = Ft = null;
          break;
        case "mousedown":
          mo = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          mo = !1, si(p, n, m);
          break;
        case "selectionchange":
          if (Uf) break;
        case "keydown":
        case "keyup":
          si(p, n, m);
      }
      var x;
      if (ou) e: {
        switch (e) {
          case "compositionstart":
            var P = "onCompositionStart";
            break e;
          case "compositionend":
            P = "onCompositionEnd";
            break e;
          case "compositionupdate":
            P = "onCompositionUpdate";
            break e;
        }
        P = void 0;
      }
      else Dt ? Us(e, n) && (P = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (P = "onCompositionStart");
      P && (Fs && n.locale !== "ko" && (Dt || P !== "onCompositionStart" ? P === "onCompositionEnd" && Dt && (x = Ds()) : (tt = m, nu = "value" in tt ? tt.value : tt.textContent, Dt = !0)), C = Ur(a, P), 0 < C.length && (P = new bu(P, e, null, n, m), p.push({ event: P, listeners: C }), x ? P.data = x : (x = Bs(n), x !== null && (P.data = x)))), (x = Pf ? Nf(e, n) : Tf(e, n)) && (a = Ur(a, "onBeforeInput"), 0 < a.length && (m = new bu("onBeforeInput", "beforeinput", null, n, m), p.push({ event: m, listeners: a }), m.data = x));
    }
    Js(p, t);
  });
}
function An(e, t, n) {
  return { instance: e, listener: t, currentTarget: n };
}
function Ur(e, t) {
  for (var n = t + "Capture", r = []; e !== null; ) {
    var l = e, o = l.stateNode;
    l.tag === 5 && o !== null && (l = o, o = In(e, n), o != null && r.unshift(An(e, o, l)), o = In(e, t), o != null && r.push(An(e, o, l))), e = e.return;
  }
  return r;
}
function Ot(e) {
  if (e === null) return null;
  do
    e = e.return;
  while (e && e.tag !== 5);
  return e || null;
}
function fi(e, t, n, r, l) {
  for (var o = t._reactName, u = []; n !== null && n !== r; ) {
    var i = n, s = i.alternate, a = i.stateNode;
    if (s !== null && s === r) break;
    i.tag === 5 && a !== null && (i = a, l ? (s = In(n, o), s != null && u.unshift(An(n, s, i))) : l || (s = In(n, o), s != null && u.push(An(n, s, i)))), n = n.return;
  }
  u.length !== 0 && e.push({ event: t, listeners: u });
}
var Vf = /\r\n?/g, Wf = /\u0000|\uFFFD/g;
function di(e) {
  return (typeof e == "string" ? e : "" + e).replace(Vf, `
`).replace(Wf, "");
}
function dr(e, t, n) {
  if (t = di(t), di(e) !== t && n) throw Error(y(425));
}
function Br() {
}
var ho = null, vo = null;
function go(e, t) {
  return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
}
var yo = typeof setTimeout == "function" ? setTimeout : void 0, Hf = typeof clearTimeout == "function" ? clearTimeout : void 0, pi = typeof Promise == "function" ? Promise : void 0, Qf = typeof queueMicrotask == "function" ? queueMicrotask : typeof pi < "u" ? function(e) {
  return pi.resolve(null).then(e).catch(Kf);
} : yo;
function Kf(e) {
  setTimeout(function() {
    throw e;
  });
}
function Dl(e, t) {
  var n = t, r = 0;
  do {
    var l = n.nextSibling;
    if (e.removeChild(n), l && l.nodeType === 8) if (n = l.data, n === "/$") {
      if (r === 0) {
        e.removeChild(l), Fn(t);
        return;
      }
      r--;
    } else n !== "$" && n !== "$?" && n !== "$!" || r++;
    n = l;
  } while (n);
  Fn(t);
}
function ut(e) {
  for (; e != null; e = e.nextSibling) {
    var t = e.nodeType;
    if (t === 1 || t === 3) break;
    if (t === 8) {
      if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
      if (t === "/$") return null;
    }
  }
  return e;
}
function mi(e) {
  e = e.previousSibling;
  for (var t = 0; e; ) {
    if (e.nodeType === 8) {
      var n = e.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (t === 0) return e;
        t--;
      } else n === "/$" && t++;
    }
    e = e.previousSibling;
  }
  return null;
}
var sn = Math.random().toString(36).slice(2), Fe = "__reactFiber$" + sn, Vn = "__reactProps$" + sn, Ke = "__reactContainer$" + sn, wo = "__reactEvents$" + sn, Xf = "__reactListeners$" + sn, Yf = "__reactHandles$" + sn;
function St(e) {
  var t = e[Fe];
  if (t) return t;
  for (var n = e.parentNode; n; ) {
    if (t = n[Ke] || n[Fe]) {
      if (n = t.alternate, t.child !== null || n !== null && n.child !== null) for (e = mi(e); e !== null; ) {
        if (n = e[Fe]) return n;
        e = mi(e);
      }
      return t;
    }
    e = n, n = e.parentNode;
  }
  return null;
}
function qn(e) {
  return e = e[Fe] || e[Ke], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e;
}
function Bt(e) {
  if (e.tag === 5 || e.tag === 6) return e.stateNode;
  throw Error(y(33));
}
function ol(e) {
  return e[Vn] || null;
}
var ko = [], $t = -1;
function mt(e) {
  return { current: e };
}
function U(e) {
  0 > $t || (e.current = ko[$t], ko[$t] = null, $t--);
}
function D(e, t) {
  $t++, ko[$t] = e.current, e.current = t;
}
var dt = {}, ue = mt(dt), pe = mt(!1), Pt = dt;
function bt(e, t) {
  var n = e.type.contextTypes;
  if (!n) return dt;
  var r = e.stateNode;
  if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
  var l = {}, o;
  for (o in n) l[o] = t[o];
  return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = l), l;
}
function me(e) {
  return e = e.childContextTypes, e != null;
}
function $r() {
  U(pe), U(ue);
}
function hi(e, t, n) {
  if (ue.current !== dt) throw Error(y(168));
  D(ue, t), D(pe, n);
}
function bs(e, t, n) {
  var r = e.stateNode;
  if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
  r = r.getChildContext();
  for (var l in r) if (!(l in t)) throw Error(y(108, Rc(e) || "Unknown", l));
  return V({}, n, r);
}
function Ar(e) {
  return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || dt, Pt = ue.current, D(ue, e), D(pe, pe.current), !0;
}
function vi(e, t, n) {
  var r = e.stateNode;
  if (!r) throw Error(y(169));
  n ? (e = bs(e, t, Pt), r.__reactInternalMemoizedMergedChildContext = e, U(pe), U(ue), D(ue, e)) : U(pe), D(pe, n);
}
var Ae = null, ul = !1, Fl = !1;
function ea(e) {
  Ae === null ? Ae = [e] : Ae.push(e);
}
function Gf(e) {
  ul = !0, ea(e);
}
function ht() {
  if (!Fl && Ae !== null) {
    Fl = !0;
    var e = 0, t = j;
    try {
      var n = Ae;
      for (j = 1; e < n.length; e++) {
        var r = n[e];
        do
          r = r(!0);
        while (r !== null);
      }
      Ae = null, ul = !1;
    } catch (l) {
      throw Ae !== null && (Ae = Ae.slice(e + 1)), xs(qo, ht), l;
    } finally {
      j = t, Fl = !1;
    }
  }
  return null;
}
var At = [], Vt = 0, Vr = null, Wr = 0, Ee = [], _e = 0, Nt = null, Ve = 1, We = "";
function wt(e, t) {
  At[Vt++] = Wr, At[Vt++] = Vr, Vr = e, Wr = t;
}
function ta(e, t, n) {
  Ee[_e++] = Ve, Ee[_e++] = We, Ee[_e++] = Nt, Nt = e;
  var r = Ve;
  e = We;
  var l = 32 - Me(r) - 1;
  r &= ~(1 << l), n += 1;
  var o = 32 - Me(t) + l;
  if (30 < o) {
    var u = l - l % 5;
    o = (r & (1 << u) - 1).toString(32), r >>= u, l -= u, Ve = 1 << 32 - Me(t) + l | n << l | r, We = o + e;
  } else Ve = 1 << o | n << l | r, We = e;
}
function iu(e) {
  e.return !== null && (wt(e, 1), ta(e, 1, 0));
}
function su(e) {
  for (; e === Vr; ) Vr = At[--Vt], At[Vt] = null, Wr = At[--Vt], At[Vt] = null;
  for (; e === Nt; ) Nt = Ee[--_e], Ee[_e] = null, We = Ee[--_e], Ee[_e] = null, Ve = Ee[--_e], Ee[_e] = null;
}
var ye = null, ge = null, B = !1, Re = null;
function na(e, t) {
  var n = Ce(5, null, null, 0);
  n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n);
}
function gi(e, t) {
  switch (e.tag) {
    case 5:
      var n = e.type;
      return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, ye = e, ge = ut(t.firstChild), !0) : !1;
    case 6:
      return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, ye = e, ge = null, !0) : !1;
    case 13:
      return t = t.nodeType !== 8 ? null : t, t !== null ? (n = Nt !== null ? { id: Ve, overflow: We } : null, e.memoizedState = { dehydrated: t, treeContext: n, retryLane: 1073741824 }, n = Ce(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, ye = e, ge = null, !0) : !1;
    default:
      return !1;
  }
}
function So(e) {
  return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
}
function Eo(e) {
  if (B) {
    var t = ge;
    if (t) {
      var n = t;
      if (!gi(e, t)) {
        if (So(e)) throw Error(y(418));
        t = ut(n.nextSibling);
        var r = ye;
        t && gi(e, t) ? na(r, n) : (e.flags = e.flags & -4097 | 2, B = !1, ye = e);
      }
    } else {
      if (So(e)) throw Error(y(418));
      e.flags = e.flags & -4097 | 2, B = !1, ye = e;
    }
  }
}
function yi(e) {
  for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13; ) e = e.return;
  ye = e;
}
function pr(e) {
  if (e !== ye) return !1;
  if (!B) return yi(e), B = !0, !1;
  var t;
  if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !go(e.type, e.memoizedProps)), t && (t = ge)) {
    if (So(e)) throw ra(), Error(y(418));
    for (; t; ) na(e, t), t = ut(t.nextSibling);
  }
  if (yi(e), e.tag === 13) {
    if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(y(317));
    e: {
      for (e = e.nextSibling, t = 0; e; ) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === "/$") {
            if (t === 0) {
              ge = ut(e.nextSibling);
              break e;
            }
            t--;
          } else n !== "$" && n !== "$!" && n !== "$?" || t++;
        }
        e = e.nextSibling;
      }
      ge = null;
    }
  } else ge = ye ? ut(e.stateNode.nextSibling) : null;
  return !0;
}
function ra() {
  for (var e = ge; e; ) e = ut(e.nextSibling);
}
function en() {
  ge = ye = null, B = !1;
}
function au(e) {
  Re === null ? Re = [e] : Re.push(e);
}
var Zf = Ge.ReactCurrentBatchConfig;
function hn(e, t, n) {
  if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
    if (n._owner) {
      if (n = n._owner, n) {
        if (n.tag !== 1) throw Error(y(309));
        var r = n.stateNode;
      }
      if (!r) throw Error(y(147, e));
      var l = r, o = "" + e;
      return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(u) {
        var i = l.refs;
        u === null ? delete i[o] : i[o] = u;
      }, t._stringRef = o, t);
    }
    if (typeof e != "string") throw Error(y(284));
    if (!n._owner) throw Error(y(290, e));
  }
  return e;
}
function mr(e, t) {
  throw e = Object.prototype.toString.call(t), Error(y(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e));
}
function wi(e) {
  var t = e._init;
  return t(e._payload);
}
function la(e) {
  function t(f, c) {
    if (e) {
      var d = f.deletions;
      d === null ? (f.deletions = [c], f.flags |= 16) : d.push(c);
    }
  }
  function n(f, c) {
    if (!e) return null;
    for (; c !== null; ) t(f, c), c = c.sibling;
    return null;
  }
  function r(f, c) {
    for (f = /* @__PURE__ */ new Map(); c !== null; ) c.key !== null ? f.set(c.key, c) : f.set(c.index, c), c = c.sibling;
    return f;
  }
  function l(f, c) {
    return f = ct(f, c), f.index = 0, f.sibling = null, f;
  }
  function o(f, c, d) {
    return f.index = d, e ? (d = f.alternate, d !== null ? (d = d.index, d < c ? (f.flags |= 2, c) : d) : (f.flags |= 2, c)) : (f.flags |= 1048576, c);
  }
  function u(f) {
    return e && f.alternate === null && (f.flags |= 2), f;
  }
  function i(f, c, d, g) {
    return c === null || c.tag !== 6 ? (c = Hl(d, f.mode, g), c.return = f, c) : (c = l(c, d), c.return = f, c);
  }
  function s(f, c, d, g) {
    var S = d.type;
    return S === jt ? m(f, c, d.props.children, g, d.key) : c !== null && (c.elementType === S || typeof S == "object" && S !== null && S.$$typeof === Je && wi(S) === c.type) ? (g = l(c, d.props), g.ref = hn(f, c, d), g.return = f, g) : (g = Lr(d.type, d.key, d.props, null, f.mode, g), g.ref = hn(f, c, d), g.return = f, g);
  }
  function a(f, c, d, g) {
    return c === null || c.tag !== 4 || c.stateNode.containerInfo !== d.containerInfo || c.stateNode.implementation !== d.implementation ? (c = Ql(d, f.mode, g), c.return = f, c) : (c = l(c, d.children || []), c.return = f, c);
  }
  function m(f, c, d, g, S) {
    return c === null || c.tag !== 7 ? (c = xt(d, f.mode, g, S), c.return = f, c) : (c = l(c, d), c.return = f, c);
  }
  function p(f, c, d) {
    if (typeof c == "string" && c !== "" || typeof c == "number") return c = Hl("" + c, f.mode, d), c.return = f, c;
    if (typeof c == "object" && c !== null) {
      switch (c.$$typeof) {
        case rr:
          return d = Lr(c.type, c.key, c.props, null, f.mode, d), d.ref = hn(f, null, c), d.return = f, d;
        case It:
          return c = Ql(c, f.mode, d), c.return = f, c;
        case Je:
          var g = c._init;
          return p(f, g(c._payload), d);
      }
      if (kn(c) || cn(c)) return c = xt(c, f.mode, d, null), c.return = f, c;
      mr(f, c);
    }
    return null;
  }
  function h(f, c, d, g) {
    var S = c !== null ? c.key : null;
    if (typeof d == "string" && d !== "" || typeof d == "number") return S !== null ? null : i(f, c, "" + d, g);
    if (typeof d == "object" && d !== null) {
      switch (d.$$typeof) {
        case rr:
          return d.key === S ? s(f, c, d, g) : null;
        case It:
          return d.key === S ? a(f, c, d, g) : null;
        case Je:
          return S = d._init, h(
            f,
            c,
            S(d._payload),
            g
          );
      }
      if (kn(d) || cn(d)) return S !== null ? null : m(f, c, d, g, null);
      mr(f, d);
    }
    return null;
  }
  function v(f, c, d, g, S) {
    if (typeof g == "string" && g !== "" || typeof g == "number") return f = f.get(d) || null, i(c, f, "" + g, S);
    if (typeof g == "object" && g !== null) {
      switch (g.$$typeof) {
        case rr:
          return f = f.get(g.key === null ? d : g.key) || null, s(c, f, g, S);
        case It:
          return f = f.get(g.key === null ? d : g.key) || null, a(c, f, g, S);
        case Je:
          var C = g._init;
          return v(f, c, d, C(g._payload), S);
      }
      if (kn(g) || cn(g)) return f = f.get(d) || null, m(c, f, g, S, null);
      mr(c, g);
    }
    return null;
  }
  function w(f, c, d, g) {
    for (var S = null, C = null, x = c, P = c = 0, N = null; x !== null && P < d.length; P++) {
      x.index > P ? (N = x, x = null) : N = x.sibling;
      var z = h(f, x, d[P], g);
      if (z === null) {
        x === null && (x = N);
        break;
      }
      e && x && z.alternate === null && t(f, x), c = o(z, c, P), C === null ? S = z : C.sibling = z, C = z, x = N;
    }
    if (P === d.length) return n(f, x), B && wt(f, P), S;
    if (x === null) {
      for (; P < d.length; P++) x = p(f, d[P], g), x !== null && (c = o(x, c, P), C === null ? S = x : C.sibling = x, C = x);
      return B && wt(f, P), S;
    }
    for (x = r(f, x); P < d.length; P++) N = v(x, f, P, d[P], g), N !== null && (e && N.alternate !== null && x.delete(N.key === null ? P : N.key), c = o(N, c, P), C === null ? S = N : C.sibling = N, C = N);
    return e && x.forEach(function(b) {
      return t(f, b);
    }), B && wt(f, P), S;
  }
  function k(f, c, d, g) {
    var S = cn(d);
    if (typeof S != "function") throw Error(y(150));
    if (d = S.call(d), d == null) throw Error(y(151));
    for (var C = S = null, x = c, P = c = 0, N = null, z = d.next(); x !== null && !z.done; P++, z = d.next()) {
      x.index > P ? (N = x, x = null) : N = x.sibling;
      var b = h(f, x, z.value, g);
      if (b === null) {
        x === null && (x = N);
        break;
      }
      e && x && b.alternate === null && t(f, x), c = o(b, c, P), C === null ? S = b : C.sibling = b, C = b, x = N;
    }
    if (z.done) return n(
      f,
      x
    ), B && wt(f, P), S;
    if (x === null) {
      for (; !z.done; P++, z = d.next()) z = p(f, z.value, g), z !== null && (c = o(z, c, P), C === null ? S = z : C.sibling = z, C = z);
      return B && wt(f, P), S;
    }
    for (x = r(f, x); !z.done; P++, z = d.next()) z = v(x, f, P, z.value, g), z !== null && (e && z.alternate !== null && x.delete(z.key === null ? P : z.key), c = o(z, c, P), C === null ? S = z : C.sibling = z, C = z);
    return e && x.forEach(function(vt) {
      return t(f, vt);
    }), B && wt(f, P), S;
  }
  function O(f, c, d, g) {
    if (typeof d == "object" && d !== null && d.type === jt && d.key === null && (d = d.props.children), typeof d == "object" && d !== null) {
      switch (d.$$typeof) {
        case rr:
          e: {
            for (var S = d.key, C = c; C !== null; ) {
              if (C.key === S) {
                if (S = d.type, S === jt) {
                  if (C.tag === 7) {
                    n(f, C.sibling), c = l(C, d.props.children), c.return = f, f = c;
                    break e;
                  }
                } else if (C.elementType === S || typeof S == "object" && S !== null && S.$$typeof === Je && wi(S) === C.type) {
                  n(f, C.sibling), c = l(C, d.props), c.ref = hn(f, C, d), c.return = f, f = c;
                  break e;
                }
                n(f, C);
                break;
              } else t(f, C);
              C = C.sibling;
            }
            d.type === jt ? (c = xt(d.props.children, f.mode, g, d.key), c.return = f, f = c) : (g = Lr(d.type, d.key, d.props, null, f.mode, g), g.ref = hn(f, c, d), g.return = f, f = g);
          }
          return u(f);
        case It:
          e: {
            for (C = d.key; c !== null; ) {
              if (c.key === C) if (c.tag === 4 && c.stateNode.containerInfo === d.containerInfo && c.stateNode.implementation === d.implementation) {
                n(f, c.sibling), c = l(c, d.children || []), c.return = f, f = c;
                break e;
              } else {
                n(f, c);
                break;
              }
              else t(f, c);
              c = c.sibling;
            }
            c = Ql(d, f.mode, g), c.return = f, f = c;
          }
          return u(f);
        case Je:
          return C = d._init, O(f, c, C(d._payload), g);
      }
      if (kn(d)) return w(f, c, d, g);
      if (cn(d)) return k(f, c, d, g);
      mr(f, d);
    }
    return typeof d == "string" && d !== "" || typeof d == "number" ? (d = "" + d, c !== null && c.tag === 6 ? (n(f, c.sibling), c = l(c, d), c.return = f, f = c) : (n(f, c), c = Hl(d, f.mode, g), c.return = f, f = c), u(f)) : n(f, c);
  }
  return O;
}
var tn = la(!0), oa = la(!1), Hr = mt(null), Qr = null, Wt = null, cu = null;
function fu() {
  cu = Wt = Qr = null;
}
function du(e) {
  var t = Hr.current;
  U(Hr), e._currentValue = t;
}
function _o(e, t, n) {
  for (; e !== null; ) {
    var r = e.alternate;
    if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
    e = e.return;
  }
}
function Zt(e, t) {
  Qr = e, cu = Wt = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (de = !0), e.firstContext = null);
}
function Pe(e) {
  var t = e._currentValue;
  if (cu !== e) if (e = { context: e, memoizedValue: t, next: null }, Wt === null) {
    if (Qr === null) throw Error(y(308));
    Wt = e, Qr.dependencies = { lanes: 0, firstContext: e };
  } else Wt = Wt.next = e;
  return t;
}
var Et = null;
function pu(e) {
  Et === null ? Et = [e] : Et.push(e);
}
function ua(e, t, n, r) {
  var l = t.interleaved;
  return l === null ? (n.next = n, pu(t)) : (n.next = l.next, l.next = n), t.interleaved = n, Xe(e, r);
}
function Xe(e, t) {
  e.lanes |= t;
  var n = e.alternate;
  for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null; ) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
  return n.tag === 3 ? n.stateNode : null;
}
var qe = !1;
function mu(e) {
  e.updateQueue = { baseState: e.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function ia(e, t) {
  e = e.updateQueue, t.updateQueue === e && (t.updateQueue = { baseState: e.baseState, firstBaseUpdate: e.firstBaseUpdate, lastBaseUpdate: e.lastBaseUpdate, shared: e.shared, effects: e.effects });
}
function He(e, t) {
  return { eventTime: e, lane: t, tag: 0, payload: null, callback: null, next: null };
}
function it(e, t, n) {
  var r = e.updateQueue;
  if (r === null) return null;
  if (r = r.shared, M & 2) {
    var l = r.pending;
    return l === null ? t.next = t : (t.next = l.next, l.next = t), r.pending = t, Xe(e, n);
  }
  return l = r.interleaved, l === null ? (t.next = t, pu(r)) : (t.next = l.next, l.next = t), r.interleaved = t, Xe(e, n);
}
function Cr(e, t, n) {
  if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
    var r = t.lanes;
    r &= e.pendingLanes, n |= r, t.lanes = n, bo(e, n);
  }
}
function ki(e, t) {
  var n = e.updateQueue, r = e.alternate;
  if (r !== null && (r = r.updateQueue, n === r)) {
    var l = null, o = null;
    if (n = n.firstBaseUpdate, n !== null) {
      do {
        var u = { eventTime: n.eventTime, lane: n.lane, tag: n.tag, payload: n.payload, callback: n.callback, next: null };
        o === null ? l = o = u : o = o.next = u, n = n.next;
      } while (n !== null);
      o === null ? l = o = t : o = o.next = t;
    } else l = o = t;
    n = { baseState: r.baseState, firstBaseUpdate: l, lastBaseUpdate: o, shared: r.shared, effects: r.effects }, e.updateQueue = n;
    return;
  }
  e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t;
}
function Kr(e, t, n, r) {
  var l = e.updateQueue;
  qe = !1;
  var o = l.firstBaseUpdate, u = l.lastBaseUpdate, i = l.shared.pending;
  if (i !== null) {
    l.shared.pending = null;
    var s = i, a = s.next;
    s.next = null, u === null ? o = a : u.next = a, u = s;
    var m = e.alternate;
    m !== null && (m = m.updateQueue, i = m.lastBaseUpdate, i !== u && (i === null ? m.firstBaseUpdate = a : i.next = a, m.lastBaseUpdate = s));
  }
  if (o !== null) {
    var p = l.baseState;
    u = 0, m = a = s = null, i = o;
    do {
      var h = i.lane, v = i.eventTime;
      if ((r & h) === h) {
        m !== null && (m = m.next = {
          eventTime: v,
          lane: 0,
          tag: i.tag,
          payload: i.payload,
          callback: i.callback,
          next: null
        });
        e: {
          var w = e, k = i;
          switch (h = t, v = n, k.tag) {
            case 1:
              if (w = k.payload, typeof w == "function") {
                p = w.call(v, p, h);
                break e;
              }
              p = w;
              break e;
            case 3:
              w.flags = w.flags & -65537 | 128;
            case 0:
              if (w = k.payload, h = typeof w == "function" ? w.call(v, p, h) : w, h == null) break e;
              p = V({}, p, h);
              break e;
            case 2:
              qe = !0;
          }
        }
        i.callback !== null && i.lane !== 0 && (e.flags |= 64, h = l.effects, h === null ? l.effects = [i] : h.push(i));
      } else v = { eventTime: v, lane: h, tag: i.tag, payload: i.payload, callback: i.callback, next: null }, m === null ? (a = m = v, s = p) : m = m.next = v, u |= h;
      if (i = i.next, i === null) {
        if (i = l.shared.pending, i === null) break;
        h = i, i = h.next, h.next = null, l.lastBaseUpdate = h, l.shared.pending = null;
      }
    } while (!0);
    if (m === null && (s = p), l.baseState = s, l.firstBaseUpdate = a, l.lastBaseUpdate = m, t = l.shared.interleaved, t !== null) {
      l = t;
      do
        u |= l.lane, l = l.next;
      while (l !== t);
    } else o === null && (l.shared.lanes = 0);
    zt |= u, e.lanes = u, e.memoizedState = p;
  }
}
function Si(e, t, n) {
  if (e = t.effects, t.effects = null, e !== null) for (t = 0; t < e.length; t++) {
    var r = e[t], l = r.callback;
    if (l !== null) {
      if (r.callback = null, r = n, typeof l != "function") throw Error(y(191, l));
      l.call(r);
    }
  }
}
var bn = {}, Be = mt(bn), Wn = mt(bn), Hn = mt(bn);
function _t(e) {
  if (e === bn) throw Error(y(174));
  return e;
}
function hu(e, t) {
  switch (D(Hn, t), D(Wn, e), D(Be, bn), e = t.nodeType, e) {
    case 9:
    case 11:
      t = (t = t.documentElement) ? t.namespaceURI : no(null, "");
      break;
    default:
      e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = no(t, e);
  }
  U(Be), D(Be, t);
}
function nn() {
  U(Be), U(Wn), U(Hn);
}
function sa(e) {
  _t(Hn.current);
  var t = _t(Be.current), n = no(t, e.type);
  t !== n && (D(Wn, e), D(Be, n));
}
function vu(e) {
  Wn.current === e && (U(Be), U(Wn));
}
var $ = mt(0);
function Xr(e) {
  for (var t = e; t !== null; ) {
    if (t.tag === 13) {
      var n = t.memoizedState;
      if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t;
    } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
      if (t.flags & 128) return t;
    } else if (t.child !== null) {
      t.child.return = t, t = t.child;
      continue;
    }
    if (t === e) break;
    for (; t.sibling === null; ) {
      if (t.return === null || t.return === e) return null;
      t = t.return;
    }
    t.sibling.return = t.return, t = t.sibling;
  }
  return null;
}
var Ul = [];
function gu() {
  for (var e = 0; e < Ul.length; e++) Ul[e]._workInProgressVersionPrimary = null;
  Ul.length = 0;
}
var xr = Ge.ReactCurrentDispatcher, Bl = Ge.ReactCurrentBatchConfig, Tt = 0, A = null, Y = null, J = null, Yr = !1, Tn = !1, Qn = 0, Jf = 0;
function re() {
  throw Error(y(321));
}
function yu(e, t) {
  if (t === null) return !1;
  for (var n = 0; n < t.length && n < e.length; n++) if (!Ie(e[n], t[n])) return !1;
  return !0;
}
function wu(e, t, n, r, l, o) {
  if (Tt = o, A = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, xr.current = e === null || e.memoizedState === null ? td : nd, e = n(r, l), Tn) {
    o = 0;
    do {
      if (Tn = !1, Qn = 0, 25 <= o) throw Error(y(301));
      o += 1, J = Y = null, t.updateQueue = null, xr.current = rd, e = n(r, l);
    } while (Tn);
  }
  if (xr.current = Gr, t = Y !== null && Y.next !== null, Tt = 0, J = Y = A = null, Yr = !1, t) throw Error(y(300));
  return e;
}
function ku() {
  var e = Qn !== 0;
  return Qn = 0, e;
}
function De() {
  var e = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  return J === null ? A.memoizedState = J = e : J = J.next = e, J;
}
function Ne() {
  if (Y === null) {
    var e = A.alternate;
    e = e !== null ? e.memoizedState : null;
  } else e = Y.next;
  var t = J === null ? A.memoizedState : J.next;
  if (t !== null) J = t, Y = e;
  else {
    if (e === null) throw Error(y(310));
    Y = e, e = { memoizedState: Y.memoizedState, baseState: Y.baseState, baseQueue: Y.baseQueue, queue: Y.queue, next: null }, J === null ? A.memoizedState = J = e : J = J.next = e;
  }
  return J;
}
function Kn(e, t) {
  return typeof t == "function" ? t(e) : t;
}
function $l(e) {
  var t = Ne(), n = t.queue;
  if (n === null) throw Error(y(311));
  n.lastRenderedReducer = e;
  var r = Y, l = r.baseQueue, o = n.pending;
  if (o !== null) {
    if (l !== null) {
      var u = l.next;
      l.next = o.next, o.next = u;
    }
    r.baseQueue = l = o, n.pending = null;
  }
  if (l !== null) {
    o = l.next, r = r.baseState;
    var i = u = null, s = null, a = o;
    do {
      var m = a.lane;
      if ((Tt & m) === m) s !== null && (s = s.next = { lane: 0, action: a.action, hasEagerState: a.hasEagerState, eagerState: a.eagerState, next: null }), r = a.hasEagerState ? a.eagerState : e(r, a.action);
      else {
        var p = {
          lane: m,
          action: a.action,
          hasEagerState: a.hasEagerState,
          eagerState: a.eagerState,
          next: null
        };
        s === null ? (i = s = p, u = r) : s = s.next = p, A.lanes |= m, zt |= m;
      }
      a = a.next;
    } while (a !== null && a !== o);
    s === null ? u = r : s.next = i, Ie(r, t.memoizedState) || (de = !0), t.memoizedState = r, t.baseState = u, t.baseQueue = s, n.lastRenderedState = r;
  }
  if (e = n.interleaved, e !== null) {
    l = e;
    do
      o = l.lane, A.lanes |= o, zt |= o, l = l.next;
    while (l !== e);
  } else l === null && (n.lanes = 0);
  return [t.memoizedState, n.dispatch];
}
function Al(e) {
  var t = Ne(), n = t.queue;
  if (n === null) throw Error(y(311));
  n.lastRenderedReducer = e;
  var r = n.dispatch, l = n.pending, o = t.memoizedState;
  if (l !== null) {
    n.pending = null;
    var u = l = l.next;
    do
      o = e(o, u.action), u = u.next;
    while (u !== l);
    Ie(o, t.memoizedState) || (de = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o;
  }
  return [o, r];
}
function aa() {
}
function ca(e, t) {
  var n = A, r = Ne(), l = t(), o = !Ie(r.memoizedState, l);
  if (o && (r.memoizedState = l, de = !0), r = r.queue, Su(pa.bind(null, n, r, e), [e]), r.getSnapshot !== t || o || J !== null && J.memoizedState.tag & 1) {
    if (n.flags |= 2048, Xn(9, da.bind(null, n, r, l, t), void 0, null), q === null) throw Error(y(349));
    Tt & 30 || fa(n, t, l);
  }
  return l;
}
function fa(e, t, n) {
  e.flags |= 16384, e = { getSnapshot: t, value: n }, t = A.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, A.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e));
}
function da(e, t, n, r) {
  t.value = n, t.getSnapshot = r, ma(t) && ha(e);
}
function pa(e, t, n) {
  return n(function() {
    ma(t) && ha(e);
  });
}
function ma(e) {
  var t = e.getSnapshot;
  e = e.value;
  try {
    var n = t();
    return !Ie(e, n);
  } catch {
    return !0;
  }
}
function ha(e) {
  var t = Xe(e, 1);
  t !== null && Oe(t, e, 1, -1);
}
function Ei(e) {
  var t = De();
  return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Kn, lastRenderedState: e }, t.queue = e, e = e.dispatch = ed.bind(null, A, e), [t.memoizedState, e];
}
function Xn(e, t, n, r) {
  return e = { tag: e, create: t, destroy: n, deps: r, next: null }, t = A.updateQueue, t === null ? (t = { lastEffect: null, stores: null }, A.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e;
}
function va() {
  return Ne().memoizedState;
}
function Pr(e, t, n, r) {
  var l = De();
  A.flags |= e, l.memoizedState = Xn(1 | t, n, void 0, r === void 0 ? null : r);
}
function il(e, t, n, r) {
  var l = Ne();
  r = r === void 0 ? null : r;
  var o = void 0;
  if (Y !== null) {
    var u = Y.memoizedState;
    if (o = u.destroy, r !== null && yu(r, u.deps)) {
      l.memoizedState = Xn(t, n, o, r);
      return;
    }
  }
  A.flags |= e, l.memoizedState = Xn(1 | t, n, o, r);
}
function _i(e, t) {
  return Pr(8390656, 8, e, t);
}
function Su(e, t) {
  return il(2048, 8, e, t);
}
function ga(e, t) {
  return il(4, 2, e, t);
}
function ya(e, t) {
  return il(4, 4, e, t);
}
function wa(e, t) {
  if (typeof t == "function") return e = e(), t(e), function() {
    t(null);
  };
  if (t != null) return e = e(), t.current = e, function() {
    t.current = null;
  };
}
function ka(e, t, n) {
  return n = n != null ? n.concat([e]) : null, il(4, 4, wa.bind(null, t, e), n);
}
function Eu() {
}
function Sa(e, t) {
  var n = Ne();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && yu(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e);
}
function Ea(e, t) {
  var n = Ne();
  t = t === void 0 ? null : t;
  var r = n.memoizedState;
  return r !== null && t !== null && yu(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e);
}
function _a(e, t, n) {
  return Tt & 21 ? (Ie(n, t) || (n = Ts(), A.lanes |= n, zt |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, de = !0), e.memoizedState = n);
}
function qf(e, t) {
  var n = j;
  j = n !== 0 && 4 > n ? n : 4, e(!0);
  var r = Bl.transition;
  Bl.transition = {};
  try {
    e(!1), t();
  } finally {
    j = n, Bl.transition = r;
  }
}
function Ca() {
  return Ne().memoizedState;
}
function bf(e, t, n) {
  var r = at(e);
  if (n = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null }, xa(e)) Pa(t, n);
  else if (n = ua(e, t, n, r), n !== null) {
    var l = se();
    Oe(n, e, r, l), Na(n, t, r);
  }
}
function ed(e, t, n) {
  var r = at(e), l = { lane: r, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (xa(e)) Pa(t, l);
  else {
    var o = e.alternate;
    if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer, o !== null)) try {
      var u = t.lastRenderedState, i = o(u, n);
      if (l.hasEagerState = !0, l.eagerState = i, Ie(i, u)) {
        var s = t.interleaved;
        s === null ? (l.next = l, pu(t)) : (l.next = s.next, s.next = l), t.interleaved = l;
        return;
      }
    } catch {
    } finally {
    }
    n = ua(e, t, l, r), n !== null && (l = se(), Oe(n, e, r, l), Na(n, t, r));
  }
}
function xa(e) {
  var t = e.alternate;
  return e === A || t !== null && t === A;
}
function Pa(e, t) {
  Tn = Yr = !0;
  var n = e.pending;
  n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
}
function Na(e, t, n) {
  if (n & 4194240) {
    var r = t.lanes;
    r &= e.pendingLanes, n |= r, t.lanes = n, bo(e, n);
  }
}
var Gr = { readContext: Pe, useCallback: re, useContext: re, useEffect: re, useImperativeHandle: re, useInsertionEffect: re, useLayoutEffect: re, useMemo: re, useReducer: re, useRef: re, useState: re, useDebugValue: re, useDeferredValue: re, useTransition: re, useMutableSource: re, useSyncExternalStore: re, useId: re, unstable_isNewReconciler: !1 }, td = { readContext: Pe, useCallback: function(e, t) {
  return De().memoizedState = [e, t === void 0 ? null : t], e;
}, useContext: Pe, useEffect: _i, useImperativeHandle: function(e, t, n) {
  return n = n != null ? n.concat([e]) : null, Pr(
    4194308,
    4,
    wa.bind(null, t, e),
    n
  );
}, useLayoutEffect: function(e, t) {
  return Pr(4194308, 4, e, t);
}, useInsertionEffect: function(e, t) {
  return Pr(4, 2, e, t);
}, useMemo: function(e, t) {
  var n = De();
  return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e;
}, useReducer: function(e, t, n) {
  var r = De();
  return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: e, lastRenderedState: t }, r.queue = e, e = e.dispatch = bf.bind(null, A, e), [r.memoizedState, e];
}, useRef: function(e) {
  var t = De();
  return e = { current: e }, t.memoizedState = e;
}, useState: Ei, useDebugValue: Eu, useDeferredValue: function(e) {
  return De().memoizedState = e;
}, useTransition: function() {
  var e = Ei(!1), t = e[0];
  return e = qf.bind(null, e[1]), De().memoizedState = e, [t, e];
}, useMutableSource: function() {
}, useSyncExternalStore: function(e, t, n) {
  var r = A, l = De();
  if (B) {
    if (n === void 0) throw Error(y(407));
    n = n();
  } else {
    if (n = t(), q === null) throw Error(y(349));
    Tt & 30 || fa(r, t, n);
  }
  l.memoizedState = n;
  var o = { value: n, getSnapshot: t };
  return l.queue = o, _i(pa.bind(
    null,
    r,
    o,
    e
  ), [e]), r.flags |= 2048, Xn(9, da.bind(null, r, o, n, t), void 0, null), n;
}, useId: function() {
  var e = De(), t = q.identifierPrefix;
  if (B) {
    var n = We, r = Ve;
    n = (r & ~(1 << 32 - Me(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = Qn++, 0 < n && (t += "H" + n.toString(32)), t += ":";
  } else n = Jf++, t = ":" + t + "r" + n.toString(32) + ":";
  return e.memoizedState = t;
}, unstable_isNewReconciler: !1 }, nd = {
  readContext: Pe,
  useCallback: Sa,
  useContext: Pe,
  useEffect: Su,
  useImperativeHandle: ka,
  useInsertionEffect: ga,
  useLayoutEffect: ya,
  useMemo: Ea,
  useReducer: $l,
  useRef: va,
  useState: function() {
    return $l(Kn);
  },
  useDebugValue: Eu,
  useDeferredValue: function(e) {
    var t = Ne();
    return _a(t, Y.memoizedState, e);
  },
  useTransition: function() {
    var e = $l(Kn)[0], t = Ne().memoizedState;
    return [e, t];
  },
  useMutableSource: aa,
  useSyncExternalStore: ca,
  useId: Ca,
  unstable_isNewReconciler: !1
}, rd = { readContext: Pe, useCallback: Sa, useContext: Pe, useEffect: Su, useImperativeHandle: ka, useInsertionEffect: ga, useLayoutEffect: ya, useMemo: Ea, useReducer: Al, useRef: va, useState: function() {
  return Al(Kn);
}, useDebugValue: Eu, useDeferredValue: function(e) {
  var t = Ne();
  return Y === null ? t.memoizedState = e : _a(t, Y.memoizedState, e);
}, useTransition: function() {
  var e = Al(Kn)[0], t = Ne().memoizedState;
  return [e, t];
}, useMutableSource: aa, useSyncExternalStore: ca, useId: Ca, unstable_isNewReconciler: !1 };
function ze(e, t) {
  if (e && e.defaultProps) {
    t = V({}, t), e = e.defaultProps;
    for (var n in e) t[n] === void 0 && (t[n] = e[n]);
    return t;
  }
  return t;
}
function Co(e, t, n, r) {
  t = e.memoizedState, n = n(r, t), n = n == null ? t : V({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n);
}
var sl = { isMounted: function(e) {
  return (e = e._reactInternals) ? Mt(e) === e : !1;
}, enqueueSetState: function(e, t, n) {
  e = e._reactInternals;
  var r = se(), l = at(e), o = He(r, l);
  o.payload = t, n != null && (o.callback = n), t = it(e, o, l), t !== null && (Oe(t, e, l, r), Cr(t, e, l));
}, enqueueReplaceState: function(e, t, n) {
  e = e._reactInternals;
  var r = se(), l = at(e), o = He(r, l);
  o.tag = 1, o.payload = t, n != null && (o.callback = n), t = it(e, o, l), t !== null && (Oe(t, e, l, r), Cr(t, e, l));
}, enqueueForceUpdate: function(e, t) {
  e = e._reactInternals;
  var n = se(), r = at(e), l = He(n, r);
  l.tag = 2, t != null && (l.callback = t), t = it(e, l, r), t !== null && (Oe(t, e, r, n), Cr(t, e, r));
} };
function Ci(e, t, n, r, l, o, u) {
  return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, u) : t.prototype && t.prototype.isPureReactComponent ? !Bn(n, r) || !Bn(l, o) : !0;
}
function Ta(e, t, n) {
  var r = !1, l = dt, o = t.contextType;
  return typeof o == "object" && o !== null ? o = Pe(o) : (l = me(t) ? Pt : ue.current, r = t.contextTypes, o = (r = r != null) ? bt(e, l) : dt), t = new t(n, o), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = sl, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = l, e.__reactInternalMemoizedMaskedChildContext = o), t;
}
function xi(e, t, n, r) {
  e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && sl.enqueueReplaceState(t, t.state, null);
}
function xo(e, t, n, r) {
  var l = e.stateNode;
  l.props = n, l.state = e.memoizedState, l.refs = {}, mu(e);
  var o = t.contextType;
  typeof o == "object" && o !== null ? l.context = Pe(o) : (o = me(t) ? Pt : ue.current, l.context = bt(e, o)), l.state = e.memoizedState, o = t.getDerivedStateFromProps, typeof o == "function" && (Co(e, t, o, n), l.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof l.getSnapshotBeforeUpdate == "function" || typeof l.UNSAFE_componentWillMount != "function" && typeof l.componentWillMount != "function" || (t = l.state, typeof l.componentWillMount == "function" && l.componentWillMount(), typeof l.UNSAFE_componentWillMount == "function" && l.UNSAFE_componentWillMount(), t !== l.state && sl.enqueueReplaceState(l, l.state, null), Kr(e, n, l, r), l.state = e.memoizedState), typeof l.componentDidMount == "function" && (e.flags |= 4194308);
}
function rn(e, t) {
  try {
    var n = "", r = t;
    do
      n += Lc(r), r = r.return;
    while (r);
    var l = n;
  } catch (o) {
    l = `
Error generating stack: ` + o.message + `
` + o.stack;
  }
  return { value: e, source: t, stack: l, digest: null };
}
function Vl(e, t, n) {
  return { value: e, source: null, stack: n ?? null, digest: t ?? null };
}
function Po(e, t) {
  try {
    console.error(t.value);
  } catch (n) {
    setTimeout(function() {
      throw n;
    });
  }
}
var ld = typeof WeakMap == "function" ? WeakMap : Map;
function za(e, t, n) {
  n = He(-1, n), n.tag = 3, n.payload = { element: null };
  var r = t.value;
  return n.callback = function() {
    Jr || (Jr = !0, Do = r), Po(e, t);
  }, n;
}
function La(e, t, n) {
  n = He(-1, n), n.tag = 3;
  var r = e.type.getDerivedStateFromError;
  if (typeof r == "function") {
    var l = t.value;
    n.payload = function() {
      return r(l);
    }, n.callback = function() {
      Po(e, t);
    };
  }
  var o = e.stateNode;
  return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
    Po(e, t), typeof r != "function" && (st === null ? st = /* @__PURE__ */ new Set([this]) : st.add(this));
    var u = t.stack;
    this.componentDidCatch(t.value, { componentStack: u !== null ? u : "" });
  }), n;
}
function Pi(e, t, n) {
  var r = e.pingCache;
  if (r === null) {
    r = e.pingCache = new ld();
    var l = /* @__PURE__ */ new Set();
    r.set(t, l);
  } else l = r.get(t), l === void 0 && (l = /* @__PURE__ */ new Set(), r.set(t, l));
  l.has(n) || (l.add(n), e = yd.bind(null, e, t, n), t.then(e, e));
}
function Ni(e) {
  do {
    var t;
    if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
    e = e.return;
  } while (e !== null);
  return null;
}
function Ti(e, t, n, r, l) {
  return e.mode & 1 ? (e.flags |= 65536, e.lanes = l, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = He(-1, 1), t.tag = 2, it(n, t, 1))), n.lanes |= 1), e);
}
var od = Ge.ReactCurrentOwner, de = !1;
function ie(e, t, n, r) {
  t.child = e === null ? oa(t, null, n, r) : tn(t, e.child, n, r);
}
function zi(e, t, n, r, l) {
  n = n.render;
  var o = t.ref;
  return Zt(t, l), r = wu(e, t, n, r, o, l), n = ku(), e !== null && !de ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~l, Ye(e, t, l)) : (B && n && iu(t), t.flags |= 1, ie(e, t, r, l), t.child);
}
function Li(e, t, n, r, l) {
  if (e === null) {
    var o = n.type;
    return typeof o == "function" && !Lu(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = o, Ra(e, t, o, r, l)) : (e = Lr(n.type, null, r, t, t.mode, l), e.ref = t.ref, e.return = t, t.child = e);
  }
  if (o = e.child, !(e.lanes & l)) {
    var u = o.memoizedProps;
    if (n = n.compare, n = n !== null ? n : Bn, n(u, r) && e.ref === t.ref) return Ye(e, t, l);
  }
  return t.flags |= 1, e = ct(o, r), e.ref = t.ref, e.return = t, t.child = e;
}
function Ra(e, t, n, r, l) {
  if (e !== null) {
    var o = e.memoizedProps;
    if (Bn(o, r) && e.ref === t.ref) if (de = !1, t.pendingProps = r = o, (e.lanes & l) !== 0) e.flags & 131072 && (de = !0);
    else return t.lanes = e.lanes, Ye(e, t, l);
  }
  return No(e, t, n, r, l);
}
function Ma(e, t, n) {
  var r = t.pendingProps, l = r.children, o = e !== null ? e.memoizedState : null;
  if (r.mode === "hidden") if (!(t.mode & 1)) t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, D(Qt, ve), ve |= n;
  else {
    if (!(n & 1073741824)) return e = o !== null ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = { baseLanes: e, cachePool: null, transitions: null }, t.updateQueue = null, D(Qt, ve), ve |= e, null;
    t.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, r = o !== null ? o.baseLanes : n, D(Qt, ve), ve |= r;
  }
  else o !== null ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, D(Qt, ve), ve |= r;
  return ie(e, t, l, n), t.child;
}
function Oa(e, t) {
  var n = t.ref;
  (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152);
}
function No(e, t, n, r, l) {
  var o = me(n) ? Pt : ue.current;
  return o = bt(t, o), Zt(t, l), n = wu(e, t, n, r, o, l), r = ku(), e !== null && !de ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~l, Ye(e, t, l)) : (B && r && iu(t), t.flags |= 1, ie(e, t, n, l), t.child);
}
function Ri(e, t, n, r, l) {
  if (me(n)) {
    var o = !0;
    Ar(t);
  } else o = !1;
  if (Zt(t, l), t.stateNode === null) Nr(e, t), Ta(t, n, r), xo(t, n, r, l), r = !0;
  else if (e === null) {
    var u = t.stateNode, i = t.memoizedProps;
    u.props = i;
    var s = u.context, a = n.contextType;
    typeof a == "object" && a !== null ? a = Pe(a) : (a = me(n) ? Pt : ue.current, a = bt(t, a));
    var m = n.getDerivedStateFromProps, p = typeof m == "function" || typeof u.getSnapshotBeforeUpdate == "function";
    p || typeof u.UNSAFE_componentWillReceiveProps != "function" && typeof u.componentWillReceiveProps != "function" || (i !== r || s !== a) && xi(t, u, r, a), qe = !1;
    var h = t.memoizedState;
    u.state = h, Kr(t, r, u, l), s = t.memoizedState, i !== r || h !== s || pe.current || qe ? (typeof m == "function" && (Co(t, n, m, r), s = t.memoizedState), (i = qe || Ci(t, n, i, r, h, s, a)) ? (p || typeof u.UNSAFE_componentWillMount != "function" && typeof u.componentWillMount != "function" || (typeof u.componentWillMount == "function" && u.componentWillMount(), typeof u.UNSAFE_componentWillMount == "function" && u.UNSAFE_componentWillMount()), typeof u.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof u.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = s), u.props = r, u.state = s, u.context = a, r = i) : (typeof u.componentDidMount == "function" && (t.flags |= 4194308), r = !1);
  } else {
    u = t.stateNode, ia(e, t), i = t.memoizedProps, a = t.type === t.elementType ? i : ze(t.type, i), u.props = a, p = t.pendingProps, h = u.context, s = n.contextType, typeof s == "object" && s !== null ? s = Pe(s) : (s = me(n) ? Pt : ue.current, s = bt(t, s));
    var v = n.getDerivedStateFromProps;
    (m = typeof v == "function" || typeof u.getSnapshotBeforeUpdate == "function") || typeof u.UNSAFE_componentWillReceiveProps != "function" && typeof u.componentWillReceiveProps != "function" || (i !== p || h !== s) && xi(t, u, r, s), qe = !1, h = t.memoizedState, u.state = h, Kr(t, r, u, l);
    var w = t.memoizedState;
    i !== p || h !== w || pe.current || qe ? (typeof v == "function" && (Co(t, n, v, r), w = t.memoizedState), (a = qe || Ci(t, n, a, r, h, w, s) || !1) ? (m || typeof u.UNSAFE_componentWillUpdate != "function" && typeof u.componentWillUpdate != "function" || (typeof u.componentWillUpdate == "function" && u.componentWillUpdate(r, w, s), typeof u.UNSAFE_componentWillUpdate == "function" && u.UNSAFE_componentWillUpdate(r, w, s)), typeof u.componentDidUpdate == "function" && (t.flags |= 4), typeof u.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof u.componentDidUpdate != "function" || i === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof u.getSnapshotBeforeUpdate != "function" || i === e.memoizedProps && h === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = w), u.props = r, u.state = w, u.context = s, r = a) : (typeof u.componentDidUpdate != "function" || i === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof u.getSnapshotBeforeUpdate != "function" || i === e.memoizedProps && h === e.memoizedState || (t.flags |= 1024), r = !1);
  }
  return To(e, t, n, r, o, l);
}
function To(e, t, n, r, l, o) {
  Oa(e, t);
  var u = (t.flags & 128) !== 0;
  if (!r && !u) return l && vi(t, n, !1), Ye(e, t, o);
  r = t.stateNode, od.current = t;
  var i = u && typeof n.getDerivedStateFromError != "function" ? null : r.render();
  return t.flags |= 1, e !== null && u ? (t.child = tn(t, e.child, null, o), t.child = tn(t, null, i, o)) : ie(e, t, i, o), t.memoizedState = r.state, l && vi(t, n, !0), t.child;
}
function Ia(e) {
  var t = e.stateNode;
  t.pendingContext ? hi(e, t.pendingContext, t.pendingContext !== t.context) : t.context && hi(e, t.context, !1), hu(e, t.containerInfo);
}
function Mi(e, t, n, r, l) {
  return en(), au(l), t.flags |= 256, ie(e, t, n, r), t.child;
}
var zo = { dehydrated: null, treeContext: null, retryLane: 0 };
function Lo(e) {
  return { baseLanes: e, cachePool: null, transitions: null };
}
function ja(e, t, n) {
  var r = t.pendingProps, l = $.current, o = !1, u = (t.flags & 128) !== 0, i;
  if ((i = u) || (i = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0), i ? (o = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (l |= 1), D($, l & 1), e === null)
    return Eo(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (u = r.children, e = r.fallback, o ? (r = t.mode, o = t.child, u = { mode: "hidden", children: u }, !(r & 1) && o !== null ? (o.childLanes = 0, o.pendingProps = u) : o = fl(u, r, 0, null), e = xt(e, r, n, null), o.return = t, e.return = t, o.sibling = e, t.child = o, t.child.memoizedState = Lo(n), t.memoizedState = zo, e) : _u(t, u));
  if (l = e.memoizedState, l !== null && (i = l.dehydrated, i !== null)) return ud(e, t, u, r, i, l, n);
  if (o) {
    o = r.fallback, u = t.mode, l = e.child, i = l.sibling;
    var s = { mode: "hidden", children: r.children };
    return !(u & 1) && t.child !== l ? (r = t.child, r.childLanes = 0, r.pendingProps = s, t.deletions = null) : (r = ct(l, s), r.subtreeFlags = l.subtreeFlags & 14680064), i !== null ? o = ct(i, o) : (o = xt(o, u, n, null), o.flags |= 2), o.return = t, r.return = t, r.sibling = o, t.child = r, r = o, o = t.child, u = e.child.memoizedState, u = u === null ? Lo(n) : { baseLanes: u.baseLanes | n, cachePool: null, transitions: u.transitions }, o.memoizedState = u, o.childLanes = e.childLanes & ~n, t.memoizedState = zo, r;
  }
  return o = e.child, e = o.sibling, r = ct(o, { mode: "visible", children: r.children }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r;
}
function _u(e, t) {
  return t = fl({ mode: "visible", children: t }, e.mode, 0, null), t.return = e, e.child = t;
}
function hr(e, t, n, r) {
  return r !== null && au(r), tn(t, e.child, null, n), e = _u(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
}
function ud(e, t, n, r, l, o, u) {
  if (n)
    return t.flags & 256 ? (t.flags &= -257, r = Vl(Error(y(422))), hr(e, t, u, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, l = t.mode, r = fl({ mode: "visible", children: r.children }, l, 0, null), o = xt(o, l, u, null), o.flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, t.mode & 1 && tn(t, e.child, null, u), t.child.memoizedState = Lo(u), t.memoizedState = zo, o);
  if (!(t.mode & 1)) return hr(e, t, u, null);
  if (l.data === "$!") {
    if (r = l.nextSibling && l.nextSibling.dataset, r) var i = r.dgst;
    return r = i, o = Error(y(419)), r = Vl(o, r, void 0), hr(e, t, u, r);
  }
  if (i = (u & e.childLanes) !== 0, de || i) {
    if (r = q, r !== null) {
      switch (u & -u) {
        case 4:
          l = 2;
          break;
        case 16:
          l = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          l = 32;
          break;
        case 536870912:
          l = 268435456;
          break;
        default:
          l = 0;
      }
      l = l & (r.suspendedLanes | u) ? 0 : l, l !== 0 && l !== o.retryLane && (o.retryLane = l, Xe(e, l), Oe(r, e, l, -1));
    }
    return zu(), r = Vl(Error(y(421))), hr(e, t, u, r);
  }
  return l.data === "$?" ? (t.flags |= 128, t.child = e.child, t = wd.bind(null, e), l._reactRetry = t, null) : (e = o.treeContext, ge = ut(l.nextSibling), ye = t, B = !0, Re = null, e !== null && (Ee[_e++] = Ve, Ee[_e++] = We, Ee[_e++] = Nt, Ve = e.id, We = e.overflow, Nt = t), t = _u(t, r.children), t.flags |= 4096, t);
}
function Oi(e, t, n) {
  e.lanes |= t;
  var r = e.alternate;
  r !== null && (r.lanes |= t), _o(e.return, t, n);
}
function Wl(e, t, n, r, l) {
  var o = e.memoizedState;
  o === null ? e.memoizedState = { isBackwards: t, rendering: null, renderingStartTime: 0, last: r, tail: n, tailMode: l } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = l);
}
function Da(e, t, n) {
  var r = t.pendingProps, l = r.revealOrder, o = r.tail;
  if (ie(e, t, r.children, n), r = $.current, r & 2) r = r & 1 | 2, t.flags |= 128;
  else {
    if (e !== null && e.flags & 128) e: for (e = t.child; e !== null; ) {
      if (e.tag === 13) e.memoizedState !== null && Oi(e, n, t);
      else if (e.tag === 19) Oi(e, n, t);
      else if (e.child !== null) {
        e.child.return = e, e = e.child;
        continue;
      }
      if (e === t) break e;
      for (; e.sibling === null; ) {
        if (e.return === null || e.return === t) break e;
        e = e.return;
      }
      e.sibling.return = e.return, e = e.sibling;
    }
    r &= 1;
  }
  if (D($, r), !(t.mode & 1)) t.memoizedState = null;
  else switch (l) {
    case "forwards":
      for (n = t.child, l = null; n !== null; ) e = n.alternate, e !== null && Xr(e) === null && (l = n), n = n.sibling;
      n = l, n === null ? (l = t.child, t.child = null) : (l = n.sibling, n.sibling = null), Wl(t, !1, l, n, o);
      break;
    case "backwards":
      for (n = null, l = t.child, t.child = null; l !== null; ) {
        if (e = l.alternate, e !== null && Xr(e) === null) {
          t.child = l;
          break;
        }
        e = l.sibling, l.sibling = n, n = l, l = e;
      }
      Wl(t, !0, n, null, o);
      break;
    case "together":
      Wl(t, !1, null, null, void 0);
      break;
    default:
      t.memoizedState = null;
  }
  return t.child;
}
function Nr(e, t) {
  !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2);
}
function Ye(e, t, n) {
  if (e !== null && (t.dependencies = e.dependencies), zt |= t.lanes, !(n & t.childLanes)) return null;
  if (e !== null && t.child !== e.child) throw Error(y(153));
  if (t.child !== null) {
    for (e = t.child, n = ct(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null; ) e = e.sibling, n = n.sibling = ct(e, e.pendingProps), n.return = t;
    n.sibling = null;
  }
  return t.child;
}
function id(e, t, n) {
  switch (t.tag) {
    case 3:
      Ia(t), en();
      break;
    case 5:
      sa(t);
      break;
    case 1:
      me(t.type) && Ar(t);
      break;
    case 4:
      hu(t, t.stateNode.containerInfo);
      break;
    case 10:
      var r = t.type._context, l = t.memoizedProps.value;
      D(Hr, r._currentValue), r._currentValue = l;
      break;
    case 13:
      if (r = t.memoizedState, r !== null)
        return r.dehydrated !== null ? (D($, $.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? ja(e, t, n) : (D($, $.current & 1), e = Ye(e, t, n), e !== null ? e.sibling : null);
      D($, $.current & 1);
      break;
    case 19:
      if (r = (n & t.childLanes) !== 0, e.flags & 128) {
        if (r) return Da(e, t, n);
        t.flags |= 128;
      }
      if (l = t.memoizedState, l !== null && (l.rendering = null, l.tail = null, l.lastEffect = null), D($, $.current), r) break;
      return null;
    case 22:
    case 23:
      return t.lanes = 0, Ma(e, t, n);
  }
  return Ye(e, t, n);
}
var Fa, Ro, Ua, Ba;
Fa = function(e, t) {
  for (var n = t.child; n !== null; ) {
    if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      n.child.return = n, n = n.child;
      continue;
    }
    if (n === t) break;
    for (; n.sibling === null; ) {
      if (n.return === null || n.return === t) return;
      n = n.return;
    }
    n.sibling.return = n.return, n = n.sibling;
  }
};
Ro = function() {
};
Ua = function(e, t, n, r) {
  var l = e.memoizedProps;
  if (l !== r) {
    e = t.stateNode, _t(Be.current);
    var o = null;
    switch (n) {
      case "input":
        l = ql(e, l), r = ql(e, r), o = [];
        break;
      case "select":
        l = V({}, l, { value: void 0 }), r = V({}, r, { value: void 0 }), o = [];
        break;
      case "textarea":
        l = to(e, l), r = to(e, r), o = [];
        break;
      default:
        typeof l.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Br);
    }
    ro(n, r);
    var u;
    n = null;
    for (a in l) if (!r.hasOwnProperty(a) && l.hasOwnProperty(a) && l[a] != null) if (a === "style") {
      var i = l[a];
      for (u in i) i.hasOwnProperty(u) && (n || (n = {}), n[u] = "");
    } else a !== "dangerouslySetInnerHTML" && a !== "children" && a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && a !== "autoFocus" && (Mn.hasOwnProperty(a) ? o || (o = []) : (o = o || []).push(a, null));
    for (a in r) {
      var s = r[a];
      if (i = l != null ? l[a] : void 0, r.hasOwnProperty(a) && s !== i && (s != null || i != null)) if (a === "style") if (i) {
        for (u in i) !i.hasOwnProperty(u) || s && s.hasOwnProperty(u) || (n || (n = {}), n[u] = "");
        for (u in s) s.hasOwnProperty(u) && i[u] !== s[u] && (n || (n = {}), n[u] = s[u]);
      } else n || (o || (o = []), o.push(
        a,
        n
      )), n = s;
      else a === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0, i = i ? i.__html : void 0, s != null && i !== s && (o = o || []).push(a, s)) : a === "children" ? typeof s != "string" && typeof s != "number" || (o = o || []).push(a, "" + s) : a !== "suppressContentEditableWarning" && a !== "suppressHydrationWarning" && (Mn.hasOwnProperty(a) ? (s != null && a === "onScroll" && F("scroll", e), o || i === s || (o = [])) : (o = o || []).push(a, s));
    }
    n && (o = o || []).push("style", n);
    var a = o;
    (t.updateQueue = a) && (t.flags |= 4);
  }
};
Ba = function(e, t, n, r) {
  n !== r && (t.flags |= 4);
};
function vn(e, t) {
  if (!B) switch (e.tailMode) {
    case "hidden":
      t = e.tail;
      for (var n = null; t !== null; ) t.alternate !== null && (n = t), t = t.sibling;
      n === null ? e.tail = null : n.sibling = null;
      break;
    case "collapsed":
      n = e.tail;
      for (var r = null; n !== null; ) n.alternate !== null && (r = n), n = n.sibling;
      r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null;
  }
}
function le(e) {
  var t = e.alternate !== null && e.alternate.child === e.child, n = 0, r = 0;
  if (t) for (var l = e.child; l !== null; ) n |= l.lanes | l.childLanes, r |= l.subtreeFlags & 14680064, r |= l.flags & 14680064, l.return = e, l = l.sibling;
  else for (l = e.child; l !== null; ) n |= l.lanes | l.childLanes, r |= l.subtreeFlags, r |= l.flags, l.return = e, l = l.sibling;
  return e.subtreeFlags |= r, e.childLanes = n, t;
}
function sd(e, t, n) {
  var r = t.pendingProps;
  switch (su(t), t.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return le(t), null;
    case 1:
      return me(t.type) && $r(), le(t), null;
    case 3:
      return r = t.stateNode, nn(), U(pe), U(ue), gu(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (pr(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Re !== null && (Bo(Re), Re = null))), Ro(e, t), le(t), null;
    case 5:
      vu(t);
      var l = _t(Hn.current);
      if (n = t.type, e !== null && t.stateNode != null) Ua(e, t, n, r, l), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
      else {
        if (!r) {
          if (t.stateNode === null) throw Error(y(166));
          return le(t), null;
        }
        if (e = _t(Be.current), pr(t)) {
          r = t.stateNode, n = t.type;
          var o = t.memoizedProps;
          switch (r[Fe] = t, r[Vn] = o, e = (t.mode & 1) !== 0, n) {
            case "dialog":
              F("cancel", r), F("close", r);
              break;
            case "iframe":
            case "object":
            case "embed":
              F("load", r);
              break;
            case "video":
            case "audio":
              for (l = 0; l < En.length; l++) F(En[l], r);
              break;
            case "source":
              F("error", r);
              break;
            case "img":
            case "image":
            case "link":
              F(
                "error",
                r
              ), F("load", r);
              break;
            case "details":
              F("toggle", r);
              break;
            case "input":
              Vu(r, o), F("invalid", r);
              break;
            case "select":
              r._wrapperState = { wasMultiple: !!o.multiple }, F("invalid", r);
              break;
            case "textarea":
              Hu(r, o), F("invalid", r);
          }
          ro(n, o), l = null;
          for (var u in o) if (o.hasOwnProperty(u)) {
            var i = o[u];
            u === "children" ? typeof i == "string" ? r.textContent !== i && (o.suppressHydrationWarning !== !0 && dr(r.textContent, i, e), l = ["children", i]) : typeof i == "number" && r.textContent !== "" + i && (o.suppressHydrationWarning !== !0 && dr(
              r.textContent,
              i,
              e
            ), l = ["children", "" + i]) : Mn.hasOwnProperty(u) && i != null && u === "onScroll" && F("scroll", r);
          }
          switch (n) {
            case "input":
              lr(r), Wu(r, o, !0);
              break;
            case "textarea":
              lr(r), Qu(r);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof o.onClick == "function" && (r.onclick = Br);
          }
          r = l, t.updateQueue = r, r !== null && (t.flags |= 4);
        } else {
          u = l.nodeType === 9 ? l : l.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = ps(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = u.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = u.createElement(n, { is: r.is }) : (e = u.createElement(n), n === "select" && (u = e, r.multiple ? u.multiple = !0 : r.size && (u.size = r.size))) : e = u.createElementNS(e, n), e[Fe] = t, e[Vn] = r, Fa(e, t, !1, !1), t.stateNode = e;
          e: {
            switch (u = lo(n, r), n) {
              case "dialog":
                F("cancel", e), F("close", e), l = r;
                break;
              case "iframe":
              case "object":
              case "embed":
                F("load", e), l = r;
                break;
              case "video":
              case "audio":
                for (l = 0; l < En.length; l++) F(En[l], e);
                l = r;
                break;
              case "source":
                F("error", e), l = r;
                break;
              case "img":
              case "image":
              case "link":
                F(
                  "error",
                  e
                ), F("load", e), l = r;
                break;
              case "details":
                F("toggle", e), l = r;
                break;
              case "input":
                Vu(e, r), l = ql(e, r), F("invalid", e);
                break;
              case "option":
                l = r;
                break;
              case "select":
                e._wrapperState = { wasMultiple: !!r.multiple }, l = V({}, r, { value: void 0 }), F("invalid", e);
                break;
              case "textarea":
                Hu(e, r), l = to(e, r), F("invalid", e);
                break;
              default:
                l = r;
            }
            ro(n, l), i = l;
            for (o in i) if (i.hasOwnProperty(o)) {
              var s = i[o];
              o === "style" ? vs(e, s) : o === "dangerouslySetInnerHTML" ? (s = s ? s.__html : void 0, s != null && ms(e, s)) : o === "children" ? typeof s == "string" ? (n !== "textarea" || s !== "") && On(e, s) : typeof s == "number" && On(e, "" + s) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (Mn.hasOwnProperty(o) ? s != null && o === "onScroll" && F("scroll", e) : s != null && Xo(e, o, s, u));
            }
            switch (n) {
              case "input":
                lr(e), Wu(e, r, !1);
                break;
              case "textarea":
                lr(e), Qu(e);
                break;
              case "option":
                r.value != null && e.setAttribute("value", "" + ft(r.value));
                break;
              case "select":
                e.multiple = !!r.multiple, o = r.value, o != null ? Kt(e, !!r.multiple, o, !1) : r.defaultValue != null && Kt(
                  e,
                  !!r.multiple,
                  r.defaultValue,
                  !0
                );
                break;
              default:
                typeof l.onClick == "function" && (e.onclick = Br);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                r = !!r.autoFocus;
                break e;
              case "img":
                r = !0;
                break e;
              default:
                r = !1;
            }
          }
          r && (t.flags |= 4);
        }
        t.ref !== null && (t.flags |= 512, t.flags |= 2097152);
      }
      return le(t), null;
    case 6:
      if (e && t.stateNode != null) Ba(e, t, e.memoizedProps, r);
      else {
        if (typeof r != "string" && t.stateNode === null) throw Error(y(166));
        if (n = _t(Hn.current), _t(Be.current), pr(t)) {
          if (r = t.stateNode, n = t.memoizedProps, r[Fe] = t, (o = r.nodeValue !== n) && (e = ye, e !== null)) switch (e.tag) {
            case 3:
              dr(r.nodeValue, n, (e.mode & 1) !== 0);
              break;
            case 5:
              e.memoizedProps.suppressHydrationWarning !== !0 && dr(r.nodeValue, n, (e.mode & 1) !== 0);
          }
          o && (t.flags |= 4);
        } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Fe] = t, t.stateNode = r;
      }
      return le(t), null;
    case 13:
      if (U($), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
        if (B && ge !== null && t.mode & 1 && !(t.flags & 128)) ra(), en(), t.flags |= 98560, o = !1;
        else if (o = pr(t), r !== null && r.dehydrated !== null) {
          if (e === null) {
            if (!o) throw Error(y(318));
            if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(y(317));
            o[Fe] = t;
          } else en(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
          le(t), o = !1;
        } else Re !== null && (Bo(Re), Re = null), o = !0;
        if (!o) return t.flags & 65536 ? t : null;
      }
      return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || $.current & 1 ? G === 0 && (G = 3) : zu())), t.updateQueue !== null && (t.flags |= 4), le(t), null);
    case 4:
      return nn(), Ro(e, t), e === null && $n(t.stateNode.containerInfo), le(t), null;
    case 10:
      return du(t.type._context), le(t), null;
    case 17:
      return me(t.type) && $r(), le(t), null;
    case 19:
      if (U($), o = t.memoizedState, o === null) return le(t), null;
      if (r = (t.flags & 128) !== 0, u = o.rendering, u === null) if (r) vn(o, !1);
      else {
        if (G !== 0 || e !== null && e.flags & 128) for (e = t.child; e !== null; ) {
          if (u = Xr(e), u !== null) {
            for (t.flags |= 128, vn(o, !1), r = u.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null; ) o = n, e = r, o.flags &= 14680066, u = o.alternate, u === null ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = u.childLanes, o.lanes = u.lanes, o.child = u.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = u.memoizedProps, o.memoizedState = u.memoizedState, o.updateQueue = u.updateQueue, o.type = u.type, e = u.dependencies, o.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }), n = n.sibling;
            return D($, $.current & 1 | 2), t.child;
          }
          e = e.sibling;
        }
        o.tail !== null && K() > ln && (t.flags |= 128, r = !0, vn(o, !1), t.lanes = 4194304);
      }
      else {
        if (!r) if (e = Xr(u), e !== null) {
          if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), vn(o, !0), o.tail === null && o.tailMode === "hidden" && !u.alternate && !B) return le(t), null;
        } else 2 * K() - o.renderingStartTime > ln && n !== 1073741824 && (t.flags |= 128, r = !0, vn(o, !1), t.lanes = 4194304);
        o.isBackwards ? (u.sibling = t.child, t.child = u) : (n = o.last, n !== null ? n.sibling = u : t.child = u, o.last = u);
      }
      return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = K(), t.sibling = null, n = $.current, D($, r ? n & 1 | 2 : n & 1), t) : (le(t), null);
    case 22:
    case 23:
      return Tu(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? ve & 1073741824 && (le(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : le(t), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(y(156, t.tag));
}
function ad(e, t) {
  switch (su(t), t.tag) {
    case 1:
      return me(t.type) && $r(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 3:
      return nn(), U(pe), U(ue), gu(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
    case 5:
      return vu(t), null;
    case 13:
      if (U($), e = t.memoizedState, e !== null && e.dehydrated !== null) {
        if (t.alternate === null) throw Error(y(340));
        en();
      }
      return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
    case 19:
      return U($), null;
    case 4:
      return nn(), null;
    case 10:
      return du(t.type._context), null;
    case 22:
    case 23:
      return Tu(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var vr = !1, oe = !1, cd = typeof WeakSet == "function" ? WeakSet : Set, E = null;
function Ht(e, t) {
  var n = e.ref;
  if (n !== null) if (typeof n == "function") try {
    n(null);
  } catch (r) {
    H(e, t, r);
  }
  else n.current = null;
}
function Mo(e, t, n) {
  try {
    n();
  } catch (r) {
    H(e, t, r);
  }
}
var Ii = !1;
function fd(e, t) {
  if (ho = Dr, e = Hs(), uu(e)) {
    if ("selectionStart" in e) var n = { start: e.selectionStart, end: e.selectionEnd };
    else e: {
      n = (n = e.ownerDocument) && n.defaultView || window;
      var r = n.getSelection && n.getSelection();
      if (r && r.rangeCount !== 0) {
        n = r.anchorNode;
        var l = r.anchorOffset, o = r.focusNode;
        r = r.focusOffset;
        try {
          n.nodeType, o.nodeType;
        } catch {
          n = null;
          break e;
        }
        var u = 0, i = -1, s = -1, a = 0, m = 0, p = e, h = null;
        t: for (; ; ) {
          for (var v; p !== n || l !== 0 && p.nodeType !== 3 || (i = u + l), p !== o || r !== 0 && p.nodeType !== 3 || (s = u + r), p.nodeType === 3 && (u += p.nodeValue.length), (v = p.firstChild) !== null; )
            h = p, p = v;
          for (; ; ) {
            if (p === e) break t;
            if (h === n && ++a === l && (i = u), h === o && ++m === r && (s = u), (v = p.nextSibling) !== null) break;
            p = h, h = p.parentNode;
          }
          p = v;
        }
        n = i === -1 || s === -1 ? null : { start: i, end: s };
      } else n = null;
    }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (vo = { focusedElem: e, selectionRange: n }, Dr = !1, E = t; E !== null; ) if (t = E, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, E = e;
  else for (; E !== null; ) {
    t = E;
    try {
      var w = t.alternate;
      if (t.flags & 1024) switch (t.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if (w !== null) {
            var k = w.memoizedProps, O = w.memoizedState, f = t.stateNode, c = f.getSnapshotBeforeUpdate(t.elementType === t.type ? k : ze(t.type, k), O);
            f.__reactInternalSnapshotBeforeUpdate = c;
          }
          break;
        case 3:
          var d = t.stateNode.containerInfo;
          d.nodeType === 1 ? d.textContent = "" : d.nodeType === 9 && d.documentElement && d.removeChild(d.documentElement);
          break;
        case 5:
        case 6:
        case 4:
        case 17:
          break;
        default:
          throw Error(y(163));
      }
    } catch (g) {
      H(t, t.return, g);
    }
    if (e = t.sibling, e !== null) {
      e.return = t.return, E = e;
      break;
    }
    E = t.return;
  }
  return w = Ii, Ii = !1, w;
}
function zn(e, t, n) {
  var r = t.updateQueue;
  if (r = r !== null ? r.lastEffect : null, r !== null) {
    var l = r = r.next;
    do {
      if ((l.tag & e) === e) {
        var o = l.destroy;
        l.destroy = void 0, o !== void 0 && Mo(t, n, o);
      }
      l = l.next;
    } while (l !== r);
  }
}
function al(e, t) {
  if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
    var n = t = t.next;
    do {
      if ((n.tag & e) === e) {
        var r = n.create;
        n.destroy = r();
      }
      n = n.next;
    } while (n !== t);
  }
}
function Oo(e) {
  var t = e.ref;
  if (t !== null) {
    var n = e.stateNode;
    switch (e.tag) {
      case 5:
        e = n;
        break;
      default:
        e = n;
    }
    typeof t == "function" ? t(e) : t.current = e;
  }
}
function $a(e) {
  var t = e.alternate;
  t !== null && (e.alternate = null, $a(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Fe], delete t[Vn], delete t[wo], delete t[Xf], delete t[Yf])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
}
function Aa(e) {
  return e.tag === 5 || e.tag === 3 || e.tag === 4;
}
function ji(e) {
  e: for (; ; ) {
    for (; e.sibling === null; ) {
      if (e.return === null || Aa(e.return)) return null;
      e = e.return;
    }
    for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
      if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
      e.child.return = e, e = e.child;
    }
    if (!(e.flags & 2)) return e.stateNode;
  }
}
function Io(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Br));
  else if (r !== 4 && (e = e.child, e !== null)) for (Io(e, t, n), e = e.sibling; e !== null; ) Io(e, t, n), e = e.sibling;
}
function jo(e, t, n) {
  var r = e.tag;
  if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
  else if (r !== 4 && (e = e.child, e !== null)) for (jo(e, t, n), e = e.sibling; e !== null; ) jo(e, t, n), e = e.sibling;
}
var ee = null, Le = !1;
function Ze(e, t, n) {
  for (n = n.child; n !== null; ) Va(e, t, n), n = n.sibling;
}
function Va(e, t, n) {
  if (Ue && typeof Ue.onCommitFiberUnmount == "function") try {
    Ue.onCommitFiberUnmount(tl, n);
  } catch {
  }
  switch (n.tag) {
    case 5:
      oe || Ht(n, t);
    case 6:
      var r = ee, l = Le;
      ee = null, Ze(e, t, n), ee = r, Le = l, ee !== null && (Le ? (e = ee, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : ee.removeChild(n.stateNode));
      break;
    case 18:
      ee !== null && (Le ? (e = ee, n = n.stateNode, e.nodeType === 8 ? Dl(e.parentNode, n) : e.nodeType === 1 && Dl(e, n), Fn(e)) : Dl(ee, n.stateNode));
      break;
    case 4:
      r = ee, l = Le, ee = n.stateNode.containerInfo, Le = !0, Ze(e, t, n), ee = r, Le = l;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!oe && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
        l = r = r.next;
        do {
          var o = l, u = o.destroy;
          o = o.tag, u !== void 0 && (o & 2 || o & 4) && Mo(n, t, u), l = l.next;
        } while (l !== r);
      }
      Ze(e, t, n);
      break;
    case 1:
      if (!oe && (Ht(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
        r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount();
      } catch (i) {
        H(n, t, i);
      }
      Ze(e, t, n);
      break;
    case 21:
      Ze(e, t, n);
      break;
    case 22:
      n.mode & 1 ? (oe = (r = oe) || n.memoizedState !== null, Ze(e, t, n), oe = r) : Ze(e, t, n);
      break;
    default:
      Ze(e, t, n);
  }
}
function Di(e) {
  var t = e.updateQueue;
  if (t !== null) {
    e.updateQueue = null;
    var n = e.stateNode;
    n === null && (n = e.stateNode = new cd()), t.forEach(function(r) {
      var l = kd.bind(null, e, r);
      n.has(r) || (n.add(r), r.then(l, l));
    });
  }
}
function Te(e, t) {
  var n = t.deletions;
  if (n !== null) for (var r = 0; r < n.length; r++) {
    var l = n[r];
    try {
      var o = e, u = t, i = u;
      e: for (; i !== null; ) {
        switch (i.tag) {
          case 5:
            ee = i.stateNode, Le = !1;
            break e;
          case 3:
            ee = i.stateNode.containerInfo, Le = !0;
            break e;
          case 4:
            ee = i.stateNode.containerInfo, Le = !0;
            break e;
        }
        i = i.return;
      }
      if (ee === null) throw Error(y(160));
      Va(o, u, l), ee = null, Le = !1;
      var s = l.alternate;
      s !== null && (s.return = null), l.return = null;
    } catch (a) {
      H(l, t, a);
    }
  }
  if (t.subtreeFlags & 12854) for (t = t.child; t !== null; ) Wa(t, e), t = t.sibling;
}
function Wa(e, t) {
  var n = e.alternate, r = e.flags;
  switch (e.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if (Te(t, e), je(e), r & 4) {
        try {
          zn(3, e, e.return), al(3, e);
        } catch (k) {
          H(e, e.return, k);
        }
        try {
          zn(5, e, e.return);
        } catch (k) {
          H(e, e.return, k);
        }
      }
      break;
    case 1:
      Te(t, e), je(e), r & 512 && n !== null && Ht(n, n.return);
      break;
    case 5:
      if (Te(t, e), je(e), r & 512 && n !== null && Ht(n, n.return), e.flags & 32) {
        var l = e.stateNode;
        try {
          On(l, "");
        } catch (k) {
          H(e, e.return, k);
        }
      }
      if (r & 4 && (l = e.stateNode, l != null)) {
        var o = e.memoizedProps, u = n !== null ? n.memoizedProps : o, i = e.type, s = e.updateQueue;
        if (e.updateQueue = null, s !== null) try {
          i === "input" && o.type === "radio" && o.name != null && fs(l, o), lo(i, u);
          var a = lo(i, o);
          for (u = 0; u < s.length; u += 2) {
            var m = s[u], p = s[u + 1];
            m === "style" ? vs(l, p) : m === "dangerouslySetInnerHTML" ? ms(l, p) : m === "children" ? On(l, p) : Xo(l, m, p, a);
          }
          switch (i) {
            case "input":
              bl(l, o);
              break;
            case "textarea":
              ds(l, o);
              break;
            case "select":
              var h = l._wrapperState.wasMultiple;
              l._wrapperState.wasMultiple = !!o.multiple;
              var v = o.value;
              v != null ? Kt(l, !!o.multiple, v, !1) : h !== !!o.multiple && (o.defaultValue != null ? Kt(
                l,
                !!o.multiple,
                o.defaultValue,
                !0
              ) : Kt(l, !!o.multiple, o.multiple ? [] : "", !1));
          }
          l[Vn] = o;
        } catch (k) {
          H(e, e.return, k);
        }
      }
      break;
    case 6:
      if (Te(t, e), je(e), r & 4) {
        if (e.stateNode === null) throw Error(y(162));
        l = e.stateNode, o = e.memoizedProps;
        try {
          l.nodeValue = o;
        } catch (k) {
          H(e, e.return, k);
        }
      }
      break;
    case 3:
      if (Te(t, e), je(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
        Fn(t.containerInfo);
      } catch (k) {
        H(e, e.return, k);
      }
      break;
    case 4:
      Te(t, e), je(e);
      break;
    case 13:
      Te(t, e), je(e), l = e.child, l.flags & 8192 && (o = l.memoizedState !== null, l.stateNode.isHidden = o, !o || l.alternate !== null && l.alternate.memoizedState !== null || (Pu = K())), r & 4 && Di(e);
      break;
    case 22:
      if (m = n !== null && n.memoizedState !== null, e.mode & 1 ? (oe = (a = oe) || m, Te(t, e), oe = a) : Te(t, e), je(e), r & 8192) {
        if (a = e.memoizedState !== null, (e.stateNode.isHidden = a) && !m && e.mode & 1) for (E = e, m = e.child; m !== null; ) {
          for (p = E = m; E !== null; ) {
            switch (h = E, v = h.child, h.tag) {
              case 0:
              case 11:
              case 14:
              case 15:
                zn(4, h, h.return);
                break;
              case 1:
                Ht(h, h.return);
                var w = h.stateNode;
                if (typeof w.componentWillUnmount == "function") {
                  r = h, n = h.return;
                  try {
                    t = r, w.props = t.memoizedProps, w.state = t.memoizedState, w.componentWillUnmount();
                  } catch (k) {
                    H(r, n, k);
                  }
                }
                break;
              case 5:
                Ht(h, h.return);
                break;
              case 22:
                if (h.memoizedState !== null) {
                  Ui(p);
                  continue;
                }
            }
            v !== null ? (v.return = h, E = v) : Ui(p);
          }
          m = m.sibling;
        }
        e: for (m = null, p = e; ; ) {
          if (p.tag === 5) {
            if (m === null) {
              m = p;
              try {
                l = p.stateNode, a ? (o = l.style, typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (i = p.stateNode, s = p.memoizedProps.style, u = s != null && s.hasOwnProperty("display") ? s.display : null, i.style.display = hs("display", u));
              } catch (k) {
                H(e, e.return, k);
              }
            }
          } else if (p.tag === 6) {
            if (m === null) try {
              p.stateNode.nodeValue = a ? "" : p.memoizedProps;
            } catch (k) {
              H(e, e.return, k);
            }
          } else if ((p.tag !== 22 && p.tag !== 23 || p.memoizedState === null || p === e) && p.child !== null) {
            p.child.return = p, p = p.child;
            continue;
          }
          if (p === e) break e;
          for (; p.sibling === null; ) {
            if (p.return === null || p.return === e) break e;
            m === p && (m = null), p = p.return;
          }
          m === p && (m = null), p.sibling.return = p.return, p = p.sibling;
        }
      }
      break;
    case 19:
      Te(t, e), je(e), r & 4 && Di(e);
      break;
    case 21:
      break;
    default:
      Te(
        t,
        e
      ), je(e);
  }
}
function je(e) {
  var t = e.flags;
  if (t & 2) {
    try {
      e: {
        for (var n = e.return; n !== null; ) {
          if (Aa(n)) {
            var r = n;
            break e;
          }
          n = n.return;
        }
        throw Error(y(160));
      }
      switch (r.tag) {
        case 5:
          var l = r.stateNode;
          r.flags & 32 && (On(l, ""), r.flags &= -33);
          var o = ji(e);
          jo(e, o, l);
          break;
        case 3:
        case 4:
          var u = r.stateNode.containerInfo, i = ji(e);
          Io(e, i, u);
          break;
        default:
          throw Error(y(161));
      }
    } catch (s) {
      H(e, e.return, s);
    }
    e.flags &= -3;
  }
  t & 4096 && (e.flags &= -4097);
}
function dd(e, t, n) {
  E = e, Ha(e);
}
function Ha(e, t, n) {
  for (var r = (e.mode & 1) !== 0; E !== null; ) {
    var l = E, o = l.child;
    if (l.tag === 22 && r) {
      var u = l.memoizedState !== null || vr;
      if (!u) {
        var i = l.alternate, s = i !== null && i.memoizedState !== null || oe;
        i = vr;
        var a = oe;
        if (vr = u, (oe = s) && !a) for (E = l; E !== null; ) u = E, s = u.child, u.tag === 22 && u.memoizedState !== null ? Bi(l) : s !== null ? (s.return = u, E = s) : Bi(l);
        for (; o !== null; ) E = o, Ha(o), o = o.sibling;
        E = l, vr = i, oe = a;
      }
      Fi(e);
    } else l.subtreeFlags & 8772 && o !== null ? (o.return = l, E = o) : Fi(e);
  }
}
function Fi(e) {
  for (; E !== null; ) {
    var t = E;
    if (t.flags & 8772) {
      var n = t.alternate;
      try {
        if (t.flags & 8772) switch (t.tag) {
          case 0:
          case 11:
          case 15:
            oe || al(5, t);
            break;
          case 1:
            var r = t.stateNode;
            if (t.flags & 4 && !oe) if (n === null) r.componentDidMount();
            else {
              var l = t.elementType === t.type ? n.memoizedProps : ze(t.type, n.memoizedProps);
              r.componentDidUpdate(l, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate);
            }
            var o = t.updateQueue;
            o !== null && Si(t, o, r);
            break;
          case 3:
            var u = t.updateQueue;
            if (u !== null) {
              if (n = null, t.child !== null) switch (t.child.tag) {
                case 5:
                  n = t.child.stateNode;
                  break;
                case 1:
                  n = t.child.stateNode;
              }
              Si(t, u, n);
            }
            break;
          case 5:
            var i = t.stateNode;
            if (n === null && t.flags & 4) {
              n = i;
              var s = t.memoizedProps;
              switch (t.type) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  s.autoFocus && n.focus();
                  break;
                case "img":
                  s.src && (n.src = s.src);
              }
            }
            break;
          case 6:
            break;
          case 4:
            break;
          case 12:
            break;
          case 13:
            if (t.memoizedState === null) {
              var a = t.alternate;
              if (a !== null) {
                var m = a.memoizedState;
                if (m !== null) {
                  var p = m.dehydrated;
                  p !== null && Fn(p);
                }
              }
            }
            break;
          case 19:
          case 17:
          case 21:
          case 22:
          case 23:
          case 25:
            break;
          default:
            throw Error(y(163));
        }
        oe || t.flags & 512 && Oo(t);
      } catch (h) {
        H(t, t.return, h);
      }
    }
    if (t === e) {
      E = null;
      break;
    }
    if (n = t.sibling, n !== null) {
      n.return = t.return, E = n;
      break;
    }
    E = t.return;
  }
}
function Ui(e) {
  for (; E !== null; ) {
    var t = E;
    if (t === e) {
      E = null;
      break;
    }
    var n = t.sibling;
    if (n !== null) {
      n.return = t.return, E = n;
      break;
    }
    E = t.return;
  }
}
function Bi(e) {
  for (; E !== null; ) {
    var t = E;
    try {
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          var n = t.return;
          try {
            al(4, t);
          } catch (s) {
            H(t, n, s);
          }
          break;
        case 1:
          var r = t.stateNode;
          if (typeof r.componentDidMount == "function") {
            var l = t.return;
            try {
              r.componentDidMount();
            } catch (s) {
              H(t, l, s);
            }
          }
          var o = t.return;
          try {
            Oo(t);
          } catch (s) {
            H(t, o, s);
          }
          break;
        case 5:
          var u = t.return;
          try {
            Oo(t);
          } catch (s) {
            H(t, u, s);
          }
      }
    } catch (s) {
      H(t, t.return, s);
    }
    if (t === e) {
      E = null;
      break;
    }
    var i = t.sibling;
    if (i !== null) {
      i.return = t.return, E = i;
      break;
    }
    E = t.return;
  }
}
var pd = Math.ceil, Zr = Ge.ReactCurrentDispatcher, Cu = Ge.ReactCurrentOwner, xe = Ge.ReactCurrentBatchConfig, M = 0, q = null, X = null, te = 0, ve = 0, Qt = mt(0), G = 0, Yn = null, zt = 0, cl = 0, xu = 0, Ln = null, fe = null, Pu = 0, ln = 1 / 0, $e = null, Jr = !1, Do = null, st = null, gr = !1, nt = null, qr = 0, Rn = 0, Fo = null, Tr = -1, zr = 0;
function se() {
  return M & 6 ? K() : Tr !== -1 ? Tr : Tr = K();
}
function at(e) {
  return e.mode & 1 ? M & 2 && te !== 0 ? te & -te : Zf.transition !== null ? (zr === 0 && (zr = Ts()), zr) : (e = j, e !== 0 || (e = window.event, e = e === void 0 ? 16 : js(e.type)), e) : 1;
}
function Oe(e, t, n, r) {
  if (50 < Rn) throw Rn = 0, Fo = null, Error(y(185));
  Zn(e, n, r), (!(M & 2) || e !== q) && (e === q && (!(M & 2) && (cl |= n), G === 4 && et(e, te)), he(e, r), n === 1 && M === 0 && !(t.mode & 1) && (ln = K() + 500, ul && ht()));
}
function he(e, t) {
  var n = e.callbackNode;
  Gc(e, t);
  var r = jr(e, e === q ? te : 0);
  if (r === 0) n !== null && Yu(n), e.callbackNode = null, e.callbackPriority = 0;
  else if (t = r & -r, e.callbackPriority !== t) {
    if (n != null && Yu(n), t === 1) e.tag === 0 ? Gf($i.bind(null, e)) : ea($i.bind(null, e)), Qf(function() {
      !(M & 6) && ht();
    }), n = null;
    else {
      switch (zs(r)) {
        case 1:
          n = qo;
          break;
        case 4:
          n = Ps;
          break;
        case 16:
          n = Ir;
          break;
        case 536870912:
          n = Ns;
          break;
        default:
          n = Ir;
      }
      n = qa(n, Qa.bind(null, e));
    }
    e.callbackPriority = t, e.callbackNode = n;
  }
}
function Qa(e, t) {
  if (Tr = -1, zr = 0, M & 6) throw Error(y(327));
  var n = e.callbackNode;
  if (Jt() && e.callbackNode !== n) return null;
  var r = jr(e, e === q ? te : 0);
  if (r === 0) return null;
  if (r & 30 || r & e.expiredLanes || t) t = br(e, r);
  else {
    t = r;
    var l = M;
    M |= 2;
    var o = Xa();
    (q !== e || te !== t) && ($e = null, ln = K() + 500, Ct(e, t));
    do
      try {
        vd();
        break;
      } catch (i) {
        Ka(e, i);
      }
    while (!0);
    fu(), Zr.current = o, M = l, X !== null ? t = 0 : (q = null, te = 0, t = G);
  }
  if (t !== 0) {
    if (t === 2 && (l = ao(e), l !== 0 && (r = l, t = Uo(e, l))), t === 1) throw n = Yn, Ct(e, 0), et(e, r), he(e, K()), n;
    if (t === 6) et(e, r);
    else {
      if (l = e.current.alternate, !(r & 30) && !md(l) && (t = br(e, r), t === 2 && (o = ao(e), o !== 0 && (r = o, t = Uo(e, o))), t === 1)) throw n = Yn, Ct(e, 0), et(e, r), he(e, K()), n;
      switch (e.finishedWork = l, e.finishedLanes = r, t) {
        case 0:
        case 1:
          throw Error(y(345));
        case 2:
          kt(e, fe, $e);
          break;
        case 3:
          if (et(e, r), (r & 130023424) === r && (t = Pu + 500 - K(), 10 < t)) {
            if (jr(e, 0) !== 0) break;
            if (l = e.suspendedLanes, (l & r) !== r) {
              se(), e.pingedLanes |= e.suspendedLanes & l;
              break;
            }
            e.timeoutHandle = yo(kt.bind(null, e, fe, $e), t);
            break;
          }
          kt(e, fe, $e);
          break;
        case 4:
          if (et(e, r), (r & 4194240) === r) break;
          for (t = e.eventTimes, l = -1; 0 < r; ) {
            var u = 31 - Me(r);
            o = 1 << u, u = t[u], u > l && (l = u), r &= ~o;
          }
          if (r = l, r = K() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * pd(r / 1960)) - r, 10 < r) {
            e.timeoutHandle = yo(kt.bind(null, e, fe, $e), r);
            break;
          }
          kt(e, fe, $e);
          break;
        case 5:
          kt(e, fe, $e);
          break;
        default:
          throw Error(y(329));
      }
    }
  }
  return he(e, K()), e.callbackNode === n ? Qa.bind(null, e) : null;
}
function Uo(e, t) {
  var n = Ln;
  return e.current.memoizedState.isDehydrated && (Ct(e, t).flags |= 256), e = br(e, t), e !== 2 && (t = fe, fe = n, t !== null && Bo(t)), e;
}
function Bo(e) {
  fe === null ? fe = e : fe.push.apply(fe, e);
}
function md(e) {
  for (var t = e; ; ) {
    if (t.flags & 16384) {
      var n = t.updateQueue;
      if (n !== null && (n = n.stores, n !== null)) for (var r = 0; r < n.length; r++) {
        var l = n[r], o = l.getSnapshot;
        l = l.value;
        try {
          if (!Ie(o(), l)) return !1;
        } catch {
          return !1;
        }
      }
    }
    if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
    else {
      if (t === e) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) return !0;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
  }
  return !0;
}
function et(e, t) {
  for (t &= ~xu, t &= ~cl, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t; ) {
    var n = 31 - Me(t), r = 1 << n;
    e[n] = -1, t &= ~r;
  }
}
function $i(e) {
  if (M & 6) throw Error(y(327));
  Jt();
  var t = jr(e, 0);
  if (!(t & 1)) return he(e, K()), null;
  var n = br(e, t);
  if (e.tag !== 0 && n === 2) {
    var r = ao(e);
    r !== 0 && (t = r, n = Uo(e, r));
  }
  if (n === 1) throw n = Yn, Ct(e, 0), et(e, t), he(e, K()), n;
  if (n === 6) throw Error(y(345));
  return e.finishedWork = e.current.alternate, e.finishedLanes = t, kt(e, fe, $e), he(e, K()), null;
}
function Nu(e, t) {
  var n = M;
  M |= 1;
  try {
    return e(t);
  } finally {
    M = n, M === 0 && (ln = K() + 500, ul && ht());
  }
}
function Lt(e) {
  nt !== null && nt.tag === 0 && !(M & 6) && Jt();
  var t = M;
  M |= 1;
  var n = xe.transition, r = j;
  try {
    if (xe.transition = null, j = 1, e) return e();
  } finally {
    j = r, xe.transition = n, M = t, !(M & 6) && ht();
  }
}
function Tu() {
  ve = Qt.current, U(Qt);
}
function Ct(e, t) {
  e.finishedWork = null, e.finishedLanes = 0;
  var n = e.timeoutHandle;
  if (n !== -1 && (e.timeoutHandle = -1, Hf(n)), X !== null) for (n = X.return; n !== null; ) {
    var r = n;
    switch (su(r), r.tag) {
      case 1:
        r = r.type.childContextTypes, r != null && $r();
        break;
      case 3:
        nn(), U(pe), U(ue), gu();
        break;
      case 5:
        vu(r);
        break;
      case 4:
        nn();
        break;
      case 13:
        U($);
        break;
      case 19:
        U($);
        break;
      case 10:
        du(r.type._context);
        break;
      case 22:
      case 23:
        Tu();
    }
    n = n.return;
  }
  if (q = e, X = e = ct(e.current, null), te = ve = t, G = 0, Yn = null, xu = cl = zt = 0, fe = Ln = null, Et !== null) {
    for (t = 0; t < Et.length; t++) if (n = Et[t], r = n.interleaved, r !== null) {
      n.interleaved = null;
      var l = r.next, o = n.pending;
      if (o !== null) {
        var u = o.next;
        o.next = l, r.next = u;
      }
      n.pending = r;
    }
    Et = null;
  }
  return e;
}
function Ka(e, t) {
  do {
    var n = X;
    try {
      if (fu(), xr.current = Gr, Yr) {
        for (var r = A.memoizedState; r !== null; ) {
          var l = r.queue;
          l !== null && (l.pending = null), r = r.next;
        }
        Yr = !1;
      }
      if (Tt = 0, J = Y = A = null, Tn = !1, Qn = 0, Cu.current = null, n === null || n.return === null) {
        G = 1, Yn = t, X = null;
        break;
      }
      e: {
        var o = e, u = n.return, i = n, s = t;
        if (t = te, i.flags |= 32768, s !== null && typeof s == "object" && typeof s.then == "function") {
          var a = s, m = i, p = m.tag;
          if (!(m.mode & 1) && (p === 0 || p === 11 || p === 15)) {
            var h = m.alternate;
            h ? (m.updateQueue = h.updateQueue, m.memoizedState = h.memoizedState, m.lanes = h.lanes) : (m.updateQueue = null, m.memoizedState = null);
          }
          var v = Ni(u);
          if (v !== null) {
            v.flags &= -257, Ti(v, u, i, o, t), v.mode & 1 && Pi(o, a, t), t = v, s = a;
            var w = t.updateQueue;
            if (w === null) {
              var k = /* @__PURE__ */ new Set();
              k.add(s), t.updateQueue = k;
            } else w.add(s);
            break e;
          } else {
            if (!(t & 1)) {
              Pi(o, a, t), zu();
              break e;
            }
            s = Error(y(426));
          }
        } else if (B && i.mode & 1) {
          var O = Ni(u);
          if (O !== null) {
            !(O.flags & 65536) && (O.flags |= 256), Ti(O, u, i, o, t), au(rn(s, i));
            break e;
          }
        }
        o = s = rn(s, i), G !== 4 && (G = 2), Ln === null ? Ln = [o] : Ln.push(o), o = u;
        do {
          switch (o.tag) {
            case 3:
              o.flags |= 65536, t &= -t, o.lanes |= t;
              var f = za(o, s, t);
              ki(o, f);
              break e;
            case 1:
              i = s;
              var c = o.type, d = o.stateNode;
              if (!(o.flags & 128) && (typeof c.getDerivedStateFromError == "function" || d !== null && typeof d.componentDidCatch == "function" && (st === null || !st.has(d)))) {
                o.flags |= 65536, t &= -t, o.lanes |= t;
                var g = La(o, i, t);
                ki(o, g);
                break e;
              }
          }
          o = o.return;
        } while (o !== null);
      }
      Ga(n);
    } catch (S) {
      t = S, X === n && n !== null && (X = n = n.return);
      continue;
    }
    break;
  } while (!0);
}
function Xa() {
  var e = Zr.current;
  return Zr.current = Gr, e === null ? Gr : e;
}
function zu() {
  (G === 0 || G === 3 || G === 2) && (G = 4), q === null || !(zt & 268435455) && !(cl & 268435455) || et(q, te);
}
function br(e, t) {
  var n = M;
  M |= 2;
  var r = Xa();
  (q !== e || te !== t) && ($e = null, Ct(e, t));
  do
    try {
      hd();
      break;
    } catch (l) {
      Ka(e, l);
    }
  while (!0);
  if (fu(), M = n, Zr.current = r, X !== null) throw Error(y(261));
  return q = null, te = 0, G;
}
function hd() {
  for (; X !== null; ) Ya(X);
}
function vd() {
  for (; X !== null && !$c(); ) Ya(X);
}
function Ya(e) {
  var t = Ja(e.alternate, e, ve);
  e.memoizedProps = e.pendingProps, t === null ? Ga(e) : X = t, Cu.current = null;
}
function Ga(e) {
  var t = e;
  do {
    var n = t.alternate;
    if (e = t.return, t.flags & 32768) {
      if (n = ad(n, t), n !== null) {
        n.flags &= 32767, X = n;
        return;
      }
      if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
      else {
        G = 6, X = null;
        return;
      }
    } else if (n = sd(n, t, ve), n !== null) {
      X = n;
      return;
    }
    if (t = t.sibling, t !== null) {
      X = t;
      return;
    }
    X = t = e;
  } while (t !== null);
  G === 0 && (G = 5);
}
function kt(e, t, n) {
  var r = j, l = xe.transition;
  try {
    xe.transition = null, j = 1, gd(e, t, n, r);
  } finally {
    xe.transition = l, j = r;
  }
  return null;
}
function gd(e, t, n, r) {
  do
    Jt();
  while (nt !== null);
  if (M & 6) throw Error(y(327));
  n = e.finishedWork;
  var l = e.finishedLanes;
  if (n === null) return null;
  if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(y(177));
  e.callbackNode = null, e.callbackPriority = 0;
  var o = n.lanes | n.childLanes;
  if (Zc(e, o), e === q && (X = q = null, te = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || gr || (gr = !0, qa(Ir, function() {
    return Jt(), null;
  })), o = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || o) {
    o = xe.transition, xe.transition = null;
    var u = j;
    j = 1;
    var i = M;
    M |= 4, Cu.current = null, fd(e, n), Wa(n, e), Ff(vo), Dr = !!ho, vo = ho = null, e.current = n, dd(n), Ac(), M = i, j = u, xe.transition = o;
  } else e.current = n;
  if (gr && (gr = !1, nt = e, qr = l), o = e.pendingLanes, o === 0 && (st = null), Hc(n.stateNode), he(e, K()), t !== null) for (r = e.onRecoverableError, n = 0; n < t.length; n++) l = t[n], r(l.value, { componentStack: l.stack, digest: l.digest });
  if (Jr) throw Jr = !1, e = Do, Do = null, e;
  return qr & 1 && e.tag !== 0 && Jt(), o = e.pendingLanes, o & 1 ? e === Fo ? Rn++ : (Rn = 0, Fo = e) : Rn = 0, ht(), null;
}
function Jt() {
  if (nt !== null) {
    var e = zs(qr), t = xe.transition, n = j;
    try {
      if (xe.transition = null, j = 16 > e ? 16 : e, nt === null) var r = !1;
      else {
        if (e = nt, nt = null, qr = 0, M & 6) throw Error(y(331));
        var l = M;
        for (M |= 4, E = e.current; E !== null; ) {
          var o = E, u = o.child;
          if (E.flags & 16) {
            var i = o.deletions;
            if (i !== null) {
              for (var s = 0; s < i.length; s++) {
                var a = i[s];
                for (E = a; E !== null; ) {
                  var m = E;
                  switch (m.tag) {
                    case 0:
                    case 11:
                    case 15:
                      zn(8, m, o);
                  }
                  var p = m.child;
                  if (p !== null) p.return = m, E = p;
                  else for (; E !== null; ) {
                    m = E;
                    var h = m.sibling, v = m.return;
                    if ($a(m), m === a) {
                      E = null;
                      break;
                    }
                    if (h !== null) {
                      h.return = v, E = h;
                      break;
                    }
                    E = v;
                  }
                }
              }
              var w = o.alternate;
              if (w !== null) {
                var k = w.child;
                if (k !== null) {
                  w.child = null;
                  do {
                    var O = k.sibling;
                    k.sibling = null, k = O;
                  } while (k !== null);
                }
              }
              E = o;
            }
          }
          if (o.subtreeFlags & 2064 && u !== null) u.return = o, E = u;
          else e: for (; E !== null; ) {
            if (o = E, o.flags & 2048) switch (o.tag) {
              case 0:
              case 11:
              case 15:
                zn(9, o, o.return);
            }
            var f = o.sibling;
            if (f !== null) {
              f.return = o.return, E = f;
              break e;
            }
            E = o.return;
          }
        }
        var c = e.current;
        for (E = c; E !== null; ) {
          u = E;
          var d = u.child;
          if (u.subtreeFlags & 2064 && d !== null) d.return = u, E = d;
          else e: for (u = c; E !== null; ) {
            if (i = E, i.flags & 2048) try {
              switch (i.tag) {
                case 0:
                case 11:
                case 15:
                  al(9, i);
              }
            } catch (S) {
              H(i, i.return, S);
            }
            if (i === u) {
              E = null;
              break e;
            }
            var g = i.sibling;
            if (g !== null) {
              g.return = i.return, E = g;
              break e;
            }
            E = i.return;
          }
        }
        if (M = l, ht(), Ue && typeof Ue.onPostCommitFiberRoot == "function") try {
          Ue.onPostCommitFiberRoot(tl, e);
        } catch {
        }
        r = !0;
      }
      return r;
    } finally {
      j = n, xe.transition = t;
    }
  }
  return !1;
}
function Ai(e, t, n) {
  t = rn(n, t), t = za(e, t, 1), e = it(e, t, 1), t = se(), e !== null && (Zn(e, 1, t), he(e, t));
}
function H(e, t, n) {
  if (e.tag === 3) Ai(e, e, n);
  else for (; t !== null; ) {
    if (t.tag === 3) {
      Ai(t, e, n);
      break;
    } else if (t.tag === 1) {
      var r = t.stateNode;
      if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (st === null || !st.has(r))) {
        e = rn(n, e), e = La(t, e, 1), t = it(t, e, 1), e = se(), t !== null && (Zn(t, 1, e), he(t, e));
        break;
      }
    }
    t = t.return;
  }
}
function yd(e, t, n) {
  var r = e.pingCache;
  r !== null && r.delete(t), t = se(), e.pingedLanes |= e.suspendedLanes & n, q === e && (te & n) === n && (G === 4 || G === 3 && (te & 130023424) === te && 500 > K() - Pu ? Ct(e, 0) : xu |= n), he(e, t);
}
function Za(e, t) {
  t === 0 && (e.mode & 1 ? (t = ir, ir <<= 1, !(ir & 130023424) && (ir = 4194304)) : t = 1);
  var n = se();
  e = Xe(e, t), e !== null && (Zn(e, t, n), he(e, n));
}
function wd(e) {
  var t = e.memoizedState, n = 0;
  t !== null && (n = t.retryLane), Za(e, n);
}
function kd(e, t) {
  var n = 0;
  switch (e.tag) {
    case 13:
      var r = e.stateNode, l = e.memoizedState;
      l !== null && (n = l.retryLane);
      break;
    case 19:
      r = e.stateNode;
      break;
    default:
      throw Error(y(314));
  }
  r !== null && r.delete(t), Za(e, n);
}
var Ja;
Ja = function(e, t, n) {
  if (e !== null) if (e.memoizedProps !== t.pendingProps || pe.current) de = !0;
  else {
    if (!(e.lanes & n) && !(t.flags & 128)) return de = !1, id(e, t, n);
    de = !!(e.flags & 131072);
  }
  else de = !1, B && t.flags & 1048576 && ta(t, Wr, t.index);
  switch (t.lanes = 0, t.tag) {
    case 2:
      var r = t.type;
      Nr(e, t), e = t.pendingProps;
      var l = bt(t, ue.current);
      Zt(t, n), l = wu(null, t, r, e, l, n);
      var o = ku();
      return t.flags |= 1, typeof l == "object" && l !== null && typeof l.render == "function" && l.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, me(r) ? (o = !0, Ar(t)) : o = !1, t.memoizedState = l.state !== null && l.state !== void 0 ? l.state : null, mu(t), l.updater = sl, t.stateNode = l, l._reactInternals = t, xo(t, r, e, n), t = To(null, t, r, !0, o, n)) : (t.tag = 0, B && o && iu(t), ie(null, t, l, n), t = t.child), t;
    case 16:
      r = t.elementType;
      e: {
        switch (Nr(e, t), e = t.pendingProps, l = r._init, r = l(r._payload), t.type = r, l = t.tag = Ed(r), e = ze(r, e), l) {
          case 0:
            t = No(null, t, r, e, n);
            break e;
          case 1:
            t = Ri(null, t, r, e, n);
            break e;
          case 11:
            t = zi(null, t, r, e, n);
            break e;
          case 14:
            t = Li(null, t, r, ze(r.type, e), n);
            break e;
        }
        throw Error(y(
          306,
          r,
          ""
        ));
      }
      return t;
    case 0:
      return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ze(r, l), No(e, t, r, l, n);
    case 1:
      return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ze(r, l), Ri(e, t, r, l, n);
    case 3:
      e: {
        if (Ia(t), e === null) throw Error(y(387));
        r = t.pendingProps, o = t.memoizedState, l = o.element, ia(e, t), Kr(t, r, null, n);
        var u = t.memoizedState;
        if (r = u.element, o.isDehydrated) if (o = { element: r, isDehydrated: !1, cache: u.cache, pendingSuspenseBoundaries: u.pendingSuspenseBoundaries, transitions: u.transitions }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
          l = rn(Error(y(423)), t), t = Mi(e, t, r, n, l);
          break e;
        } else if (r !== l) {
          l = rn(Error(y(424)), t), t = Mi(e, t, r, n, l);
          break e;
        } else for (ge = ut(t.stateNode.containerInfo.firstChild), ye = t, B = !0, Re = null, n = oa(t, null, r, n), t.child = n; n; ) n.flags = n.flags & -3 | 4096, n = n.sibling;
        else {
          if (en(), r === l) {
            t = Ye(e, t, n);
            break e;
          }
          ie(e, t, r, n);
        }
        t = t.child;
      }
      return t;
    case 5:
      return sa(t), e === null && Eo(t), r = t.type, l = t.pendingProps, o = e !== null ? e.memoizedProps : null, u = l.children, go(r, l) ? u = null : o !== null && go(r, o) && (t.flags |= 32), Oa(e, t), ie(e, t, u, n), t.child;
    case 6:
      return e === null && Eo(t), null;
    case 13:
      return ja(e, t, n);
    case 4:
      return hu(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = tn(t, null, r, n) : ie(e, t, r, n), t.child;
    case 11:
      return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ze(r, l), zi(e, t, r, l, n);
    case 7:
      return ie(e, t, t.pendingProps, n), t.child;
    case 8:
      return ie(e, t, t.pendingProps.children, n), t.child;
    case 12:
      return ie(e, t, t.pendingProps.children, n), t.child;
    case 10:
      e: {
        if (r = t.type._context, l = t.pendingProps, o = t.memoizedProps, u = l.value, D(Hr, r._currentValue), r._currentValue = u, o !== null) if (Ie(o.value, u)) {
          if (o.children === l.children && !pe.current) {
            t = Ye(e, t, n);
            break e;
          }
        } else for (o = t.child, o !== null && (o.return = t); o !== null; ) {
          var i = o.dependencies;
          if (i !== null) {
            u = o.child;
            for (var s = i.firstContext; s !== null; ) {
              if (s.context === r) {
                if (o.tag === 1) {
                  s = He(-1, n & -n), s.tag = 2;
                  var a = o.updateQueue;
                  if (a !== null) {
                    a = a.shared;
                    var m = a.pending;
                    m === null ? s.next = s : (s.next = m.next, m.next = s), a.pending = s;
                  }
                }
                o.lanes |= n, s = o.alternate, s !== null && (s.lanes |= n), _o(
                  o.return,
                  n,
                  t
                ), i.lanes |= n;
                break;
              }
              s = s.next;
            }
          } else if (o.tag === 10) u = o.type === t.type ? null : o.child;
          else if (o.tag === 18) {
            if (u = o.return, u === null) throw Error(y(341));
            u.lanes |= n, i = u.alternate, i !== null && (i.lanes |= n), _o(u, n, t), u = o.sibling;
          } else u = o.child;
          if (u !== null) u.return = o;
          else for (u = o; u !== null; ) {
            if (u === t) {
              u = null;
              break;
            }
            if (o = u.sibling, o !== null) {
              o.return = u.return, u = o;
              break;
            }
            u = u.return;
          }
          o = u;
        }
        ie(e, t, l.children, n), t = t.child;
      }
      return t;
    case 9:
      return l = t.type, r = t.pendingProps.children, Zt(t, n), l = Pe(l), r = r(l), t.flags |= 1, ie(e, t, r, n), t.child;
    case 14:
      return r = t.type, l = ze(r, t.pendingProps), l = ze(r.type, l), Li(e, t, r, l, n);
    case 15:
      return Ra(e, t, t.type, t.pendingProps, n);
    case 17:
      return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ze(r, l), Nr(e, t), t.tag = 1, me(r) ? (e = !0, Ar(t)) : e = !1, Zt(t, n), Ta(t, r, l), xo(t, r, l, n), To(null, t, r, !0, e, n);
    case 19:
      return Da(e, t, n);
    case 22:
      return Ma(e, t, n);
  }
  throw Error(y(156, t.tag));
};
function qa(e, t) {
  return xs(e, t);
}
function Sd(e, t, n, r) {
  this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
}
function Ce(e, t, n, r) {
  return new Sd(e, t, n, r);
}
function Lu(e) {
  return e = e.prototype, !(!e || !e.isReactComponent);
}
function Ed(e) {
  if (typeof e == "function") return Lu(e) ? 1 : 0;
  if (e != null) {
    if (e = e.$$typeof, e === Go) return 11;
    if (e === Zo) return 14;
  }
  return 2;
}
function ct(e, t) {
  var n = e.alternate;
  return n === null ? (n = Ce(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n;
}
function Lr(e, t, n, r, l, o) {
  var u = 2;
  if (r = e, typeof e == "function") Lu(e) && (u = 1);
  else if (typeof e == "string") u = 5;
  else e: switch (e) {
    case jt:
      return xt(n.children, l, o, t);
    case Yo:
      u = 8, l |= 8;
      break;
    case Yl:
      return e = Ce(12, n, t, l | 2), e.elementType = Yl, e.lanes = o, e;
    case Gl:
      return e = Ce(13, n, t, l), e.elementType = Gl, e.lanes = o, e;
    case Zl:
      return e = Ce(19, n, t, l), e.elementType = Zl, e.lanes = o, e;
    case ss:
      return fl(n, l, o, t);
    default:
      if (typeof e == "object" && e !== null) switch (e.$$typeof) {
        case us:
          u = 10;
          break e;
        case is:
          u = 9;
          break e;
        case Go:
          u = 11;
          break e;
        case Zo:
          u = 14;
          break e;
        case Je:
          u = 16, r = null;
          break e;
      }
      throw Error(y(130, e == null ? e : typeof e, ""));
  }
  return t = Ce(u, n, t, l), t.elementType = e, t.type = r, t.lanes = o, t;
}
function xt(e, t, n, r) {
  return e = Ce(7, e, r, t), e.lanes = n, e;
}
function fl(e, t, n, r) {
  return e = Ce(22, e, r, t), e.elementType = ss, e.lanes = n, e.stateNode = { isHidden: !1 }, e;
}
function Hl(e, t, n) {
  return e = Ce(6, e, null, t), e.lanes = n, e;
}
function Ql(e, t, n) {
  return t = Ce(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = { containerInfo: e.containerInfo, pendingChildren: null, implementation: e.implementation }, t;
}
function _d(e, t, n, r, l) {
  this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = xl(0), this.expirationTimes = xl(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = xl(0), this.identifierPrefix = r, this.onRecoverableError = l, this.mutableSourceEagerHydrationData = null;
}
function Ru(e, t, n, r, l, o, u, i, s) {
  return e = new _d(e, t, n, i, s), t === 1 ? (t = 1, o === !0 && (t |= 8)) : t = 0, o = Ce(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = { element: r, isDehydrated: n, cache: null, transitions: null, pendingSuspenseBoundaries: null }, mu(o), e;
}
function Cd(e, t, n) {
  var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return { $$typeof: It, key: r == null ? null : "" + r, children: e, containerInfo: t, implementation: n };
}
function ba(e) {
  if (!e) return dt;
  e = e._reactInternals;
  e: {
    if (Mt(e) !== e || e.tag !== 1) throw Error(y(170));
    var t = e;
    do {
      switch (t.tag) {
        case 3:
          t = t.stateNode.context;
          break e;
        case 1:
          if (me(t.type)) {
            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
            break e;
          }
      }
      t = t.return;
    } while (t !== null);
    throw Error(y(171));
  }
  if (e.tag === 1) {
    var n = e.type;
    if (me(n)) return bs(e, n, t);
  }
  return t;
}
function ec(e, t, n, r, l, o, u, i, s) {
  return e = Ru(n, r, !0, e, l, o, u, i, s), e.context = ba(null), n = e.current, r = se(), l = at(n), o = He(r, l), o.callback = t ?? null, it(n, o, l), e.current.lanes = l, Zn(e, l, r), he(e, r), e;
}
function dl(e, t, n, r) {
  var l = t.current, o = se(), u = at(l);
  return n = ba(n), t.context === null ? t.context = n : t.pendingContext = n, t = He(o, u), t.payload = { element: e }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = it(l, t, u), e !== null && (Oe(e, l, u, o), Cr(e, l, u)), u;
}
function el(e) {
  if (e = e.current, !e.child) return null;
  switch (e.child.tag) {
    case 5:
      return e.child.stateNode;
    default:
      return e.child.stateNode;
  }
}
function Vi(e, t) {
  if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
    var n = e.retryLane;
    e.retryLane = n !== 0 && n < t ? n : t;
  }
}
function Mu(e, t) {
  Vi(e, t), (e = e.alternate) && Vi(e, t);
}
function xd() {
  return null;
}
var tc = typeof reportError == "function" ? reportError : function(e) {
  console.error(e);
};
function Ou(e) {
  this._internalRoot = e;
}
pl.prototype.render = Ou.prototype.render = function(e) {
  var t = this._internalRoot;
  if (t === null) throw Error(y(409));
  dl(e, t, null, null);
};
pl.prototype.unmount = Ou.prototype.unmount = function() {
  var e = this._internalRoot;
  if (e !== null) {
    this._internalRoot = null;
    var t = e.containerInfo;
    Lt(function() {
      dl(null, e, null, null);
    }), t[Ke] = null;
  }
};
function pl(e) {
  this._internalRoot = e;
}
pl.prototype.unstable_scheduleHydration = function(e) {
  if (e) {
    var t = Ms();
    e = { blockedOn: null, target: e, priority: t };
    for (var n = 0; n < be.length && t !== 0 && t < be[n].priority; n++) ;
    be.splice(n, 0, e), n === 0 && Is(e);
  }
};
function Iu(e) {
  return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
}
function ml(e) {
  return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "));
}
function Wi() {
}
function Pd(e, t, n, r, l) {
  if (l) {
    if (typeof r == "function") {
      var o = r;
      r = function() {
        var a = el(u);
        o.call(a);
      };
    }
    var u = ec(t, r, e, 0, null, !1, !1, "", Wi);
    return e._reactRootContainer = u, e[Ke] = u.current, $n(e.nodeType === 8 ? e.parentNode : e), Lt(), u;
  }
  for (; l = e.lastChild; ) e.removeChild(l);
  if (typeof r == "function") {
    var i = r;
    r = function() {
      var a = el(s);
      i.call(a);
    };
  }
  var s = Ru(e, 0, !1, null, null, !1, !1, "", Wi);
  return e._reactRootContainer = s, e[Ke] = s.current, $n(e.nodeType === 8 ? e.parentNode : e), Lt(function() {
    dl(t, s, n, r);
  }), s;
}
function hl(e, t, n, r, l) {
  var o = n._reactRootContainer;
  if (o) {
    var u = o;
    if (typeof l == "function") {
      var i = l;
      l = function() {
        var s = el(u);
        i.call(s);
      };
    }
    dl(t, u, e, l);
  } else u = Pd(n, t, e, l, r);
  return el(u);
}
Ls = function(e) {
  switch (e.tag) {
    case 3:
      var t = e.stateNode;
      if (t.current.memoizedState.isDehydrated) {
        var n = Sn(t.pendingLanes);
        n !== 0 && (bo(t, n | 1), he(t, K()), !(M & 6) && (ln = K() + 500, ht()));
      }
      break;
    case 13:
      Lt(function() {
        var r = Xe(e, 1);
        if (r !== null) {
          var l = se();
          Oe(r, e, 1, l);
        }
      }), Mu(e, 1);
  }
};
eu = function(e) {
  if (e.tag === 13) {
    var t = Xe(e, 134217728);
    if (t !== null) {
      var n = se();
      Oe(t, e, 134217728, n);
    }
    Mu(e, 134217728);
  }
};
Rs = function(e) {
  if (e.tag === 13) {
    var t = at(e), n = Xe(e, t);
    if (n !== null) {
      var r = se();
      Oe(n, e, t, r);
    }
    Mu(e, t);
  }
};
Ms = function() {
  return j;
};
Os = function(e, t) {
  var n = j;
  try {
    return j = e, t();
  } finally {
    j = n;
  }
};
uo = function(e, t, n) {
  switch (t) {
    case "input":
      if (bl(e, n), t = n.name, n.type === "radio" && t != null) {
        for (n = e; n.parentNode; ) n = n.parentNode;
        for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
          var r = n[t];
          if (r !== e && r.form === e.form) {
            var l = ol(r);
            if (!l) throw Error(y(90));
            cs(r), bl(r, l);
          }
        }
      }
      break;
    case "textarea":
      ds(e, n);
      break;
    case "select":
      t = n.value, t != null && Kt(e, !!n.multiple, t, !1);
  }
};
ws = Nu;
ks = Lt;
var Nd = { usingClientEntryPoint: !1, Events: [qn, Bt, ol, gs, ys, Nu] }, gn = { findFiberByHostInstance: St, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, Td = { bundleType: gn.bundleType, version: gn.version, rendererPackageName: gn.rendererPackageName, rendererConfig: gn.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: Ge.ReactCurrentDispatcher, findHostInstanceByFiber: function(e) {
  return e = _s(e), e === null ? null : e.stateNode;
}, findFiberByHostInstance: gn.findFiberByHostInstance || xd, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var yr = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!yr.isDisabled && yr.supportsFiber) try {
    tl = yr.inject(Td), Ue = yr;
  } catch {
  }
}
ke.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Nd;
ke.createPortal = function(e, t) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!Iu(t)) throw Error(y(200));
  return Cd(e, t, null, n);
};
ke.createRoot = function(e, t) {
  if (!Iu(e)) throw Error(y(299));
  var n = !1, r = "", l = tc;
  return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (l = t.onRecoverableError)), t = Ru(e, 1, !1, null, null, n, !1, r, l), e[Ke] = t.current, $n(e.nodeType === 8 ? e.parentNode : e), new Ou(t);
};
ke.findDOMNode = function(e) {
  if (e == null) return null;
  if (e.nodeType === 1) return e;
  var t = e._reactInternals;
  if (t === void 0)
    throw typeof e.render == "function" ? Error(y(188)) : (e = Object.keys(e).join(","), Error(y(268, e)));
  return e = _s(t), e = e === null ? null : e.stateNode, e;
};
ke.flushSync = function(e) {
  return Lt(e);
};
ke.hydrate = function(e, t, n) {
  if (!ml(t)) throw Error(y(200));
  return hl(null, e, t, !0, n);
};
ke.hydrateRoot = function(e, t, n) {
  if (!Iu(e)) throw Error(y(405));
  var r = n != null && n.hydratedSources || null, l = !1, o = "", u = tc;
  if (n != null && (n.unstable_strictMode === !0 && (l = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onRecoverableError !== void 0 && (u = n.onRecoverableError)), t = ec(t, null, e, 1, n ?? null, l, !1, o, u), e[Ke] = t.current, $n(e), r) for (e = 0; e < r.length; e++) n = r[e], l = n._getVersion, l = l(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, l] : t.mutableSourceEagerHydrationData.push(
    n,
    l
  );
  return new pl(t);
};
ke.render = function(e, t, n) {
  if (!ml(t)) throw Error(y(200));
  return hl(null, e, t, !1, n);
};
ke.unmountComponentAtNode = function(e) {
  if (!ml(e)) throw Error(y(40));
  return e._reactRootContainer ? (Lt(function() {
    hl(null, null, e, !1, function() {
      e._reactRootContainer = null, e[Ke] = null;
    });
  }), !0) : !1;
};
ke.unstable_batchedUpdates = Nu;
ke.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
  if (!ml(n)) throw Error(y(200));
  if (e == null || e._reactInternals === void 0) throw Error(y(38));
  return hl(e, t, n, !1, r);
};
ke.version = "18.3.1-next-f1338f8080-20240426";
function nc() {
  if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(nc);
    } catch (e) {
      console.error(e);
    }
}
nc(), ns.exports = ke;
var zd = ns.exports;
const Ld = /* @__PURE__ */ Ki(zd);
let $o = null, yn = null;
function Rd(e) {
  $o = e;
}
function Md(e, t = 5e3, n = 50) {
  return new Promise((r, l) => {
    const o = Date.now(), u = () => {
      if (e()) return r();
      if (Date.now() - o >= t)
        return l(new Error("[BladeBerg] Timed out waiting for the editor runtime."));
      setTimeout(u, n);
    };
    u();
  });
}
function Od() {
  var e;
  return (e = window.wp) != null && e.attachEditor ? Promise.resolve() : yn || (yn = ($o ? $o() : Promise.resolve()).then(() => Md(() => {
    var t;
    return !!((t = window.wp) != null && t.attachEditor);
  })).catch((t) => {
    throw yn = null, t;
  }), yn);
}
function Id(e, t) {
  window.React = e, window.ReactDOM = t, globalThis.React = e, globalThis.ReactDOM = t;
}
function jd(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Dd({ blockPrefix: e, media: t } = {}) {
  var l;
  const n = window.BladebergConfig ?? {}, r = {
    blockPrefix: e ?? n.blockPrefix ?? "bb",
    mediaMode: (t == null ? void 0 : t.mode) ?? n.mediaMode ?? "disabled",
    mediaApiUrl: (t == null ? void 0 : t.apiUrl) ?? n.mediaApiUrl ?? "",
    csrfToken: (t == null ? void 0 : t.csrfToken) ?? n.csrfToken ?? ((l = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : l.getAttribute("content")) ?? ""
  };
  return window.BladebergConfig = { ...n, ...r }, r;
}
function Hi(e, t) {
  return ((e == null ? void 0 : e.value) ?? "").replace(/<!--\s*(\/?)wp:/g, `<!-- $1${t}:`);
}
function Fd(e, t) {
  if (!e) return e;
  const n = new RegExp(`<!--\\s*(\\/?)\\s*${jd(t)}:`, "g");
  return e.replace(n, "<!-- $1wp:");
}
function rc(e) {
  var t;
  return e ?? ((t = window.BladebergConfig) == null ? void 0 : t.blockPrefix) ?? "bb";
}
function Ud(e) {
  const t = rc(e);
  if (window.__bbBrandingInstalled) {
    Kl(document.body, t);
    return;
  }
  window.__bbBrandingInstalled = !0, Kl(document.body, t);
  const n = new MutationObserver((r) => {
    for (const { addedNodes: l } of r)
      for (const o of l)
        o.nodeType === Node.ELEMENT_NODE && Kl(o, t);
  });
  n.observe(document.body, { childList: !0, subtree: !0 }), window.Bladeberg = window.Bladeberg ?? {}, window.Bladeberg._brandingObserver = n, $d(t);
}
function Bd(e) {
  return [
    { from: /WordPress/g, to: "BladeBerg" },
    { from: /\bWP\b(?![-_])/g, to: "BB" },
    { from: /\bwp:([\w-]+)/g, to: `${e}:$1` },
    { from: /\bcore\/([\w-]+)/g, to: `${e}/$1` }
  ];
}
function Kl(e, t) {
  if (!e) return;
  const n = Bd(t);
  if (e.nodeType === Node.TEXT_NODE) {
    Qi(e, n);
    return;
  }
  const r = document.createTreeWalker(e, NodeFilter.SHOW_TEXT, {
    acceptNode(u) {
      var a;
      const i = ((a = u.parentElement) == null ? void 0 : a.tagName) ?? "";
      return ["SCRIPT", "STYLE", "INPUT", "TEXTAREA"].includes(i) ? NodeFilter.FILTER_REJECT : n.some((m) => (m.from.lastIndex = 0, m.from.test(u.textContent))) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  }), l = [];
  let o;
  for (; o = r.nextNode(); ) l.push(o);
  l.forEach((u) => Qi(u, n));
}
function Qi(e, t) {
  let n = e.textContent;
  for (const { from: r, to: l } of t)
    r.lastIndex = 0, n = n.replace(r, l);
  n !== e.textContent && (e.textContent = n);
}
function $d(e) {
  const t = rc(e), n = "data-bb-code-overlay";
  function r(i) {
    return i.replace(/wp:([\w-]+)/g, `${t}:$1`).replace(/WordPress/g, "BladeBerg").replace(/core\/([\w-]+)/g, `${t}/$1`);
  }
  function l(i) {
    var m;
    if (i.hasAttribute(n)) return;
    i.setAttribute(n, "1");
    const s = i.parentElement;
    s && getComputedStyle(s).position === "static" && (s.style.position = "relative");
    const a = document.createElement("pre");
    a.className = "bb-code-editor-overlay", a.textContent = r(i.value), a.setAttribute("aria-hidden", "true"), (m = i.parentNode) == null || m.insertBefore(a, i.nextSibling), i.addEventListener("input", () => {
      a.textContent = r(i.value);
    });
  }
  const o = ".editor-post-text-editor, .block-editor-plain-text";
  if (document.querySelectorAll(o).forEach(l), window.__bbOverlayInstalled) return;
  window.__bbOverlayInstalled = !0;
  const u = new MutationObserver((i) => {
    var s, a;
    for (const { addedNodes: m } of i)
      for (const p of m)
        p.nodeType === Node.ELEMENT_NODE && ((s = p.querySelectorAll) == null || s.call(p, o).forEach(l), (a = p.matches) != null && a.call(p, o) && l(p));
  });
  u.observe(document.body, { childList: !0, subtree: !0 }), window.Bladeberg = window.Bladeberg ?? {}, window.Bladeberg._overlayObserver = u;
}
function Ad() {
  if (window.__bbContextMenuInstalled) return;
  window.__bbContextMenuInstalled = !0;
  const e = ".block-editor-block-list__layout, .editor-styles-wrapper, .iso-editor";
  function t(n = 0) {
    const r = document.querySelector(".block-editor-block-settings-menu__toggle") || document.querySelector(".block-editor-block-settings-menu button") || document.querySelector('button[aria-label="Options"]') || document.querySelector('.block-editor-block-settings-menu [role="button"]');
    if (r) {
      r.click();
      return;
    }
    n < 10 && setTimeout(() => t(n + 1), 30);
  }
  document.addEventListener(
    "contextmenu",
    (n) => {
      var u;
      const r = n.target, l = (u = r == null ? void 0 : r.closest) == null ? void 0 : u.call(r, "[data-block]");
      if (!l || !l.closest(e))
        return;
      n.preventDefault();
      const o = { bubbles: !0, cancelable: !0, view: window, button: 0 };
      if (r.dispatchEvent(new MouseEvent("mousedown", o)), r.dispatchEvent(new MouseEvent("mouseup", o)), typeof l.focus == "function")
        try {
          l.focus({ preventScroll: !0 });
        } catch {
        }
      setTimeout(() => t(), 30);
    },
    { capture: !0 }
  );
}
function Vd(e) {
  var t, n;
  return {
    ...e,
    alt: e.alt_text ?? "",
    caption: ((t = e.caption) == null ? void 0 : t.raw) ?? "",
    title: ((n = e.title) == null ? void 0 : n.raw) ?? e.title ?? "",
    url: e.source_url ?? e.url ?? ""
  };
}
async function Wd(e, t = {}, n) {
  var m, p, h;
  const r = window.BladebergConfig ?? {}, l = r.mediaApiUrl, o = r.csrfToken ?? ((m = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : m.getAttribute("content"));
  if (!l)
    throw new Error("[BladeBerg] mediaApiUrl is not configured. Set media.enabled = true in config/bladeberg.php.");
  const u = new FormData();
  u.append("file", e, e.name || "upload");
  const i = ["alt_text", "title", "caption"];
  for (const v of i)
    t[v] !== void 0 && t[v] !== null && u.append(v, t[v]);
  const s = {};
  o && (s["X-CSRF-TOKEN"] = o);
  const a = await fetch(l, {
    method: "POST",
    headers: s,
    body: u,
    credentials: "same-origin",
    signal: n
  });
  if (!a.ok) {
    const v = await a.json().catch(() => ({})), w = (v == null ? void 0 : v.message) ?? ((h = (p = v == null ? void 0 : v.errors) == null ? void 0 : p.file) == null ? void 0 : h[0]) ?? `HTTP ${a.status}`;
    throw new Error(`[BladeBerg] Upload failed: ${w}`);
  }
  return Vd(await a.json());
}
async function lc({
  filesList: e,
  onFileChange: t,
  onSuccess: n,
  onError: r,
  additionalData: l = {},
  signal: o
}) {
  const u = Array.from(e), i = [];
  for (const s of u) {
    const a = URL.createObjectURL(s), m = { url: a, media_type: s.type };
    t([m]);
    try {
      const p = await Wd(s, l, o);
      URL.revokeObjectURL(a), t([p]), i.push(p);
    } catch (p) {
      URL.revokeObjectURL(a), typeof r == "function" ? r({ code: "upload_error", message: p.message, file: s }) : console.error("[BladeBerg] Media upload error:", p);
    }
  }
  i.length > 0 && typeof n == "function" && n(i);
}
const Hd = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  bladebergMediaUpload: lc
}, Symbol.toStringTag, { value: "Module" }));
function Qd(e) {
  const t = window.BladebergConfig ?? {}, n = t.mediaApiUrl ? new URL(t.mediaApiUrl).pathname : "/bladeberg/media", r = e.replace(/^\/wp\/v2\/media/, ""), l = r.indexOf("?"), o = l >= 0 ? r.slice(0, l) : r, u = l >= 0 ? r.slice(l + 1) : "", i = new URLSearchParams(u), s = new URLSearchParams(), a = ["page", "per_page", "search", "media_type", "orderby", "order"];
  for (const h of a)
    i.has(h) && s.set(h, i.get(h));
  const m = s.toString();
  return n + o + (m ? "?" + m : "");
}
function Kd() {
  var t;
  const e = (t = window.wp) == null ? void 0 : t.apiFetch;
  if (!e) {
    console.warn("[BladeBerg] window.wp.apiFetch not found — media API middleware not registered.");
    return;
  }
  e.use((n, r) => {
    const l = n.path ?? "";
    return typeof l == "string" && l.startsWith("/wp/v2/media") ? r({ ...n, path: Qd(l) }) : r(n);
  });
}
var oc = { exports: {} }, vl = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Xd = W, Yd = Symbol.for("react.element"), Gd = Symbol.for("react.fragment"), Zd = Object.prototype.hasOwnProperty, Jd = Xd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, qd = { key: !0, ref: !0, __self: !0, __source: !0 };
function uc(e, t, n) {
  var r, l = {}, o = null, u = null;
  n !== void 0 && (o = "" + n), t.key !== void 0 && (o = "" + t.key), t.ref !== void 0 && (u = t.ref);
  for (r in t) Zd.call(t, r) && !qd.hasOwnProperty(r) && (l[r] = t[r]);
  if (e && e.defaultProps) for (r in t = e.defaultProps, t) l[r] === void 0 && (l[r] = t[r]);
  return { $$typeof: Yd, type: e, key: o, ref: u, props: l, _owner: Jd.current };
}
vl.Fragment = Gd;
vl.jsx = uc;
vl.jsxs = uc;
oc.exports = vl;
var I = oc.exports;
const bd = [
  { label: "All", value: "" },
  { label: "Images", value: "image" },
  { label: "Video", value: "video" },
  { label: "Audio", value: "audio" },
  { label: "Documents", value: "application" }
];
async function ep({ page: e = 1, perPage: t = 20, search: n = "", mediaType: r = "" } = {}) {
  var h;
  const l = window.BladebergConfig ?? {}, o = l.csrfToken ?? ((h = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : h.content), u = l.mediaApiUrl ?? "/bladeberg/media", i = new URLSearchParams({ page: e, per_page: t });
  n && i.set("search", n), r && i.set("media_type", r);
  const s = await fetch(`${u}?${i}`, {
    headers: {
      Accept: "application/json",
      ...o ? { "X-CSRF-TOKEN": o } : {}
    },
    credentials: "same-origin"
  });
  if (!s.ok) throw new Error(`[BladeBerg] Media fetch failed: ${s.status}`);
  const a = await s.json(), m = parseInt(s.headers.get("X-WP-Total") ?? "0", 10), p = parseInt(s.headers.get("X-WP-TotalPages") ?? "1", 10);
  return { items: a, total: m, totalPages: p };
}
function tp({ item: e, isSelected: t, onSelect: n }) {
  var o, u, i, s, a, m;
  const r = (o = e.mime_type) == null ? void 0 : o.startsWith("image/"), l = e.source_url ?? e.url ?? "";
  return /* @__PURE__ */ I.jsxs(
    "button",
    {
      type: "button",
      className: `bb-media-grid__item${t ? " bb-media-grid__item--selected" : ""}`,
      onClick: () => n(e),
      title: ((u = e.title) == null ? void 0 : u.rendered) ?? e.title ?? l,
      "aria-pressed": t,
      children: [
        r ? /* @__PURE__ */ I.jsx(
          "img",
          {
            src: ((a = (s = (i = e.media_details) == null ? void 0 : i.sizes) == null ? void 0 : s.thumbnail) == null ? void 0 : a.source_url) ?? l,
            alt: e.alt_text ?? "",
            loading: "lazy",
            className: "bb-media-grid__thumb"
          }
        ) : /* @__PURE__ */ I.jsx("div", { className: "bb-media-grid__icon", "aria-hidden": "true", children: np(e.mime_type) }),
        /* @__PURE__ */ I.jsx("span", { className: "bb-media-grid__name", children: ((m = e.title) == null ? void 0 : m.rendered) ?? e.title ?? "" })
      ]
    }
  );
}
function np(e = "") {
  return e.startsWith("video/") ? "🎬" : e.startsWith("audio/") ? "🎵" : e.includes("pdf") ? "📄" : "📁";
}
function rp({ onUploaded: e }) {
  const t = W.useRef(null), [n, r] = W.useState(!1), [l, o] = W.useState(!1), u = W.useCallback(async (i) => {
    if (i.length) {
      o(!0);
      try {
        const { bladebergMediaUpload: s } = await Promise.resolve().then(() => Hd);
        await s({
          filesList: i,
          onFileChange: (a) => {
            var m;
            (m = a[0]) != null && m.id && e(a[0]);
          },
          onError: (a) => console.error("[BladeBerg] Upload error:", a)
        });
      } finally {
        o(!1);
      }
    }
  }, [e]);
  return /* @__PURE__ */ I.jsxs(
    "div",
    {
      className: `bb-media-upload-zone${n ? " bb-media-upload-zone--drag" : ""}`,
      onDragOver: (i) => {
        i.preventDefault(), r(!0);
      },
      onDragLeave: () => r(!1),
      onDrop: (i) => {
        i.preventDefault(), r(!1), u(Array.from(i.dataTransfer.files));
      },
      onClick: () => {
        var i;
        return (i = t.current) == null ? void 0 : i.click();
      },
      role: "button",
      tabIndex: 0,
      onKeyDown: (i) => {
        var s;
        return i.key === "Enter" && ((s = t.current) == null ? void 0 : s.click());
      },
      children: [
        /* @__PURE__ */ I.jsx(
          "input",
          {
            ref: t,
            type: "file",
            multiple: !0,
            accept: "image/*,video/*,audio/*,application/pdf",
            style: { display: "none" },
            onChange: (i) => u(Array.from(i.target.files))
          }
        ),
        l ? /* @__PURE__ */ I.jsx("span", { children: "Uploading…" }) : /* @__PURE__ */ I.jsx("span", { children: "Drop files here or click to upload" })
      ]
    }
  );
}
function lp({ onSelect: e, allowedTypes: t = [], allowUpload: n = !0 }) {
  const [r, l] = W.useState([]), [o, u] = W.useState(1), [i, s] = W.useState(1), [a, m] = W.useState(""), [p, h] = W.useState(
    t.length === 1 ? t[0] : ""
  ), [v, w] = W.useState(!1), [k, O] = W.useState(null), [f, c] = W.useState(null), d = W.useRef(null), g = W.useCallback(async (N = 1, z = !1) => {
    w(!0), O(null);
    try {
      const b = await ep({ page: N, search: a, mediaType: p });
      l((vt) => z ? b.items : [...vt, ...b.items]), s(b.totalPages), u(N);
    } catch (b) {
      O(b.message);
    } finally {
      w(!1);
    }
  }, [a, p]);
  W.useEffect(() => {
    g(1, !0);
  }, [g]);
  const S = (N) => {
    clearTimeout(d.current), d.current = setTimeout(() => m(N), 350);
  }, C = (N) => {
    c(N.id), e(N);
  }, x = (N) => {
    l((z) => [N, ...z]);
  }, P = t.length !== 1;
  return /* @__PURE__ */ I.jsxs("div", { className: "bb-media-grid-wrap", children: [
    /* @__PURE__ */ I.jsxs("div", { className: "bb-media-grid-toolbar", children: [
      /* @__PURE__ */ I.jsx(
        "input",
        {
          type: "search",
          className: "bb-media-grid-search",
          placeholder: "Search media…",
          onChange: (N) => S(N.target.value)
        }
      ),
      P && /* @__PURE__ */ I.jsx("div", { className: "bb-media-grid-filters", role: "tablist", children: bd.map((N) => /* @__PURE__ */ I.jsx(
        "button",
        {
          type: "button",
          role: "tab",
          "aria-selected": p === N.value,
          className: `bb-media-grid-filter${p === N.value ? " bb-media-grid-filter--active" : ""}`,
          onClick: () => h(N.value),
          children: N.label
        },
        N.value
      )) })
    ] }),
    n && /* @__PURE__ */ I.jsx(rp, { onUploaded: x }),
    k && /* @__PURE__ */ I.jsx("p", { className: "bb-media-grid-error", children: k }),
    /* @__PURE__ */ I.jsx("div", { className: "bb-media-grid", role: "listbox", "aria-label": "Media library", children: r.map((N) => /* @__PURE__ */ I.jsx(
      tp,
      {
        item: N,
        isSelected: f === N.id,
        onSelect: C
      },
      N.id
    )) }),
    !v && r.length === 0 && /* @__PURE__ */ I.jsx("p", { className: "bb-media-grid-empty", children: n ? "No media found. Drop files above to upload." : "No media found in the configured storage directory." }),
    v && /* @__PURE__ */ I.jsx("p", { className: "bb-media-grid-loading", children: "Loading…" }),
    !v && o < i && /* @__PURE__ */ I.jsx(
      "button",
      {
        type: "button",
        className: "bb-media-grid-load-more",
        onClick: () => g(o + 1),
        children: "Load more"
      }
    )
  ] });
}
function op({ isOpen: e, onClose: t, title: n, children: r }) {
  return e ? /* @__PURE__ */ I.jsx(
    "div",
    {
      className: "bb-media-modal-overlay",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": n,
      onClick: (l) => {
        l.target === l.currentTarget && t();
      },
      children: /* @__PURE__ */ I.jsxs("div", { className: "bb-media-modal", children: [
        /* @__PURE__ */ I.jsxs("div", { className: "bb-media-modal__header", children: [
          /* @__PURE__ */ I.jsx("h2", { className: "bb-media-modal__title", children: n }),
          /* @__PURE__ */ I.jsx(
            "button",
            {
              type: "button",
              className: "bb-media-modal__close",
              onClick: t,
              "aria-label": "Close media library",
              children: "✕"
            }
          )
        ] }),
        /* @__PURE__ */ I.jsx("div", { className: "bb-media-modal__body", children: r })
      ] })
    }
  ) : null;
}
function up({ onSelect: e, allowedTypes: t = [], multiple: n = !1, render: r }) {
  var v;
  const [l, o] = W.useState(!1), i = (((v = window.BladebergConfig) == null ? void 0 : v.mediaMode) ?? "upload") === "upload", s = i ? "BladeBerg Media Library" : "BladeBerg Media — Browse", a = W.useCallback(() => o(!0), []), m = W.useCallback(() => o(!1), []), p = W.useCallback((w) => {
    e(w), m();
  }, [e, m]), h = [...new Set(
    (t ?? []).map((w) => w.split("/")[0]).filter(Boolean)
  )];
  return /* @__PURE__ */ I.jsxs(I.Fragment, { children: [
    typeof r == "function" && r({ open: a }),
    /* @__PURE__ */ I.jsx(
      op,
      {
        isOpen: l,
        onClose: m,
        title: s,
        children: /* @__PURE__ */ I.jsx(
          lp,
          {
            onSelect: p,
            allowedTypes: h,
            allowUpload: i
          }
        )
      }
    )
  ] });
}
function cp(e, t) {
  var n, r;
  window.Bladeberg = window.Bladeberg ?? { _queue: [] }, window.Bladeberg._queue = window.Bladeberg._queue ?? [], (r = (n = window.wp) == null ? void 0 : n.blocks) != null && r.registerBlockType ? window.wp.blocks.registerBlockType(e, t) : window.Bladeberg._queue.push({ name: e, settings: t });
}
function ip() {
  var t, n, r;
  if (!((n = (t = window.wp) == null ? void 0 : t.blocks) != null && n.registerBlockType)) return;
  (((r = window.Bladeberg) == null ? void 0 : r._queue) ?? []).forEach(({ name: l, settings: o }) => window.wp.blocks.registerBlockType(l, o)), window.Bladeberg && (window.Bladeberg._queue = []);
}
function sp(e) {
  const t = typeof e == "string" ? document.querySelector(e) : e;
  if (!t)
    throw new Error("[BladeBerg] createEditor: target element not found.");
  if (t.classList.add("bladeberg-container"), t.tagName === "TEXTAREA")
    return t;
  const n = document.createElement("textarea");
  return t.appendChild(n), n;
}
function ap(e, t) {
  var n, r, l, o, u;
  if (e !== "select" && e !== "upload")
    return t;
  if (Kd(), (r = (n = window.wp) == null ? void 0 : n.hooks) != null && r.addFilter && window.wp.hooks.addFilter(
    "editor.MediaUpload",
    "bladeberg/media-upload",
    () => up
  ), e === "upload" && (t.editor = {
    ...t.editor ?? {},
    mediaUpload: lc
  }, (l = window.wp) != null && l.data))
    try {
      (u = (o = window.wp.data.dispatch("core")) == null ? void 0 : o.receiveUserPermission) == null || u.call(o, "create/media", !0);
    } catch {
    }
  return t;
}
async function fp(e = {}) {
  const {
    target: t,
    value: n,
    settings: r = {},
    blockPrefix: l,
    media: o,
    branding: u = !0,
    contextMenu: i = !0,
    onChange: s
  } = e;
  await Od(), ip();
  const a = Dd({ blockPrefix: l, media: o }), m = a.blockPrefix, p = sp(t);
  p.dataset.bladebergMounted = "1", n != null && (p.value = n), p.value && (p.value = Fd(p.value, m));
  const h = ap(a.mediaMode, { ...r });
  window.wp.attachEditor(p, h), u && Ud(m), i && Ad();
  const v = /* @__PURE__ */ new Set();
  typeof s == "function" && v.add(s);
  let w = p.value, k = null;
  function O() {
    k || v.size === 0 || (k = window.setInterval(() => {
      if (p.value === w) return;
      w = p.value;
      const f = Hi(p, m);
      v.forEach((c) => {
        try {
          c(f);
        } catch (d) {
          console.error("[BladeBerg] onChange handler error:", d);
        }
      });
    }, 300));
  }
  return O(), {
    textarea: p,
    getContent: () => Hi(p, m),
    onChange(f) {
      return v.add(f), O(), () => v.delete(f);
    },
    destroy() {
      var f, c;
      k && (window.clearInterval(k), k = null), v.clear();
      try {
        (c = (f = window.wp) == null ? void 0 : f.detachEditor) == null || c.call(f, p);
      } catch {
      }
      delete p.dataset.bladebergMounted;
    }
  };
}
Rd(() => {
  var n;
  if (Id(_c, Ld), (n = window.wp) != null && n.attachEditor)
    return Promise.resolve();
  const e = new URL("./isolated-block-editor.js", import.meta.url).href, t = document.querySelector(`script[data-bladeberg-runtime][src="${e}"]`);
  return t ? new Promise((r, l) => {
    var o;
    if ((o = window.wp) != null && o.attachEditor) return r();
    t.addEventListener("load", () => r()), t.addEventListener("error", () => l(new Error("[BladeBerg] Failed to load editor runtime.")));
  }) : new Promise((r, l) => {
    const o = document.createElement("script");
    o.src = e, o.defer = !0, o.dataset.bladebergRuntime = "1", o.onload = () => r(), o.onerror = () => l(new Error("[BladeBerg] Failed to load editor runtime.")), document.head.appendChild(o);
  });
});
export {
  Ud as applyBranding,
  fp as createEditor,
  Ad as installBlockContextMenu,
  $d as installCodeEditorOverlay,
  cp as registerBlock
};
