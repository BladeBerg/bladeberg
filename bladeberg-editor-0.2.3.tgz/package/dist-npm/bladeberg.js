import D, { useState as h, useRef as L, useCallback as N, useEffect as j } from "react";
import W from "react-dom";
import { jsxs as v, jsx as b, Fragment as X } from "react/jsx-runtime";
let R = null, T = null;
function z(e) {
  R = e;
}
function K(e, t = 5e3, r = 50) {
  return new Promise((o, n) => {
    const a = Date.now(), c = () => {
      if (e()) return o();
      if (Date.now() - a >= t)
        return n(new Error("[BladeBerg] Timed out waiting for the editor runtime."));
      setTimeout(c, r);
    };
    c();
  });
}
function V() {
  var e;
  return (e = window.wp) != null && e.attachEditor ? Promise.resolve() : T || (T = (R ? R() : Promise.resolve()).then(() => K(() => {
    var t;
    return !!((t = window.wp) != null && t.attachEditor);
  })).catch((t) => {
    throw T = null, t;
  }), T);
}
function G(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function H({ blockPrefix: e, media: t } = {}) {
  var n;
  const r = window.BladebergConfig ?? {}, o = {
    blockPrefix: e ?? r.blockPrefix ?? "bb",
    mediaMode: (t == null ? void 0 : t.mode) ?? r.mediaMode ?? "disabled",
    mediaApiUrl: (t == null ? void 0 : t.apiUrl) ?? r.mediaApiUrl ?? "",
    csrfToken: (t == null ? void 0 : t.csrfToken) ?? r.csrfToken ?? ((n = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : n.getAttribute("content")) ?? ""
  };
  return window.BladebergConfig = { ...r, ...o }, o;
}
function S(e, t) {
  return ((e == null ? void 0 : e.value) ?? "").replace(/<!--\s*(\/?)wp:/g, `<!-- $1${t}:`);
}
function Q(e, t) {
  if (!e) return e;
  const r = new RegExp(`<!--\\s*(\\/?)\\s*${G(t)}:`, "g");
  return e.replace(r, "<!-- $1wp:");
}
function O(e) {
  var t;
  return e ?? ((t = window.BladebergConfig) == null ? void 0 : t.blockPrefix) ?? "bb";
}
function Y(e) {
  const t = O(e);
  if (window.__bbBrandingInstalled) {
    M(document.body, t);
    return;
  }
  window.__bbBrandingInstalled = !0, M(document.body, t);
  const r = new MutationObserver((o) => {
    for (const { addedNodes: n } of o)
      for (const a of n)
        a.nodeType === Node.ELEMENT_NODE && M(a, t);
  });
  r.observe(document.body, { childList: !0, subtree: !0 }), window.Bladeberg = window.Bladeberg ?? {}, window.Bladeberg._brandingObserver = r, Z(t);
}
function J(e) {
  return [
    { from: /WordPress/g, to: "BladeBerg" },
    { from: /\bWP\b(?![-_])/g, to: "BB" },
    { from: /\bwp:([\w-]+)/g, to: `${e}:$1` },
    { from: /\bcore\/([\w-]+)/g, to: `${e}/$1` }
  ];
}
function M(e, t) {
  if (!e) return;
  const r = J(t);
  if (e.nodeType === Node.TEXT_NODE) {
    x(e, r);
    return;
  }
  const o = document.createTreeWalker(e, NodeFilter.SHOW_TEXT, {
    acceptNode(c) {
      var d;
      const i = ((d = c.parentElement) == null ? void 0 : d.tagName) ?? "";
      return ["SCRIPT", "STYLE", "INPUT", "TEXTAREA"].includes(i) ? NodeFilter.FILTER_REJECT : r.some((u) => (u.from.lastIndex = 0, u.from.test(c.textContent))) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  }), n = [];
  let a;
  for (; a = o.nextNode(); ) n.push(a);
  n.forEach((c) => x(c, r));
}
function x(e, t) {
  let r = e.textContent;
  for (const { from: o, to: n } of t)
    o.lastIndex = 0, r = r.replace(o, n);
  r !== e.textContent && (e.textContent = r);
}
function Z(e) {
  const t = O(e), r = "data-bb-code-overlay";
  function o(i) {
    return i.replace(/wp:([\w-]+)/g, `${t}:$1`).replace(/WordPress/g, "BladeBerg").replace(/core\/([\w-]+)/g, `${t}/$1`);
  }
  function n(i) {
    var u;
    if (i.hasAttribute(r)) return;
    i.setAttribute(r, "1");
    const s = i.parentElement;
    s && getComputedStyle(s).position === "static" && (s.style.position = "relative");
    const d = document.createElement("pre");
    d.className = "bb-code-editor-overlay", d.textContent = o(i.value), d.setAttribute("aria-hidden", "true"), (u = i.parentNode) == null || u.insertBefore(d, i.nextSibling), i.addEventListener("input", () => {
      d.textContent = o(i.value);
    });
  }
  const a = ".editor-post-text-editor, .block-editor-plain-text";
  if (document.querySelectorAll(a).forEach(n), window.__bbOverlayInstalled) return;
  window.__bbOverlayInstalled = !0;
  const c = new MutationObserver((i) => {
    var s, d;
    for (const { addedNodes: u } of i)
      for (const l of u)
        l.nodeType === Node.ELEMENT_NODE && ((s = l.querySelectorAll) == null || s.call(l, a).forEach(n), (d = l.matches) != null && d.call(l, a) && n(l));
  });
  c.observe(document.body, { childList: !0, subtree: !0 }), window.Bladeberg = window.Bladeberg ?? {}, window.Bladeberg._overlayObserver = c;
}
function ee() {
  if (window.__bbContextMenuInstalled) return;
  window.__bbContextMenuInstalled = !0;
  const e = ".block-editor-block-list__layout, .editor-styles-wrapper, .iso-editor";
  function t(r = 0) {
    const o = document.querySelector(".block-editor-block-settings-menu__toggle") || document.querySelector(".block-editor-block-settings-menu button") || document.querySelector('button[aria-label="Options"]') || document.querySelector('.block-editor-block-settings-menu [role="button"]');
    if (o) {
      o.click();
      return;
    }
    r < 10 && setTimeout(() => t(r + 1), 30);
  }
  document.addEventListener(
    "contextmenu",
    (r) => {
      var c;
      const o = r.target, n = (c = o == null ? void 0 : o.closest) == null ? void 0 : c.call(o, "[data-block]");
      if (!n || !n.closest(e))
        return;
      r.preventDefault();
      const a = { bubbles: !0, cancelable: !0, view: window, button: 0 };
      if (o.dispatchEvent(new MouseEvent("mousedown", a)), o.dispatchEvent(new MouseEvent("mouseup", a)), typeof n.focus == "function")
        try {
          n.focus({ preventScroll: !0 });
        } catch {
        }
      setTimeout(() => t(), 30);
    },
    { capture: !0 }
  );
}
function te(e) {
  var t, r;
  return {
    ...e,
    alt: e.alt_text ?? "",
    caption: ((t = e.caption) == null ? void 0 : t.raw) ?? "",
    title: ((r = e.title) == null ? void 0 : r.raw) ?? e.title ?? "",
    url: e.source_url ?? e.url ?? ""
  };
}
async function re(e, t = {}, r) {
  var u, l, m;
  const o = window.BladebergConfig ?? {}, n = o.mediaApiUrl, a = o.csrfToken ?? ((u = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : u.getAttribute("content"));
  if (!n)
    throw new Error("[BladeBerg] mediaApiUrl is not configured. Set media.enabled = true in config/bladeberg.php.");
  const c = new FormData();
  c.append("file", e, e.name || "upload");
  const i = ["alt_text", "title", "caption"];
  for (const f of i)
    t[f] !== void 0 && t[f] !== null && c.append(f, t[f]);
  const s = {};
  a && (s["X-CSRF-TOKEN"] = a);
  const d = await fetch(n, {
    method: "POST",
    headers: s,
    body: c,
    credentials: "same-origin",
    signal: r
  });
  if (!d.ok) {
    const f = await d.json().catch(() => ({})), w = (f == null ? void 0 : f.message) ?? ((m = (l = f == null ? void 0 : f.errors) == null ? void 0 : l.file) == null ? void 0 : m[0]) ?? `HTTP ${d.status}`;
    throw new Error(`[BladeBerg] Upload failed: ${w}`);
  }
  return te(await d.json());
}
async function U({
  filesList: e,
  onFileChange: t,
  onSuccess: r,
  onError: o,
  additionalData: n = {},
  signal: a
}) {
  const c = Array.from(e), i = [];
  for (const s of c) {
    const d = URL.createObjectURL(s), u = { url: d, media_type: s.type };
    t([u]);
    try {
      const l = await re(s, n, a);
      URL.revokeObjectURL(d), t([l]), i.push(l);
    } catch (l) {
      URL.revokeObjectURL(d), typeof o == "function" ? o({ code: "upload_error", message: l.message, file: s }) : console.error("[BladeBerg] Media upload error:", l);
    }
  }
  i.length > 0 && typeof r == "function" && r(i);
}
const oe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  bladebergMediaUpload: U
}, Symbol.toStringTag, { value: "Module" }));
function ne(e) {
  const t = window.BladebergConfig ?? {}, r = t.mediaApiUrl ? new URL(t.mediaApiUrl).pathname : "/bladeberg/media", o = e.replace(/^\/wp\/v2\/media/, ""), n = o.indexOf("?"), a = n >= 0 ? o.slice(0, n) : o, c = n >= 0 ? o.slice(n + 1) : "", i = new URLSearchParams(c), s = new URLSearchParams(), d = ["page", "per_page", "search", "media_type", "orderby", "order"];
  for (const m of d)
    i.has(m) && s.set(m, i.get(m));
  const u = s.toString();
  return r + a + (u ? "?" + u : "");
}
function ae() {
  var t;
  const e = (t = window.wp) == null ? void 0 : t.apiFetch;
  if (!e) {
    console.warn("[BladeBerg] window.wp.apiFetch not found — media API middleware not registered.");
    return;
  }
  e.use((r, o) => {
    const n = r.path ?? "";
    return typeof n == "string" && n.startsWith("/wp/v2/media") ? o({ ...r, path: ne(n) }) : o(r);
  });
}
const ie = [
  { label: "All", value: "" },
  { label: "Images", value: "image" },
  { label: "Video", value: "video" },
  { label: "Audio", value: "audio" },
  { label: "Documents", value: "application" }
];
async function le({ page: e = 1, perPage: t = 20, search: r = "", mediaType: o = "" } = {}) {
  var m;
  const n = window.BladebergConfig ?? {}, a = n.csrfToken ?? ((m = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : m.content), c = n.mediaApiUrl ?? "/bladeberg/media", i = new URLSearchParams({ page: e, per_page: t });
  r && i.set("search", r), o && i.set("media_type", o);
  const s = await fetch(`${c}?${i}`, {
    headers: {
      Accept: "application/json",
      ...a ? { "X-CSRF-TOKEN": a } : {}
    },
    credentials: "same-origin"
  });
  if (!s.ok) throw new Error(`[BladeBerg] Media fetch failed: ${s.status}`);
  const d = await s.json(), u = parseInt(s.headers.get("X-WP-Total") ?? "0", 10), l = parseInt(s.headers.get("X-WP-TotalPages") ?? "1", 10);
  return { items: d, total: u, totalPages: l };
}
function de({ item: e, isSelected: t, onSelect: r }) {
  var a, c, i, s, d, u;
  const o = (a = e.mime_type) == null ? void 0 : a.startsWith("image/"), n = e.source_url ?? e.url ?? "";
  return /* @__PURE__ */ v(
    "button",
    {
      type: "button",
      className: `bb-media-grid__item${t ? " bb-media-grid__item--selected" : ""}`,
      onClick: () => r(e),
      title: ((c = e.title) == null ? void 0 : c.rendered) ?? e.title ?? n,
      "aria-pressed": t,
      children: [
        o ? /* @__PURE__ */ b(
          "img",
          {
            src: ((d = (s = (i = e.media_details) == null ? void 0 : i.sizes) == null ? void 0 : s.thumbnail) == null ? void 0 : d.source_url) ?? n,
            alt: e.alt_text ?? "",
            loading: "lazy",
            className: "bb-media-grid__thumb"
          }
        ) : /* @__PURE__ */ b("div", { className: "bb-media-grid__icon", "aria-hidden": "true", children: se(e.mime_type) }),
        /* @__PURE__ */ b("span", { className: "bb-media-grid__name", children: ((u = e.title) == null ? void 0 : u.rendered) ?? e.title ?? "" })
      ]
    }
  );
}
function se(e = "") {
  return e.startsWith("video/") ? "🎬" : e.startsWith("audio/") ? "🎵" : e.includes("pdf") ? "📄" : "📁";
}
function ce({ onUploaded: e }) {
  const t = L(null), [r, o] = h(!1), [n, a] = h(!1), c = N(async (i) => {
    if (i.length) {
      a(!0);
      try {
        const { bladebergMediaUpload: s } = await Promise.resolve().then(() => oe);
        await s({
          filesList: i,
          onFileChange: (d) => {
            var u;
            (u = d[0]) != null && u.id && e(d[0]);
          },
          onError: (d) => console.error("[BladeBerg] Upload error:", d)
        });
      } finally {
        a(!1);
      }
    }
  }, [e]);
  return /* @__PURE__ */ v(
    "div",
    {
      className: `bb-media-upload-zone${r ? " bb-media-upload-zone--drag" : ""}`,
      onDragOver: (i) => {
        i.preventDefault(), o(!0);
      },
      onDragLeave: () => o(!1),
      onDrop: (i) => {
        i.preventDefault(), o(!1), c(Array.from(i.dataTransfer.files));
      },
      onClick: () => {
        var i;
        return (i = t.current) == null ? void 0 : i.click();
      },
      role: "button",
      tabIndex: 0,
      onKeyDown: (i) => {
        var s;
        return i.key === "Enter" && ((s = t.current) == null ? void 0 : s.click());
      },
      children: [
        /* @__PURE__ */ b(
          "input",
          {
            ref: t,
            type: "file",
            multiple: !0,
            accept: "image/*,video/*,audio/*,application/pdf",
            style: { display: "none" },
            onChange: (i) => c(Array.from(i.target.files))
          }
        ),
        n ? /* @__PURE__ */ b("span", { children: "Uploading…" }) : /* @__PURE__ */ b("span", { children: "Drop files here or click to upload" })
      ]
    }
  );
}
function ue({ onSelect: e, allowedTypes: t = [], allowUpload: r = !0 }) {
  const [o, n] = h([]), [a, c] = h(1), [i, s] = h(1), [d, u] = h(""), [l, m] = h(
    t.length === 1 ? t[0] : ""
  ), [f, w] = h(!1), [y, E] = h(null), [g, _] = h(null), B = L(null), P = N(async (p = 1, C = !1) => {
    w(!0), E(null);
    try {
      const k = await le({ page: p, search: d, mediaType: l });
      n((q) => C ? k.items : [...q, ...k.items]), s(k.totalPages), c(p);
    } catch (k) {
      E(k.message);
    } finally {
      w(!1);
    }
  }, [d, l]);
  j(() => {
    P(1, !0);
  }, [P]);
  const I = (p) => {
    clearTimeout(B.current), B.current = setTimeout(() => u(p), 350);
  }, A = (p) => {
    _(p.id), e(p);
  }, F = (p) => {
    n((C) => [p, ...C]);
  }, $ = t.length !== 1;
  return /* @__PURE__ */ v("div", { className: "bb-media-grid-wrap", children: [
    /* @__PURE__ */ v("div", { className: "bb-media-grid-toolbar", children: [
      /* @__PURE__ */ b(
        "input",
        {
          type: "search",
          className: "bb-media-grid-search",
          placeholder: "Search media…",
          onChange: (p) => I(p.target.value)
        }
      ),
      $ && /* @__PURE__ */ b("div", { className: "bb-media-grid-filters", role: "tablist", children: ie.map((p) => /* @__PURE__ */ b(
        "button",
        {
          type: "button",
          role: "tab",
          "aria-selected": l === p.value,
          className: `bb-media-grid-filter${l === p.value ? " bb-media-grid-filter--active" : ""}`,
          onClick: () => m(p.value),
          children: p.label
        },
        p.value
      )) })
    ] }),
    r && /* @__PURE__ */ b(ce, { onUploaded: F }),
    y && /* @__PURE__ */ b("p", { className: "bb-media-grid-error", children: y }),
    /* @__PURE__ */ b("div", { className: "bb-media-grid", role: "listbox", "aria-label": "Media library", children: o.map((p) => /* @__PURE__ */ b(
      de,
      {
        item: p,
        isSelected: g === p.id,
        onSelect: A
      },
      p.id
    )) }),
    !f && o.length === 0 && /* @__PURE__ */ b("p", { className: "bb-media-grid-empty", children: r ? "No media found. Drop files above to upload." : "No media found in the configured storage directory." }),
    f && /* @__PURE__ */ b("p", { className: "bb-media-grid-loading", children: "Loading…" }),
    !f && a < i && /* @__PURE__ */ b(
      "button",
      {
        type: "button",
        className: "bb-media-grid-load-more",
        onClick: () => P(a + 1),
        children: "Load more"
      }
    )
  ] });
}
function fe({ isOpen: e, onClose: t, title: r, children: o }) {
  return e ? /* @__PURE__ */ b(
    "div",
    {
      className: "bb-media-modal-overlay",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": r,
      onClick: (n) => {
        n.target === n.currentTarget && t();
      },
      children: /* @__PURE__ */ v("div", { className: "bb-media-modal", children: [
        /* @__PURE__ */ v("div", { className: "bb-media-modal__header", children: [
          /* @__PURE__ */ b("h2", { className: "bb-media-modal__title", children: r }),
          /* @__PURE__ */ b(
            "button",
            {
              type: "button",
              className: "bb-media-modal__close",
              onClick: t,
              "aria-label": "Close media library",
              children: "✕"
            }
          )
        ] }),
        /* @__PURE__ */ b("div", { className: "bb-media-modal__body", children: o })
      ] })
    }
  ) : null;
}
function be({ onSelect: e, allowedTypes: t = [], multiple: r = !1, render: o }) {
  var f;
  const [n, a] = h(!1), i = (((f = window.BladebergConfig) == null ? void 0 : f.mediaMode) ?? "upload") === "upload", s = i ? "BladeBerg Media Library" : "BladeBerg Media — Browse", d = N(() => a(!0), []), u = N(() => a(!1), []), l = N((w) => {
    e(w), u();
  }, [e, u]), m = [...new Set(
    (t ?? []).map((w) => w.split("/")[0]).filter(Boolean)
  )];
  return /* @__PURE__ */ v(X, { children: [
    typeof o == "function" && o({ open: d }),
    /* @__PURE__ */ b(
      fe,
      {
        isOpen: n,
        onClose: u,
        title: s,
        children: /* @__PURE__ */ b(
          ue,
          {
            onSelect: l,
            allowedTypes: m,
            allowUpload: i
          }
        )
      }
    )
  ] });
}
function ve(e, t) {
  var r, o;
  window.Bladeberg = window.Bladeberg ?? { _queue: [] }, window.Bladeberg._queue = window.Bladeberg._queue ?? [], (o = (r = window.wp) == null ? void 0 : r.blocks) != null && o.registerBlockType ? window.wp.blocks.registerBlockType(e, t) : window.Bladeberg._queue.push({ name: e, settings: t });
}
function pe() {
  var t, r, o;
  if (!((r = (t = window.wp) == null ? void 0 : t.blocks) != null && r.registerBlockType)) return;
  (((o = window.Bladeberg) == null ? void 0 : o._queue) ?? []).forEach(({ name: n, settings: a }) => window.wp.blocks.registerBlockType(n, a)), window.Bladeberg && (window.Bladeberg._queue = []);
}
function me(e) {
  const t = typeof e == "string" ? document.querySelector(e) : e;
  if (!t)
    throw new Error("[BladeBerg] createEditor: target element not found.");
  if (t.tagName === "TEXTAREA")
    return t;
  const r = document.createElement("textarea");
  return t.appendChild(r), r;
}
function we(e, t) {
  var r, o, n, a, c;
  if (e !== "select" && e !== "upload")
    return t;
  if (ae(), (o = (r = window.wp) == null ? void 0 : r.hooks) != null && o.addFilter && window.wp.hooks.addFilter(
    "editor.MediaUpload",
    "bladeberg/media-upload",
    () => be
  ), e === "upload" && (t.editor = {
    ...t.editor ?? {},
    mediaUpload: U
  }, (n = window.wp) != null && n.data))
    try {
      (c = (a = window.wp.data.dispatch("core")) == null ? void 0 : a.receiveUserPermission) == null || c.call(a, "create/media", !0);
    } catch {
    }
  return t;
}
async function _e(e = {}) {
  const {
    target: t,
    value: r,
    settings: o = {},
    blockPrefix: n,
    media: a,
    branding: c = !0,
    contextMenu: i = !0,
    onChange: s
  } = e;
  await V(), pe();
  const d = H({ blockPrefix: n, media: a }), u = d.blockPrefix, l = me(t);
  l.dataset.bladebergMounted = "1", r != null && (l.value = r), l.value && (l.value = Q(l.value, u));
  const m = we(d.mediaMode, { ...o });
  window.wp.attachEditor(l, m), c && Y(u), i && ee();
  const f = /* @__PURE__ */ new Set();
  typeof s == "function" && f.add(s);
  let w = l.value, y = null;
  function E() {
    y || f.size === 0 || (y = window.setInterval(() => {
      if (l.value === w) return;
      w = l.value;
      const g = S(l, u);
      f.forEach((_) => {
        try {
          _(g);
        } catch (B) {
          console.error("[BladeBerg] onChange handler error:", B);
        }
      });
    }, 300));
  }
  return E(), {
    textarea: l,
    getContent: () => S(l, u),
    onChange(g) {
      return f.add(g), E(), () => f.delete(g);
    },
    destroy() {
      var g, _;
      y && (window.clearInterval(y), y = null), f.clear();
      try {
        (_ = (g = window.wp) == null ? void 0 : g.detachEditor) == null || _.call(g, l);
      } catch {
      }
      delete l.dataset.bladebergMounted;
    }
  };
}
z(() => {
  var r;
  if (window.React = window.React ?? D, window.ReactDOM = window.ReactDOM ?? W, (r = window.wp) != null && r.attachEditor)
    return Promise.resolve();
  const e = new URL("./isolated-block-editor.js", import.meta.url).href, t = document.querySelector(`script[data-bladeberg-runtime][src="${e}"]`);
  return t ? new Promise((o, n) => {
    var a;
    if ((a = window.wp) != null && a.attachEditor) return o();
    t.addEventListener("load", () => o()), t.addEventListener("error", () => n(new Error("[BladeBerg] Failed to load editor runtime.")));
  }) : new Promise((o, n) => {
    const a = document.createElement("script");
    a.src = e, a.defer = !0, a.dataset.bladebergRuntime = "1", a.onload = () => o(), a.onerror = () => n(new Error("[BladeBerg] Failed to load editor runtime.")), document.head.appendChild(a);
  });
});
export {
  Y as applyBranding,
  _e as createEditor,
  ee as installBlockContextMenu,
  Z as installCodeEditorOverlay,
  ve as registerBlock
};
