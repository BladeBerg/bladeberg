import M, { useState as h, useRef as O, useCallback as k, useEffect as X } from "react";
import z from "react-dom";
let R = null, B = null;
function K(e) {
  R = e;
}
function V(e, t = 5e3, o = 50) {
  return new Promise((r, n) => {
    const a = Date.now(), s = () => {
      if (e()) return r();
      if (Date.now() - a >= t)
        return n(new Error("[BladeBerg] Timed out waiting for the editor runtime."));
      setTimeout(s, o);
    };
    s();
  });
}
function Y() {
  var e;
  return (e = window.wp) != null && e.attachEditor ? Promise.resolve() : B || (B = (R ? R() : Promise.resolve()).then(() => V(() => {
    var t;
    return !!((t = window.wp) != null && t.attachEditor);
  })).catch((t) => {
    throw B = null, t;
  }), B);
}
function G(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function H({ blockPrefix: e, media: t } = {}) {
  var n;
  const o = window.BladebergConfig ?? {}, r = {
    blockPrefix: e ?? o.blockPrefix ?? "bb",
    mediaMode: (t == null ? void 0 : t.mode) ?? o.mediaMode ?? "disabled",
    mediaApiUrl: (t == null ? void 0 : t.apiUrl) ?? o.mediaApiUrl ?? "",
    csrfToken: (t == null ? void 0 : t.csrfToken) ?? o.csrfToken ?? ((n = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : n.getAttribute("content")) ?? ""
  };
  return window.BladebergConfig = { ...o, ...r }, r;
}
function j(e, t) {
  return ((e == null ? void 0 : e.value) ?? "").replace(/<!--\s*(\/?)wp:/g, `<!-- $1${t}:`);
}
function J(e, t) {
  if (!e) return e;
  const o = new RegExp(`<!--\\s*(\\/?)\\s*${G(t)}:`, "g");
  return e.replace(o, "<!-- $1wp:");
}
function L(e) {
  var t;
  return e ?? ((t = window.BladebergConfig) == null ? void 0 : t.blockPrefix) ?? "bb";
}
function Q(e) {
  const t = L(e);
  if (window.__bbBrandingInstalled) {
    C(document.body, t);
    return;
  }
  window.__bbBrandingInstalled = !0, C(document.body, t);
  const o = new MutationObserver((r) => {
    for (const { addedNodes: n } of r)
      for (const a of n)
        a.nodeType === Node.ELEMENT_NODE && C(a, t);
  });
  o.observe(document.body, { childList: !0, subtree: !0 }), window.Bladeberg = window.Bladeberg ?? {}, window.Bladeberg._brandingObserver = o, ee(t);
}
function Z(e) {
  return [
    { from: /WordPress/g, to: "BladeBerg" },
    { from: /\bWP\b(?![-_])/g, to: "BB" },
    { from: /\bwp:([\w-]+)/g, to: `${e}:$1` },
    { from: /\bcore\/([\w-]+)/g, to: `${e}/$1` }
  ];
}
function C(e, t) {
  if (!e) return;
  const o = Z(t);
  if (e.nodeType === Node.TEXT_NODE) {
    S(e, o);
    return;
  }
  const r = document.createTreeWalker(e, NodeFilter.SHOW_TEXT, {
    acceptNode(s) {
      var d;
      const i = ((d = s.parentElement) == null ? void 0 : d.tagName) ?? "";
      return ["SCRIPT", "STYLE", "INPUT", "TEXTAREA"].includes(i) ? NodeFilter.FILTER_REJECT : o.some((u) => (u.from.lastIndex = 0, u.from.test(s.textContent))) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  }), n = [];
  let a;
  for (; a = r.nextNode(); ) n.push(a);
  n.forEach((s) => S(s, o));
}
function S(e, t) {
  let o = e.textContent;
  for (const { from: r, to: n } of t)
    r.lastIndex = 0, o = o.replace(r, n);
  o !== e.textContent && (e.textContent = o);
}
function ee(e) {
  const t = L(e), o = "data-bb-code-overlay";
  function r(i) {
    return i.replace(/wp:([\w-]+)/g, `${t}:$1`).replace(/WordPress/g, "BladeBerg").replace(/core\/([\w-]+)/g, `${t}/$1`);
  }
  function n(i) {
    var u;
    if (i.hasAttribute(o)) return;
    i.setAttribute(o, "1");
    const c = i.parentElement;
    c && getComputedStyle(c).position === "static" && (c.style.position = "relative");
    const d = document.createElement("pre");
    d.className = "bb-code-editor-overlay", d.textContent = r(i.value), d.setAttribute("aria-hidden", "true"), (u = i.parentNode) == null || u.insertBefore(d, i.nextSibling), i.addEventListener("input", () => {
      d.textContent = r(i.value);
    });
  }
  const a = ".editor-post-text-editor, .block-editor-plain-text";
  if (document.querySelectorAll(a).forEach(n), window.__bbOverlayInstalled) return;
  window.__bbOverlayInstalled = !0;
  const s = new MutationObserver((i) => {
    var c, d;
    for (const { addedNodes: u } of i)
      for (const l of u)
        l.nodeType === Node.ELEMENT_NODE && ((c = l.querySelectorAll) == null || c.call(l, a).forEach(n), (d = l.matches) != null && d.call(l, a) && n(l));
  });
  s.observe(document.body, { childList: !0, subtree: !0 }), window.Bladeberg = window.Bladeberg ?? {}, window.Bladeberg._overlayObserver = s;
}
function te() {
  if (window.__bbContextMenuInstalled) return;
  window.__bbContextMenuInstalled = !0;
  const e = ".block-editor-block-list__layout, .editor-styles-wrapper, .iso-editor";
  function t(o = 0) {
    const r = document.querySelector(".block-editor-block-settings-menu__toggle") || document.querySelector(".block-editor-block-settings-menu button") || document.querySelector('button[aria-label="Options"]') || document.querySelector('.block-editor-block-settings-menu [role="button"]');
    if (r) {
      r.click();
      return;
    }
    o < 10 && setTimeout(() => t(o + 1), 30);
  }
  document.addEventListener(
    "contextmenu",
    (o) => {
      var s;
      const r = o.target, n = (s = r == null ? void 0 : r.closest) == null ? void 0 : s.call(r, "[data-block]");
      if (!n || !n.closest(e))
        return;
      o.preventDefault();
      const a = { bubbles: !0, cancelable: !0, view: window, button: 0 };
      if (r.dispatchEvent(new MouseEvent("mousedown", a)), r.dispatchEvent(new MouseEvent("mouseup", a)), typeof n.focus == "function")
        try {
          n.focus({ preventScroll: !0 });
        } catch {
        }
      setTimeout(() => t(), 30);
    },
    { capture: !0 }
  );
}
function re(e) {
  var t, o;
  return {
    ...e,
    alt: e.alt_text ?? "",
    caption: ((t = e.caption) == null ? void 0 : t.raw) ?? "",
    title: ((o = e.title) == null ? void 0 : o.raw) ?? e.title ?? "",
    url: e.source_url ?? e.url ?? ""
  };
}
async function oe(e, t = {}, o) {
  var u, l, m;
  const r = window.BladebergConfig ?? {}, n = r.mediaApiUrl, a = r.csrfToken ?? ((u = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : u.getAttribute("content"));
  if (!n)
    throw new Error("[BladeBerg] mediaApiUrl is not configured. Set media.enabled = true in config/bladeberg.php.");
  const s = new FormData();
  s.append("file", e, e.name || "upload");
  const i = ["alt_text", "title", "caption"];
  for (const p of i)
    t[p] !== void 0 && t[p] !== null && s.append(p, t[p]);
  const c = {};
  a && (c["X-CSRF-TOKEN"] = a);
  const d = await fetch(n, {
    method: "POST",
    headers: c,
    body: s,
    credentials: "same-origin",
    signal: o
  });
  if (!d.ok) {
    const p = await d.json().catch(() => ({})), w = (p == null ? void 0 : p.message) ?? ((m = (l = p == null ? void 0 : p.errors) == null ? void 0 : l.file) == null ? void 0 : m[0]) ?? `HTTP ${d.status}`;
    throw new Error(`[BladeBerg] Upload failed: ${w}`);
  }
  return re(await d.json());
}
async function U({
  filesList: e,
  onFileChange: t,
  onSuccess: o,
  onError: r,
  additionalData: n = {},
  signal: a
}) {
  const s = Array.from(e), i = [];
  for (const c of s) {
    const d = URL.createObjectURL(c), u = { url: d, media_type: c.type };
    t([u]);
    try {
      const l = await oe(c, n, a);
      URL.revokeObjectURL(d), t([l]), i.push(l);
    } catch (l) {
      URL.revokeObjectURL(d), typeof r == "function" ? r({ code: "upload_error", message: l.message, file: c }) : console.error("[BladeBerg] Media upload error:", l);
    }
  }
  i.length > 0 && typeof o == "function" && o(i);
}
const ne = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  bladebergMediaUpload: U
}, Symbol.toStringTag, { value: "Module" }));
function ae(e) {
  const t = window.BladebergConfig ?? {}, o = t.mediaApiUrl ? new URL(t.mediaApiUrl).pathname : "/bladeberg/media", r = e.replace(/^\/wp\/v2\/media/, ""), n = r.indexOf("?"), a = n >= 0 ? r.slice(0, n) : r, s = n >= 0 ? r.slice(n + 1) : "", i = new URLSearchParams(s), c = new URLSearchParams(), d = ["page", "per_page", "search", "media_type", "orderby", "order"];
  for (const m of d)
    i.has(m) && c.set(m, i.get(m));
  const u = c.toString();
  return o + a + (u ? "?" + u : "");
}
function ie() {
  var t;
  const e = (t = window.wp) == null ? void 0 : t.apiFetch;
  if (!e) {
    console.warn("[BladeBerg] window.wp.apiFetch not found — media API middleware not registered.");
    return;
  }
  e.use((o, r) => {
    const n = o.path ?? "";
    return typeof n == "string" && n.startsWith("/wp/v2/media") ? r({ ...o, path: ae(n) }) : r(o);
  });
}
var I = { exports: {} }, T = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var le = M, se = Symbol.for("react.element"), de = Symbol.for("react.fragment"), ce = Object.prototype.hasOwnProperty, ue = le.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, fe = { key: !0, ref: !0, __self: !0, __source: !0 };
function A(e, t, o) {
  var r, n = {}, a = null, s = null;
  o !== void 0 && (a = "" + o), t.key !== void 0 && (a = "" + t.key), t.ref !== void 0 && (s = t.ref);
  for (r in t) ce.call(t, r) && !fe.hasOwnProperty(r) && (n[r] = t[r]);
  if (e && e.defaultProps) for (r in t = e.defaultProps, t) n[r] === void 0 && (n[r] = t[r]);
  return { $$typeof: se, type: e, key: a, ref: s, props: n, _owner: ue.current };
}
T.Fragment = de;
T.jsx = A;
T.jsxs = A;
I.exports = T;
var f = I.exports;
const pe = [
  { label: "All", value: "" },
  { label: "Images", value: "image" },
  { label: "Video", value: "video" },
  { label: "Audio", value: "audio" },
  { label: "Documents", value: "application" }
];
async function be({ page: e = 1, perPage: t = 20, search: o = "", mediaType: r = "" } = {}) {
  var m;
  const n = window.BladebergConfig ?? {}, a = n.csrfToken ?? ((m = document.querySelector('meta[name="csrf-token"]')) == null ? void 0 : m.content), s = n.mediaApiUrl ?? "/bladeberg/media", i = new URLSearchParams({ page: e, per_page: t });
  o && i.set("search", o), r && i.set("media_type", r);
  const c = await fetch(`${s}?${i}`, {
    headers: {
      Accept: "application/json",
      ...a ? { "X-CSRF-TOKEN": a } : {}
    },
    credentials: "same-origin"
  });
  if (!c.ok) throw new Error(`[BladeBerg] Media fetch failed: ${c.status}`);
  const d = await c.json(), u = parseInt(c.headers.get("X-WP-Total") ?? "0", 10), l = parseInt(c.headers.get("X-WP-TotalPages") ?? "1", 10);
  return { items: d, total: u, totalPages: l };
}
function me({ item: e, isSelected: t, onSelect: o }) {
  var a, s, i, c, d, u;
  const r = (a = e.mime_type) == null ? void 0 : a.startsWith("image/"), n = e.source_url ?? e.url ?? "";
  return /* @__PURE__ */ f.jsxs(
    "button",
    {
      type: "button",
      className: `bb-media-grid__item${t ? " bb-media-grid__item--selected" : ""}`,
      onClick: () => o(e),
      title: ((s = e.title) == null ? void 0 : s.rendered) ?? e.title ?? n,
      "aria-pressed": t,
      children: [
        r ? /* @__PURE__ */ f.jsx(
          "img",
          {
            src: ((d = (c = (i = e.media_details) == null ? void 0 : i.sizes) == null ? void 0 : c.thumbnail) == null ? void 0 : d.source_url) ?? n,
            alt: e.alt_text ?? "",
            loading: "lazy",
            className: "bb-media-grid__thumb"
          }
        ) : /* @__PURE__ */ f.jsx("div", { className: "bb-media-grid__icon", "aria-hidden": "true", children: we(e.mime_type) }),
        /* @__PURE__ */ f.jsx("span", { className: "bb-media-grid__name", children: ((u = e.title) == null ? void 0 : u.rendered) ?? e.title ?? "" })
      ]
    }
  );
}
function we(e = "") {
  return e.startsWith("video/") ? "🎬" : e.startsWith("audio/") ? "🎵" : e.includes("pdf") ? "📄" : "📁";
}
function ge({ onUploaded: e }) {
  const t = O(null), [o, r] = h(!1), [n, a] = h(!1), s = k(async (i) => {
    if (i.length) {
      a(!0);
      try {
        const { bladebergMediaUpload: c } = await Promise.resolve().then(() => ne);
        await c({
          filesList: i,
          onFileChange: (d) => {
            var u;
            (u = d[0]) != null && u.id && e(d[0]);
          },
          onError: (d) => console.error("[BladeBerg] Upload error:", d)
        });
      } finally {
        a(!1);
      }
    }
  }, [e]);
  return /* @__PURE__ */ f.jsxs(
    "div",
    {
      className: `bb-media-upload-zone${o ? " bb-media-upload-zone--drag" : ""}`,
      onDragOver: (i) => {
        i.preventDefault(), r(!0);
      },
      onDragLeave: () => r(!1),
      onDrop: (i) => {
        i.preventDefault(), r(!1), s(Array.from(i.dataTransfer.files));
      },
      onClick: () => {
        var i;
        return (i = t.current) == null ? void 0 : i.click();
      },
      role: "button",
      tabIndex: 0,
      onKeyDown: (i) => {
        var c;
        return i.key === "Enter" && ((c = t.current) == null ? void 0 : c.click());
      },
      children: [
        /* @__PURE__ */ f.jsx(
          "input",
          {
            ref: t,
            type: "file",
            multiple: !0,
            accept: "image/*,video/*,audio/*,application/pdf",
            style: { display: "none" },
            onChange: (i) => s(Array.from(i.target.files))
          }
        ),
        n ? /* @__PURE__ */ f.jsx("span", { children: "Uploading…" }) : /* @__PURE__ */ f.jsx("span", { children: "Drop files here or click to upload" })
      ]
    }
  );
}
function he({ onSelect: e, allowedTypes: t = [], allowUpload: o = !0 }) {
  const [r, n] = h([]), [a, s] = h(1), [i, c] = h(1), [d, u] = h(""), [l, m] = h(
    t.length === 1 ? t[0] : ""
  ), [p, w] = h(!1), [y, v] = h(null), [g, _] = h(null), E = O(null), N = k(async (b = 1, P = !1) => {
    w(!0), v(null);
    try {
      const x = await be({ page: b, search: d, mediaType: l });
      n((W) => P ? x.items : [...W, ...x.items]), c(x.totalPages), s(b);
    } catch (x) {
      v(x.message);
    } finally {
      w(!1);
    }
  }, [d, l]);
  X(() => {
    N(1, !0);
  }, [N]);
  const F = (b) => {
    clearTimeout(E.current), E.current = setTimeout(() => u(b), 350);
  }, $ = (b) => {
    _(b.id), e(b);
  }, q = (b) => {
    n((P) => [b, ...P]);
  }, D = t.length !== 1;
  return /* @__PURE__ */ f.jsxs("div", { className: "bb-media-grid-wrap", children: [
    /* @__PURE__ */ f.jsxs("div", { className: "bb-media-grid-toolbar", children: [
      /* @__PURE__ */ f.jsx(
        "input",
        {
          type: "search",
          className: "bb-media-grid-search",
          placeholder: "Search media…",
          onChange: (b) => F(b.target.value)
        }
      ),
      D && /* @__PURE__ */ f.jsx("div", { className: "bb-media-grid-filters", role: "tablist", children: pe.map((b) => /* @__PURE__ */ f.jsx(
        "button",
        {
          type: "button",
          role: "tab",
          "aria-selected": l === b.value,
          className: `bb-media-grid-filter${l === b.value ? " bb-media-grid-filter--active" : ""}`,
          onClick: () => m(b.value),
          children: b.label
        },
        b.value
      )) })
    ] }),
    o && /* @__PURE__ */ f.jsx(ge, { onUploaded: q }),
    y && /* @__PURE__ */ f.jsx("p", { className: "bb-media-grid-error", children: y }),
    /* @__PURE__ */ f.jsx("div", { className: "bb-media-grid", role: "listbox", "aria-label": "Media library", children: r.map((b) => /* @__PURE__ */ f.jsx(
      me,
      {
        item: b,
        isSelected: g === b.id,
        onSelect: $
      },
      b.id
    )) }),
    !p && r.length === 0 && /* @__PURE__ */ f.jsx("p", { className: "bb-media-grid-empty", children: o ? "No media found. Drop files above to upload." : "No media found in the configured storage directory." }),
    p && /* @__PURE__ */ f.jsx("p", { className: "bb-media-grid-loading", children: "Loading…" }),
    !p && a < i && /* @__PURE__ */ f.jsx(
      "button",
      {
        type: "button",
        className: "bb-media-grid-load-more",
        onClick: () => N(a + 1),
        children: "Load more"
      }
    )
  ] });
}
function ye({ isOpen: e, onClose: t, title: o, children: r }) {
  return e ? /* @__PURE__ */ f.jsx(
    "div",
    {
      className: "bb-media-modal-overlay",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": o,
      onClick: (n) => {
        n.target === n.currentTarget && t();
      },
      children: /* @__PURE__ */ f.jsxs("div", { className: "bb-media-modal", children: [
        /* @__PURE__ */ f.jsxs("div", { className: "bb-media-modal__header", children: [
          /* @__PURE__ */ f.jsx("h2", { className: "bb-media-modal__title", children: o }),
          /* @__PURE__ */ f.jsx(
            "button",
            {
              type: "button",
              className: "bb-media-modal__close",
              onClick: t,
              "aria-label": "Close media library",
              children: "✕"
            }
          )
        ] }),
        /* @__PURE__ */ f.jsx("div", { className: "bb-media-modal__body", children: r })
      ] })
    }
  ) : null;
}
function _e({ onSelect: e, allowedTypes: t = [], multiple: o = !1, render: r }) {
  var p;
  const [n, a] = h(!1), i = (((p = window.BladebergConfig) == null ? void 0 : p.mediaMode) ?? "upload") === "upload", c = i ? "BladeBerg Media Library" : "BladeBerg Media — Browse", d = k(() => a(!0), []), u = k(() => a(!1), []), l = k((w) => {
    e(w), u();
  }, [e, u]), m = [...new Set(
    (t ?? []).map((w) => w.split("/")[0]).filter(Boolean)
  )];
  return /* @__PURE__ */ f.jsxs(f.Fragment, { children: [
    typeof r == "function" && r({ open: d }),
    /* @__PURE__ */ f.jsx(
      ye,
      {
        isOpen: n,
        onClose: u,
        title: c,
        children: /* @__PURE__ */ f.jsx(
          he,
          {
            onSelect: l,
            allowedTypes: m,
            allowUpload: i
          }
        )
      }
    )
  ] });
}
function Te(e, t) {
  var o, r;
  window.Bladeberg = window.Bladeberg ?? { _queue: [] }, window.Bladeberg._queue = window.Bladeberg._queue ?? [], (r = (o = window.wp) == null ? void 0 : o.blocks) != null && r.registerBlockType ? window.wp.blocks.registerBlockType(e, t) : window.Bladeberg._queue.push({ name: e, settings: t });
}
function ve() {
  var t, o, r;
  if (!((o = (t = window.wp) == null ? void 0 : t.blocks) != null && o.registerBlockType)) return;
  (((r = window.Bladeberg) == null ? void 0 : r._queue) ?? []).forEach(({ name: n, settings: a }) => window.wp.blocks.registerBlockType(n, a)), window.Bladeberg && (window.Bladeberg._queue = []);
}
function Ee(e) {
  const t = typeof e == "string" ? document.querySelector(e) : e;
  if (!t)
    throw new Error("[BladeBerg] createEditor: target element not found.");
  if (t.tagName === "TEXTAREA")
    return t;
  const o = document.createElement("textarea");
  return t.appendChild(o), o;
}
function xe(e, t) {
  var o, r, n, a, s;
  if (e !== "select" && e !== "upload")
    return t;
  if (ie(), (r = (o = window.wp) == null ? void 0 : o.hooks) != null && r.addFilter && window.wp.hooks.addFilter(
    "editor.MediaUpload",
    "bladeberg/media-upload",
    () => _e
  ), e === "upload" && (t.editor = {
    ...t.editor ?? {},
    mediaUpload: U
  }, (n = window.wp) != null && n.data))
    try {
      (s = (a = window.wp.data.dispatch("core")) == null ? void 0 : a.receiveUserPermission) == null || s.call(a, "create/media", !0);
    } catch {
    }
  return t;
}
async function Ne(e = {}) {
  const {
    target: t,
    value: o,
    settings: r = {},
    blockPrefix: n,
    media: a,
    branding: s = !0,
    contextMenu: i = !0,
    onChange: c
  } = e;
  await Y(), ve();
  const d = H({ blockPrefix: n, media: a }), u = d.blockPrefix, l = Ee(t);
  l.dataset.bladebergMounted = "1", o != null && (l.value = o), l.value && (l.value = J(l.value, u));
  const m = xe(d.mediaMode, { ...r });
  window.wp.attachEditor(l, m), s && Q(u), i && te();
  const p = /* @__PURE__ */ new Set();
  typeof c == "function" && p.add(c);
  let w = l.value, y = null;
  function v() {
    y || p.size === 0 || (y = window.setInterval(() => {
      if (l.value === w) return;
      w = l.value;
      const g = j(l, u);
      p.forEach((_) => {
        try {
          _(g);
        } catch (E) {
          console.error("[BladeBerg] onChange handler error:", E);
        }
      });
    }, 300));
  }
  return v(), {
    textarea: l,
    getContent: () => j(l, u),
    onChange(g) {
      return p.add(g), v(), () => p.delete(g);
    },
    destroy() {
      var g, _;
      y && (window.clearInterval(y), y = null), p.clear();
      try {
        (_ = (g = window.wp) == null ? void 0 : g.detachEditor) == null || _.call(g, l);
      } catch {
      }
      delete l.dataset.bladebergMounted;
    }
  };
}
K(() => {
  var o;
  if (window.React = window.React ?? M, window.ReactDOM = window.ReactDOM ?? z, (o = window.wp) != null && o.attachEditor)
    return Promise.resolve();
  const e = new URL("./isolated-block-editor.js", import.meta.url).href, t = document.querySelector(`script[data-bladeberg-runtime][src="${e}"]`);
  return t ? new Promise((r, n) => {
    var a;
    if ((a = window.wp) != null && a.attachEditor) return r();
    t.addEventListener("load", () => r()), t.addEventListener("error", () => n(new Error("[BladeBerg] Failed to load editor runtime.")));
  }) : new Promise((r, n) => {
    const a = document.createElement("script");
    a.src = e, a.defer = !0, a.dataset.bladebergRuntime = "1", a.onload = () => r(), a.onerror = () => n(new Error("[BladeBerg] Failed to load editor runtime.")), document.head.appendChild(a);
  });
});
export {
  Q as applyBranding,
  Ne as createEditor,
  te as installBlockContextMenu,
  ee as installCodeEditorOverlay,
  Te as registerBlock
};
